import {env} from 'cloudflare:workers';
import {ownerIdentity} from '@/lib/pin-lock';
import {adminLogin,adminSession} from '@/lib/admin-access';
import {readSettings,validateSettings,DEFAULT_SETTINGS} from '@/lib/site-settings';
import {settingChanges} from '@/lib/admin-config';
import {probeSource,sourceFingerprint} from '@/lib/source-probe';
import {performanceStats} from '@/lib/forecast-journal';
import {normalizeAdminAudit} from '@/lib/admin-audit';
async function dashboard(db:any){const [sources,versions,records,audit]=await Promise.all([db.prepare('SELECT * FROM source_status').all(),db.prepare('SELECT id,created_at FROM settings_history ORDER BY created_at DESC,rowid DESC LIMIT 20').all(),db.prepare('SELECT f.id,f.symbol,f.created_at,f.horizon,f.model,f.market,f.sector,f.confidence,f.available,COALESCE(json_extract(f.data,\'$.recordClass\'),\'legacy-unverified\') AS recordClass,o.data AS outcome_data FROM forecast_records f LEFT JOIN forecast_outcomes o ON o.id=f.id').all(),db.prepare('SELECT * FROM admin_audit ORDER BY created_at DESC, rowid DESC LIMIT 100').all()]);return {audit:normalizeAdminAudit(audit.results),sources:sources.results||[],versions:versions.results||[],performance:performanceStats((records.results||[]).map((r:any)=>({...r,outcome:r.outcome_data?JSON.parse(r.outcome_data):null})))};}
const headers={'Cache-Control':'no-store, private'};
export async function POST(req:Request){try{
 const runtime=env as unknown as {DB:any;ADMIN_PASSWORD_HASH:string;RECOMMENDATION_OWNER_EMAIL:string};
 if(req.headers.get('origin')!==new URL(req.url).origin||!ownerIdentity(req.headers,runtime.RECOMMENDATION_OWNER_EMAIL||''))return Response.json({error:'يلزم حساب مالك الموقع.'},{status:403,headers});
 const raw=await req.text();if(raw.length>150000)throw Error('الطلب أكبر من الحد.');const b=JSON.parse(raw);
 if(b.action==='login'){const token=await adminLogin(runtime.DB,runtime.ADMIN_PASSWORD_HASH,b.username,b.password);return Response.json({settings:await readSettings(runtime.DB),...await dashboard(runtime.DB)},{headers:{...headers,'Set-Cookie':`mizan_admin=${token}; HttpOnly; Secure; SameSite=Strict; Path=/api/admin; Max-Age=1800`}});}
 if(!await adminSession(runtime.DB,req))return Response.json({error:'انتهت جلسة الإدارة؛ سجّل الدخول مجددًا.'},{status:401,headers});
 if(b.action==='logout'){await runtime.DB.prepare("UPDATE admin_access SET session_hash='',expires_at=0 WHERE id=1").run();return Response.json({ok:true},{headers:{...headers,'Set-Cookie':'mizan_admin=; HttpOnly; Secure; SameSite=Strict; Path=/api/admin; Max-Age=0'}});}
 if(b.action==='probe'){const current=await readSettings(runtime.DB);const source=validateSettings({...current,sourceConfig:[...current.sourceConfig.filter(v=>v.id!==b.source?.id),b.source]}).sourceConfig.find(v=>v.id===b.source.id)!;const result=await probeSource(source,String(b.symbol||'AAPL').toUpperCase()),id=await sourceFingerprint(source);await runtime.DB.prepare('INSERT INTO source_status(id,status,last_attempt,last_success,detail) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,last_attempt=excluded.last_attempt,last_success=excluded.last_success,detail=excluded.detail').bind(id,result.state,result.checkedAt,result.state==='failed'?'':result.checkedAt,JSON.stringify({...result,sourceId:source.id})).run();return Response.json({probe:{...result,sourceId:source.id},...await dashboard(runtime.DB)},{headers});}
 if(b.action==='load')return Response.json({settings:await readSettings(runtime.DB),...await dashboard(runtime.DB)},{headers});
 if(['save','reset','restore'].includes(b.action)){
  let candidate=b.action==='reset'?DEFAULT_SETTINGS:b.settings;
  if(b.action==='restore'){const version=await runtime.DB.prepare('SELECT data FROM settings_history WHERE id=?').bind(String(b.versionId||'')).first();if(!version)throw Error('نسخة الإعدادات غير موجودة.');candidate=JSON.parse(version.data);}
  const previous=await readSettings(runtime.DB),settings={...validateSettings(candidate),updatedAt:new Date().toISOString()};
  for(const source of settings.sourceConfig){const old=previous.sourceConfig.find(v=>v.id===source.id);if(source.enabled&&!source.deleted&&source.adapter!=='builtin'&&(!old||old.url!==source.url||old.adapter!==source.adapter||!old.enabled||old.deleted)){const probe=await runtime.DB.prepare('SELECT status,last_attempt FROM source_status WHERE id=?').bind(await sourceFingerprint(source)).first();if(!probe||probe.status==='failed'||Date.now()-Date.parse(probe.last_attempt)>86400000)throw Error('اختبر رابط المصدر قبل اعتماده: '+source.name);}}
  const changes=settingChanges(previous,settings);
  await runtime.DB.batch([runtime.DB.prepare('INSERT INTO admin_audit(id,created_at,action,data) VALUES(?,?,?,?)').bind(crypto.randomUUID(),settings.updatedAt,b.action,JSON.stringify(changes)),runtime.DB.prepare('INSERT INTO settings_history (id,created_at,data) VALUES (?,?,?)').bind(crypto.randomUUID(),settings.updatedAt,JSON.stringify(previous)),runtime.DB.prepare('INSERT INTO site_settings (id,value) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').bind(JSON.stringify(settings))]);
  return Response.json({settings,...await dashboard(runtime.DB),message:'حُفظت الإعدادات وانعكست على الموقع. تُطبق قواعد الحساب على التحليل التالي؛ السجلات القديمة تبقى ثابتة.'},{headers});}
 throw Error('طلب غير صالح.');
 }catch(e){return Response.json({error:e instanceof Error?e.message:'تعذرت العملية؛ لم يتم تأكيد الحفظ.'},{status:400,headers});}}
