-- SQLite OR REPLACE may suppress DELETE triggers when recursive_triggers=OFF.
-- Preserve every hidden rowid ever issued so a replacement by rowid can be
-- rejected after SQLite has assigned NEW.rowid, including default auto-rowids.
CREATE TABLE IF NOT EXISTS analysis_snapshot_rowid_history (
  issued_rowid INTEGER PRIMARY KEY NOT NULL
);
--> statement-breakpoint
INSERT INTO analysis_snapshot_rowid_history (issued_rowid)
SELECT source.rowid FROM analysis_snapshots AS source
WHERE NOT EXISTS (
  SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = source.rowid
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS forecast_record_rowid_history (
  issued_rowid INTEGER PRIMARY KEY NOT NULL
);
--> statement-breakpoint
INSERT INTO forecast_record_rowid_history (issued_rowid)
SELECT source.rowid FROM forecast_records AS source
WHERE NOT EXISTS (
  SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = source.rowid
);
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS analysis_snapshot_rowid_history_insert_guard
BEFORE INSERT ON analysis_snapshot_rowid_history
WHEN EXISTS (
  SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = NEW.issued_rowid
)
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_already_issued');
END;
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS analysis_snapshot_rowid_history_update_guard
BEFORE UPDATE ON analysis_snapshot_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_history_is_immutable');
END;
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS analysis_snapshot_rowid_history_delete_guard
BEFORE DELETE ON analysis_snapshot_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_history_is_immutable');
END;
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS analysis_snapshot_track_rowid_after_insert
AFTER INSERT ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_already_issued')
  WHERE EXISTS (
    SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = NEW.rowid
  );
  INSERT INTO analysis_snapshot_rowid_history (issued_rowid) VALUES (NEW.rowid);
END;
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS forecast_record_rowid_history_insert_guard
BEFORE INSERT ON forecast_record_rowid_history
WHEN EXISTS (
  SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = NEW.issued_rowid
)
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_already_issued');
END;
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS forecast_record_rowid_history_update_guard
BEFORE UPDATE ON forecast_record_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_history_is_immutable');
END;
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS forecast_record_rowid_history_delete_guard
BEFORE DELETE ON forecast_record_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_history_is_immutable');
END;
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS forecast_record_track_rowid_after_insert
AFTER INSERT ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_already_issued')
  WHERE EXISTS (
    SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = NEW.rowid
  );
  INSERT INTO forecast_record_rowid_history (issued_rowid) VALUES (NEW.rowid);
END;
