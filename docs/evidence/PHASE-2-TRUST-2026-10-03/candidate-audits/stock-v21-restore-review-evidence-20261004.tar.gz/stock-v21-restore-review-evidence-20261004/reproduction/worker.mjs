import * as app from './functional-bundle.mjs';
import {reportFor, FIXED_NOW} from './flow-fixtures.mjs';
const NativeDate=globalThis.Date;
class FrozenDate extends NativeDate { constructor(...a){ if(a.length===0) super(FIXED_NOW); else super(...a) } static now(){ return FIXED_NOW } static parse(v){ return NativeDate.parse(v) } static UTC(...a){ return NativeDate.UTC(...a) } }
globalThis.Date=FrozenDate;
const historyTriggers = [
  'analysis_snapshot_rowid_history_insert_guard',
  'analysis_snapshot_rowid_history_update_guard',
  'analysis_snapshot_rowid_history_delete_guard',
  'analysis_snapshot_track_rowid_after_insert',
  'forecast_record_rowid_history_insert_guard',
  'forecast_record_rowid_history_update_guard',
  'forecast_record_rowid_history_delete_guard',
  'forecast_record_track_rowid_after_insert',
];
const resetSql = [
  ...historyTriggers.map((name) => `DROP TRIGGER IF EXISTS ${name}`),
  'DELETE FROM analysis_snapshot_rowid_history',
  'DELETE FROM forecast_record_rowid_history',
  'INSERT INTO analysis_snapshot_rowid_history(issued_rowid) SELECT rowid FROM analysis_snapshots ORDER BY rowid',
  'INSERT INTO forecast_record_rowid_history(issued_rowid) SELECT rowid FROM forecast_records ORDER BY rowid',
  `CREATE TRIGGER analysis_snapshot_rowid_history_insert_guard BEFORE INSERT ON analysis_snapshot_rowid_history WHEN EXISTS (SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid=NEW.issued_rowid) BEGIN SELECT RAISE(ABORT,'analysis_snapshot_rowid_already_issued'); END`,
  `CREATE TRIGGER analysis_snapshot_rowid_history_update_guard BEFORE UPDATE ON analysis_snapshot_rowid_history BEGIN SELECT RAISE(ABORT,'analysis_snapshot_rowid_history_is_immutable'); END`,
  `CREATE TRIGGER analysis_snapshot_rowid_history_delete_guard BEFORE DELETE ON analysis_snapshot_rowid_history BEGIN SELECT RAISE(ABORT,'analysis_snapshot_rowid_history_is_immutable'); END`,
  `CREATE TRIGGER analysis_snapshot_track_rowid_after_insert AFTER INSERT ON analysis_snapshots BEGIN SELECT RAISE(ABORT,'analysis_snapshot_rowid_already_issued') WHERE EXISTS (SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid=NEW.rowid); INSERT INTO analysis_snapshot_rowid_history(issued_rowid) VALUES(NEW.rowid); END`,
  `CREATE TRIGGER forecast_record_rowid_history_insert_guard BEFORE INSERT ON forecast_record_rowid_history WHEN EXISTS (SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid=NEW.issued_rowid) BEGIN SELECT RAISE(ABORT,'forecast_record_rowid_already_issued'); END`,
  `CREATE TRIGGER forecast_record_rowid_history_update_guard BEFORE UPDATE ON forecast_record_rowid_history BEGIN SELECT RAISE(ABORT,'forecast_record_rowid_history_is_immutable'); END`,
  `CREATE TRIGGER forecast_record_rowid_history_delete_guard BEFORE DELETE ON forecast_record_rowid_history BEGIN SELECT RAISE(ABORT,'forecast_record_rowid_history_is_immutable'); END`,
  `CREATE TRIGGER forecast_record_track_rowid_after_insert AFTER INSERT ON forecast_records BEGIN SELECT RAISE(ABORT,'forecast_record_rowid_already_issued') WHERE EXISTS (SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid=NEW.rowid); INSERT INTO forecast_record_rowid_history(issued_rowid) VALUES(NEW.rowid); END`,
];
let offline = true;
const snapSql = 'SELECT id,symbol,created_at,data FROM analysis_snapshots ORDER BY id';
const forecastSql = 'SELECT id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data FROM forecast_records ORDER BY id';
async function all(db, sql, args=[]) { const stmt=args.length?db.prepare(sql).bind(...args):db.prepare(sql); return (await stmt.all()).results || []; }
async function digestRows(db) {
  const a = await all(db, snapSql), f = await all(db, forecastSql);
  const bytes = new TextEncoder().encode(JSON.stringify({analysis_snapshots:a,forecast_records:f}));
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  const hex = [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');
  return {hash:hex,analysis_snapshots:a,forecast_records:f};
}
async function currentState(db) {
  const logical = await digestRows(db);
  const s = await all(db, 'SELECT rowid,id FROM analysis_snapshots ORDER BY rowid');
  const sh = await all(db, 'SELECT issued_rowid FROM analysis_snapshot_rowid_history ORDER BY issued_rowid');
  const f = await all(db, 'SELECT rowid,id FROM forecast_records ORDER BY rowid');
  const fh = await all(db, 'SELECT issued_rowid FROM forecast_record_rowid_history ORDER BY issued_rowid');
  const triggers=await all(db, "SELECT name FROM sqlite_master WHERE type='trigger' AND (name LIKE 'analysis_snapshot_%' OR name LIKE 'forecast_record_%') ORDER BY name");
  const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  return {logical_hash:logical.hash,snapshots:s,snapshot_history:sh.map(x=>x.issued_rowid),forecasts:f,forecast_history:fh.map(x=>x.issued_rowid),snapshotLedgerMatchesCurrent:JSON.stringify(s.map(x=>x.rowid).sort((x,y)=>x-y))===JSON.stringify(sh.map(x=>x.issued_rowid).sort((x,y)=>x-y)),forecastLedgerMatchesCurrent:JSON.stringify(f.map(x=>x.rowid).sort((x,y)=>x-y))===JSON.stringify(fh.map(x=>x.issued_rowid).sort((x,y)=>x-y)),trigger_names:triggers.map(x=>x.name),trigger_count:triggers.length,logical};
}
async function batch(db, sqls) { return db.batch(sqls.map(sql=>db.prepare(sql))); }
function json(data,status=200){return new Response(JSON.stringify(data,null,2),{status,headers:{'content-type':'application/json'}})}
export default {
 async fetch(request,env) {
  const url=new URL(request.url);
  if(url.pathname==='/health') return json({ok:true,offline});
  if(url.pathname==='/app-check') return offline?json({status:'blocked',offline:true},503):json({status:'allowed',offline:false});
  const which=url.searchParams.get('db')||'failure';
  const db=which==='success'?env.DB_SUCCESS:which==='failure_full'?env.DB_FAILURE_FULL:which==='success_full'?env.DB_SUCCESS_FULL:env.DB_FAILURE;
  if(!db)return json({error:'unknown test DB'},400);
  if(url.pathname==='/state') return json(await currentState(db));
  if(url.pathname==='/reset-fault'){
    const before=await currentState(db);let error='';
    const faultSql=[...resetSql.slice(0,4),
      "INSERT OR REPLACE INTO analysis_snapshots(rowid,id,symbol,created_at,data) VALUES(3,'reset-tx-probe','EVIL','later','must-rollback')",
      'DELETE FROM analysis_snapshot_rowid_history',
      'INSERT INTO analysis_snapshot_rowid_history(issued_rowid) SELECT rowid FROM analysis_snapshots ORDER BY rowid',
      'INSERT INTO analysis_snapshot_rowid_history(issued_rowid) VALUES(1),(1)',
      ...resetSql.slice(4)];
    try{await batch(db,faultSql)}catch(e){error=String(e?.message||e)}
    const after=await currentState(db);
    return json({operation:'injected failure after DDL/DML; batch expected to rollback',error,offline,before_hash:before.logical_hash,after_hash:after.logical_hash,logical_rows_equal:before.logical_hash===after.logical_hash,source_rows_preserved:JSON.stringify(before.logical)===JSON.stringify(after.logical),ledger_unchanged:JSON.stringify([before.snapshot_history,before.forecast_history])===JSON.stringify([after.snapshot_history,after.forecast_history]),trigger_set_unchanged:JSON.stringify(before.trigger_names)===JSON.stringify(after.trigger_names),before,after});
  }
  if(url.pathname==='/rebaseline'){
    if(!offline)return json({error:'refuse rebaseline when not offline'},409);
    const before=await currentState(db);
    await batch(db,resetSql);
    const after=await currentState(db);
    return json({operation:'local synthetic fresh-restore-only rowid-ledger rebaseline',offline,before_hash:before.logical_hash,after_hash:after.logical_hash,logical_rows_equal:before.logical_hash===after.logical_hash,ledger_current:after.snapshotLedgerMatchesCurrent&&after.forecastLedgerMatchesCurrent,trigger_set_restored:after.trigger_count===14,after});
  }
  if(url.pathname==='/try-alias-replacements'){
    if(!offline)return json({error:'target must remain offline during integrity probe'},409);
    const initial=await currentState(db),results=[];
    for(const t of ['analysis_snapshots','forecast_records']){
      const idColumn=t==='analysis_snapshots'?'symbol':'symbol';
      const existing=await db.prepare(`SELECT rowid,id FROM ${t} ORDER BY rowid LIMIT 1`).first();
      for(const alias of ['rowid','_rowid_','oid']){
        const cols=t==='analysis_snapshots'?`${alias},id,symbol,created_at,data`:`${alias},id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data`;
        const vals=t==='analysis_snapshots'?'?,? ,?,?,?':'?,? ,?,?,?,?,?,?,?,?,?,?';
        const args=t==='analysis_snapshots'?[existing.rowid,`evil-${alias}-${crypto.randomUUID()}`,'EVIL','later','bad']:[existing.rowid,`evil-${alias}-${crypto.randomUUID()}`,'legacy-snapshot','EVIL','later',5,'evil','us','fixture','high',1,'bad'];
        let caught='';try{await db.prepare(`INSERT OR REPLACE INTO ${t}(${cols}) VALUES(${vals})`).bind(...args).run()}catch(e){caught=String(e?.message||e)}
        results.push({table:t,alias,existing_rowid:existing.rowid,rejected:!!caught,error:caught});
      }
    }
    const after=await currentState(db);
    return json({offline,results,all_rejected:results.every(x=>x.rejected),logical_rows_unchanged:initial.logical_hash===after.logical_hash,after});
  }
  if(url.pathname==='/resume-test'){
    const state=await currentState(db);
    if(!state.snapshotLedgerMatchesCurrent||!state.forecastLedgerMatchesCurrent||state.trigger_count!==14)return json({error:'validation required before resume',offline,state},409);
    offline=false;return json({offline,explicitLocalTestGateOnly:true});
  }
  if(url.pathname==='/functional-flows'){
    if(offline)return json({error:'target must be explicitly resumed after ledger validation',offline},503);
    const before=await currentState(db);
    const initialIds=['fresh-negative-s','legacy-negative','legacy-snapshot','auto-s'];
    const initialForecastIds=['fresh-negative-f','legacy-negative-f','legacy-forecast','auto-f'];
    const originalSnapshots=before.logical.analysis_snapshots.filter(x=>initialIds.includes(x.id));
    const originalForecasts=before.logical.forecast_records.filter(x=>initialForecastIds.includes(x.id));
    const flow={};
    try{
      const manualReport=reportFor('sa','P2T01.SR');
      const manualProjection=await app.recordAnalysis(db,manualReport,structuredClone(app.DEFAULT_SETTINGS));
      const manualRows=await all(db,'SELECT rowid,id,snapshot_id,symbol,horizon,model,data FROM forecast_records WHERE snapshot_id=? ORDER BY horizon',[manualProjection.snapshotId]);
      flow.manual_analysis={recorded:manualProjection.recorded,snapshotId:manualProjection.snapshotId,forecastRows:manualRows.length,rowids:manualRows.map(r=>r.rowid),modelVersion:manualProjection.version};
      if(!manualProjection.recorded||manualRows.length!==6)throw new Error('manual recordAnalysis did not append six forecast rows');
      const target=manualRows.find(r=>r.horizon===5)||manualRows[0];
      const originalForecastRecord=await db.prepare('SELECT * FROM forecast_records WHERE id=?').bind(target.id).first();
      const outcome1={state:'complete',actualDate:'2026-10-06',actualPrice:100,actualDirection:'صاعد',directionCorrect:true,priceErrorPct:1,rangeHit:true,source:'synthetic://fixture/first'};
      const outcome2={...outcome1,actualPrice:98,actualDirection:'هابط',directionCorrect:false,priceErrorPct:3,rangeHit:false,source:'synthetic://fixture/correction'};
      const rev1=await app.saveEvaluationRevision(db,target.id,outcome1,'synthetic first measurement');
      const rev2=await app.saveEvaluationRevision(db,target.id,outcome2,'synthetic correction');
      const revisionRows=await all(db,'SELECT revision,fingerprint,data FROM evaluation_revisions WHERE forecast_id=? ORDER BY revision',[target.id]);
      const outcomeRow=await db.prepare('SELECT id,evaluated_at,data FROM forecast_outcomes WHERE id=?').bind(target.id).first();
      const forecastRecordAfterCorrection=await db.prepare('SELECT * FROM forecast_records WHERE id=?').bind(target.id).first();
      flow.outcome_correction={firstSaved:rev1,correctionSaved:rev2,revisions:revisionRows.map(r=>r.revision),outcome:JSON.parse(outcomeRow.data),forecastRecordUnchanged:JSON.stringify(originalForecastRecord)===JSON.stringify(forecastRecordAfterCorrection)};
      if(!rev1||!rev2||revisionRows.length!==2||!flow.outcome_correction.forecastRecordUnchanged)throw new Error('outcome correction failed or changed issued forecast bytes');
      const deps={now:()=>FIXED_NOW,acquire:async()=> 'synthetic-local-lease',owns:async()=>true,release:async()=>{},settings:async()=>structuredClone(app.DEFAULT_SETTINGS),universe:m=>[{symbol:m==='sa'?'P2DAY.SR':'P2DAYUS',name:'Synthetic daily archive fixture'}],fetch:async(symbol)=>{const market=symbol.endsWith('.SR')?'sa':'us';return reportFor(market,symbol,'2026-10-05')},record:(journal,report,settings)=>app.recordAnalysis(journal,report,settings)};
      const daily=await app.runDailyArchive(db,deps,{cron:'manual',scheduledTime:new NativeDate(FIXED_NOW).toISOString()});
      flow.daily_archive={status:daily.status,stateSaved:daily.stateSaved,analysesRecorded:daily.analysesRecorded,forecastRowsSaved:daily.forecastRowsSaved,markets:daily.markets,errors:daily.errors};
      if(daily.status!=='completed'||!daily.stateSaved||daily.analysesRecorded!==2||daily.errors.length)throw new Error('daily archive flow did not append both synthetic market records');
      const screenReport=reportFor('sa','4190.SR');
      const run=await app.createServerScreenerArchive(db,{market:'sa',horizonSessions:5,resultCount:5,scanLimit:5,symbols:['4190.SR']});
      const projection=app.forecasts(screenReport,null,FIXED_NOW,structuredClone(app.DEFAULT_SETTINGS),[{name:'five sessions',sessions:5}]);
      const row=projection.rows[0];
      const candidate={symbol:screenReport.company.symbol,name:screenReport.company.name,exchange:screenReport.company.exchange,market:'sa',currency:screenReport.currency,price:row.price,predictedPrice:row.predictedPrice,direction:row.direction,expectedChangePct:row.expectedChangePct,range:row.range,confidence:row.confidence,dataQuality:row.dataQuality,coverage:row.coverage,sample:row.sample,independent:row.independent,riskLevel:row.riskLevel,available:row.available,reasons:row.reasons,basis:row.basis,risks:row.risks,invalidation:row.invalidation,priceTime:projection.priceTime,retrievedAt:screenReport.retrievedAt,source:screenReport.priceSource};
      flow.screener={planRunId:run.runId,projection:{available:row.available,direction:row.direction,confidence:row.confidence,price:row.price,predictedPrice:row.predictedPrice,expectedChangePct:row.expectedChangePct},sourceReadNetworkCalls:0};
      if(row.available&&candidate.direction==='صاعد'&&['متوسط','مرتفع'].includes(candidate.confidence)){
       const issued=app.issuedScreenerSnapshot(run.runId,{candidate,report:screenReport,projection});
       const result={market:'sa',horizonSessions:5,horizonName:'five sessions',scanned:1,analyzed:1,eligible:1,failed:0,excluded:0,requestedResultCount:5,returned:1,missingCount:4,candidates:[issued.candidate],failures:[],exclusionCounts:{},durationMs:0,generatedAt:new NativeDate(FIXED_NOW).toISOString(),modelVersion:projection.version,rankingPolicy:'synthetic fixture',scope:'bounded-directory-sample'};
       await db.batch([
        db.prepare('INSERT INTO analysis_snapshots(id,symbol,created_at,data) VALUES(?,?,?,?)').bind(issued.snapshotId,screenReport.company.symbol,issued.createdAt,JSON.stringify(issued.snapshot)),
        db.prepare('INSERT INTO forecast_records(id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data) VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(issued.forecastId,issued.snapshotId,screenReport.company.symbol,issued.createdAt,row.sessions,projection.version,'sa','fixture',row.confidence,1,JSON.stringify(issued.record)),
        db.prepare('INSERT INTO screener_batches(run_id,batch_index,created_at,result_json) VALUES(?,?,?,?)').bind(run.runId,0,new NativeDate(FIXED_NOW).toISOString(),JSON.stringify(result))
       ]);
       const sealed=await app.finishServerScreenerArchive(db,run.runId);
       flow.screener.appended=true;flow.screener.projection={...flow.screener.projection,available:true};flow.screener.sealed=sealed?.status||'finished';flow.screener.forecastId=issued.forecastId;
      } else {
       // Don't fabricate a winning candidate. The legitimate archive plan is tested; no source scan or candidate insert is claimed.
       flow.screener.appended=false;flow.screener.reason='Canonical synthetic fixture did not produce an available positive medium/high-confidence candidate; no candidate data was fabricated.';
      }
      const after=await currentState(db);
      const byId=(rows,id)=>rows.find(r=>r.id===id);
      const originalsUnchanged=originalSnapshots.every(r=>JSON.stringify(r)===JSON.stringify(byId(after.logical.analysis_snapshots,r.id)))&&originalForecasts.every(r=>JSON.stringify(r)===JSON.stringify(byId(after.logical.forecast_records,r.id)));
      offline=true;
      flow.final_state={logical_hash_before:before.logical_hash,logical_hash_after:after.logical_hash,appendedSnapshotCount:after.logical.analysis_snapshots.length-before.logical.analysis_snapshots.length,appendedForecastCount:after.logical.forecast_records.length-before.logical.forecast_records.length,snapshotLedgerMatchesCurrent:after.snapshotLedgerMatchesCurrent,forecastLedgerMatchesCurrent:after.forecastLedgerMatchesCurrent,trigger_count:after.trigger_count,originalRowsUnchanged:originalsUnchanged,offline};
      if(!after.snapshotLedgerMatchesCurrent||!after.forecastLedgerMatchesCurrent||after.trigger_count!==14||!originalsUnchanged)throw new Error('post-flow integrity validation failed');
      return json({status:'passed for executed canonical synthetic flows',offline,flow});
    }catch(e){offline=true;return json({status:'failed',offline,error:String(e?.message||e),flow},500)}
  }
  if(url.pathname==='/set-offline'){offline=true;return json({offline});}
  return json({error:'not found'},404);
 }
}
