PRAGMA defer_foreign_keys=TRUE;
CREATE TABLE d1_migrations(
		id         INTEGER PRIMARY KEY AUTOINCREMENT,
		name       TEXT UNIQUE,
		applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);
INSERT INTO "d1_migrations" VALUES(1,'0000_high_toad_men.sql','2026-10-04 01:17:14');
INSERT INTO "d1_migrations" VALUES(2,'0001_white_mach_iv.sql','2026-10-04 01:17:15');
INSERT INTO "d1_migrations" VALUES(3,'0002_loving_katie_power.sql','2026-10-04 01:17:15');
INSERT INTO "d1_migrations" VALUES(4,'0003_pale_skreet.sql','2026-10-04 01:17:15');
INSERT INTO "d1_migrations" VALUES(5,'0004_open_hammerhead.sql','2026-10-04 01:17:15');
INSERT INTO "d1_migrations" VALUES(6,'0005_thankful_impossible_man.sql','2026-10-04 01:17:15');
INSERT INTO "d1_migrations" VALUES(7,'0006_many_nightcrawler.sql','2026-10-04 01:17:15');
INSERT INTO "d1_migrations" VALUES(8,'0007_futuristic_ultimo.sql','2026-10-04 01:17:16');
INSERT INTO "d1_migrations" VALUES(9,'0008_faithful_venus.sql','2026-10-04 01:17:16');
INSERT INTO "d1_migrations" VALUES(10,'0009_wise_radioactive_man.sql','2026-10-04 01:17:16');
INSERT INTO "d1_migrations" VALUES(11,'0010_nervous_drax.sql','2026-10-04 01:17:16');
INSERT INTO "d1_migrations" VALUES(12,'0011_aziz_monitor_journal.sql','2026-10-04 01:17:16');
INSERT INTO "d1_migrations" VALUES(13,'0011_customer_market_watch.sql','2026-10-04 01:17:17');
INSERT INTO "d1_migrations" VALUES(14,'0012_mizan_council.sql','2026-10-04 01:17:17');
INSERT INTO "d1_migrations" VALUES(15,'0013_screener_forward_archive.sql','2026-10-04 01:17:17');
INSERT INTO "d1_migrations" VALUES(16,'0014_aziz_market_archive.sql','2026-10-04 01:17:17');
INSERT INTO "d1_migrations" VALUES(17,'0015_immutable_forecast_inputs.sql','2026-10-04 01:17:17');
INSERT INTO "d1_migrations" VALUES(18,'0016_forecast_rowid_history.sql','2026-10-04 01:17:18');
CREATE TABLE `recommendation_lock` (
	`id` integer PRIMARY KEY NOT NULL,
	`owner_id` text DEFAULT '' NOT NULL,
	`pin_hash` text NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`window_started` integer DEFAULT 0 NOT NULL
);
CREATE TABLE `admin_access` (
	`id` integer PRIMARY KEY NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`window_started` integer DEFAULT 0 NOT NULL,
	`session_hash` text DEFAULT '' NOT NULL,
	`expires_at` integer DEFAULT 0 NOT NULL
);
CREATE TABLE `site_settings` (
	`id` integer PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
CREATE TABLE `analysis_snapshots` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
);
INSERT INTO "analysis_snapshots" VALUES('legacy-snapshot','SYNTH.SR','2026-01-01','{"recordClass":"prospective-public","fixture":"legacy-snapshot"}');
INSERT INTO "analysis_snapshots" VALUES('legacy-negative','NEG.SR','2026-01-02','{"recordClass":"prospective-public","fixture":"legacy-negative"}');
INSERT INTO "analysis_snapshots" VALUES('fresh-snapshot','AUTO.SR','2026-10-04','{"recordClass":"prospective-public","fixture":"fresh-snapshot"}');
INSERT INTO "analysis_snapshots" VALUES('auto-snapshot','AUTO.SR','2026-10-04','{"recordClass":"prospective-public","fixture":"auto-snapshot"}');
CREATE TABLE `backtest_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `forecast_outcomes` (
	`id` text PRIMARY KEY NOT NULL,
	`evaluated_at` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `forecast_records` (
	`id` text PRIMARY KEY NOT NULL,
	`snapshot_id` text NOT NULL,
	`symbol` text NOT NULL,
	`created_at` text NOT NULL,
	`horizon` integer NOT NULL,
	`model` text NOT NULL,
	`market` text NOT NULL,
	`sector` text NOT NULL,
	`confidence` text NOT NULL,
	`available` integer NOT NULL,
	`data` text NOT NULL
);
INSERT INTO "forecast_records" VALUES('legacy-forecast','legacy-snapshot','SYNTH.SR','2026-01-01',5,'fixture-v1','sa','fixture','منخفض',1,'{"recordClass":"prospective-public","currency":"SAR","price":100,"predictedPrice":101,"range":[90,110],"direction":"صاعد","anchorDate":"2025-12-31","seriesBasis":{"adjustment":"unadjusted","anchorDate":"2025-12-30","anchorClose":100}}');
INSERT INTO "forecast_records" VALUES('legacy-negative-f','legacy-negative','NEG.SR','2026-01-02',5,'fixture-v1','sa','fixture','منخفض',1,'{"recordClass":"prospective-public","currency":"SAR","price":100,"predictedPrice":101,"range":[90,110],"direction":"صاعد","anchorDate":"2025-12-31","seriesBasis":{"adjustment":"unadjusted","anchorDate":"2025-12-30","anchorClose":100}}');
INSERT INTO "forecast_records" VALUES('fresh-forecast','fresh-snapshot','AUTO.SR','2026-10-04',5,'fixture-v2','sa','fixture','منخفض',1,'{"recordClass":"prospective-public","currency":"SAR","price":100,"predictedPrice":101,"range":[90,110],"direction":"صاعد","anchorDate":"2026-10-01","seriesBasis":{"adjustment":"unadjusted","anchorDate":"2026-09-30","anchorClose":100}}');
INSERT INTO "forecast_records" VALUES('auto-forecast','auto-snapshot','AUTO.SR','2026-10-04',5,'fixture-v2','sa','fixture','منخفض',1,'{"recordClass":"prospective-public","currency":"SAR","price":100,"predictedPrice":101,"range":[90,110],"direction":"صاعد","anchorDate":"2026-10-01","seriesBasis":{"adjustment":"unadjusted","anchorDate":"2026-09-30","anchorClose":100}}');
CREATE TABLE `paper_trades` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`side` text NOT NULL,
	`quantity` text NOT NULL,
	`price` text NOT NULL,
	`currency` text NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
, `portfolio_id` text DEFAULT 'legacy' NOT NULL);
CREATE TABLE `watchlist` (
	`symbol` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `paper_cash_entries` (
	`id` text PRIMARY KEY NOT NULL,
	`portfolio_id` text NOT NULL,
	`cash_type` text NOT NULL,
	`amount` text NOT NULL,
	`currency` text NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `paper_portfolio_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`portfolio_id` text NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` text NOT NULL
);
CREATE TABLE `paper_portfolios` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`currency` text NOT NULL,
	`pin_hash` text DEFAULT '' NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`window_started` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`data` text NOT NULL
);
INSERT INTO "paper_portfolios" VALUES('legacy','المحفظة السابقة','MULTI','',0,0,'2026-10-04 01:17:15','2026-10-04 01:17:15','{"id":"legacy","name":"المحفظة السابقة","currency":"MULTI"}');
CREATE TABLE `settings_history` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `source_status` (
	`id` text PRIMARY KEY NOT NULL,
	`status` text NOT NULL,
	`last_attempt` text NOT NULL,
	`last_success` text NOT NULL,
	`detail` text NOT NULL
);
CREATE TABLE `admin_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL,
	`action` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `accuracy_rows` (
	`id` text PRIMARY KEY NOT NULL,
	`run_id` text NOT NULL,
	`ordinal` integer NOT NULL,
	`symbol` text NOT NULL,
	`company` text NOT NULL,
	`state` text DEFAULT 'pending' NOT NULL,
	`forecast` text,
	`inputs` text,
	`outcome` text,
	`error` text DEFAULT '' NOT NULL,
	`updated_at` text NOT NULL,
	`lease_token` text DEFAULT '' NOT NULL,
	`lease_until` integer DEFAULT 0 NOT NULL
);
CREATE TABLE `accuracy_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `gold_budgets` (
	`id` text PRIMARY KEY NOT NULL,
	`requests` integer DEFAULT 0 NOT NULL
);
CREATE TABLE `gold_locks` (
	`id` text PRIMARY KEY NOT NULL,
	`until_ms` integer DEFAULT 0 NOT NULL,
	`token` text DEFAULT '' NOT NULL
);
CREATE TABLE `gold_state` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL,
	`updated_at` text NOT NULL
);
CREATE TABLE `evaluation_revisions` (
	`id` text PRIMARY KEY NOT NULL,
	`forecast_id` text NOT NULL,
	`revision` integer NOT NULL,
	`created_at` text NOT NULL,
	`fingerprint` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `forecast_tests` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`forecast_id` text NOT NULL,
	`group_id` text NOT NULL,
	`symbol` text NOT NULL,
	`created_at` text NOT NULL,
	`archived` integer DEFAULT 0 NOT NULL,
	`policy` text NOT NULL,
	`selection` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `recovery_manifests` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
);
INSERT INTO "recovery_manifests" VALUES('before-unified-2026-09-11','2026-10-04T01:17:16.296Z','{"checkpoint":"before-unified-2026-09-11","sourceCommit":"b175c55f502080d59849e67dc0915fd8000cb47a","tables":[{"table":"accuracy_rows","columns":["id","run_id","ordinal","symbol","company","state","forecast","inputs","outcome","error","updated_at","lease_token","lease_until"],"createSql":"CREATE TABLE `accuracy_rows` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`run_id` text NOT NULL,\n\t`ordinal` integer NOT NULL,\n\t`symbol` text NOT NULL,\n\t`company` text NOT NULL,\n\t`state` text DEFAULT ''pending'' NOT NULL,\n\t`forecast` text,\n\t`inputs` text,\n\t`outcome` text,\n\t`error` text DEFAULT '''' NOT NULL,\n\t`updated_at` text NOT NULL,\n\t`lease_token` text DEFAULT '''' NOT NULL,\n\t`lease_until` integer DEFAULT 0 NOT NULL\n)"},{"table":"accuracy_runs","columns":["id","created_at","data"],"createSql":"CREATE TABLE `accuracy_runs` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`created_at` text NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"admin_access","columns":["id","attempts","window_started","session_hash","expires_at"],"createSql":"CREATE TABLE `admin_access` (\n\t`id` integer PRIMARY KEY NOT NULL,\n\t`attempts` integer DEFAULT 0 NOT NULL,\n\t`window_started` integer DEFAULT 0 NOT NULL,\n\t`session_hash` text DEFAULT '''' NOT NULL,\n\t`expires_at` integer DEFAULT 0 NOT NULL\n)"},{"table":"admin_audit","columns":["id","created_at","action","data"],"createSql":"CREATE TABLE `admin_audit` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`created_at` text NOT NULL,\n\t`action` text NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"analysis_snapshots","columns":["id","symbol","created_at","data"],"createSql":"CREATE TABLE `analysis_snapshots` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`symbol` text NOT NULL,\n\t`created_at` text NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"backtest_runs","columns":["id","symbol","created_at","data"],"createSql":"CREATE TABLE `backtest_runs` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`symbol` text NOT NULL,\n\t`created_at` text NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"forecast_outcomes","columns":["id","evaluated_at","data"],"createSql":"CREATE TABLE `forecast_outcomes` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`evaluated_at` text NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"forecast_records","columns":["id","snapshot_id","symbol","created_at","horizon","model","market","sector","confidence","available","data"],"createSql":"CREATE TABLE `forecast_records` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`snapshot_id` text NOT NULL,\n\t`symbol` text NOT NULL,\n\t`created_at` text NOT NULL,\n\t`horizon` integer NOT NULL,\n\t`model` text NOT NULL,\n\t`market` text NOT NULL,\n\t`sector` text NOT NULL,\n\t`confidence` text NOT NULL,\n\t`available` integer NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"gold_budgets","columns":["id","requests"],"createSql":"CREATE TABLE `gold_budgets` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`requests` integer DEFAULT 0 NOT NULL\n)"},{"table":"gold_locks","columns":["id","until_ms","token"],"createSql":"CREATE TABLE `gold_locks` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`until_ms` integer DEFAULT 0 NOT NULL,\n\t`token` text DEFAULT '''' NOT NULL\n)"},{"table":"gold_state","columns":["id","data","updated_at"],"createSql":"CREATE TABLE `gold_state` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`data` text NOT NULL,\n\t`updated_at` text NOT NULL\n)"},{"table":"paper_cash_entries","columns":["id","portfolio_id","cash_type","amount","currency","created_at","data"],"createSql":"CREATE TABLE `paper_cash_entries` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`portfolio_id` text NOT NULL,\n\t`cash_type` text NOT NULL,\n\t`amount` text NOT NULL,\n\t`currency` text NOT NULL,\n\t`created_at` text NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"paper_portfolio_sessions","columns":["token_hash","portfolio_id","expires_at","created_at"],"createSql":"CREATE TABLE `paper_portfolio_sessions` (\n\t`token_hash` text PRIMARY KEY NOT NULL,\n\t`portfolio_id` text NOT NULL,\n\t`expires_at` integer NOT NULL,\n\t`created_at` text NOT NULL\n)"},{"table":"paper_portfolios","columns":["id","name","currency","pin_hash","attempts","window_started","created_at","updated_at","data"],"createSql":"CREATE TABLE `paper_portfolios` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`name` text NOT NULL,\n\t`currency` text NOT NULL,\n\t`pin_hash` text DEFAULT '''' NOT NULL,\n\t`attempts` integer DEFAULT 0 NOT NULL,\n\t`window_started` integer DEFAULT 0 NOT NULL,\n\t`created_at` text NOT NULL,\n\t`updated_at` text NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"paper_trades","columns":["id","symbol","side","quantity","price","currency","created_at","data","portfolio_id"],"createSql":"CREATE TABLE `paper_trades` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`symbol` text NOT NULL,\n\t`side` text NOT NULL,\n\t`quantity` text NOT NULL,\n\t`price` text NOT NULL,\n\t`currency` text NOT NULL,\n\t`created_at` text NOT NULL,\n\t`data` text NOT NULL\n, `portfolio_id` text DEFAULT ''legacy'' NOT NULL)"},{"table":"recommendation_lock","columns":["id","owner_id","pin_hash","attempts","window_started"],"createSql":"CREATE TABLE `recommendation_lock` (\n\t`id` integer PRIMARY KEY NOT NULL,\n\t`owner_id` text DEFAULT '''' NOT NULL,\n\t`pin_hash` text NOT NULL,\n\t`attempts` integer DEFAULT 0 NOT NULL,\n\t`window_started` integer DEFAULT 0 NOT NULL\n)"},{"table":"settings_history","columns":["id","created_at","data"],"createSql":"CREATE TABLE `settings_history` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`created_at` text NOT NULL,\n\t`data` text NOT NULL\n)"},{"table":"site_settings","columns":["id","value"],"createSql":"CREATE TABLE `site_settings` (\n\t`id` integer PRIMARY KEY NOT NULL,\n\t`value` text NOT NULL\n)"},{"table":"source_status","columns":["id","status","last_attempt","last_success","detail"],"createSql":"CREATE TABLE `source_status` (\n\t`id` text PRIMARY KEY NOT NULL,\n\t`status` text NOT NULL,\n\t`last_attempt` text NOT NULL,\n\t`last_success` text NOT NULL,\n\t`detail` text NOT NULL\n)"},{"table":"watchlist","columns":["symbol","created_at","data"],"createSql":"CREATE TABLE `watchlist` (\n\t`symbol` text PRIMARY KEY NOT NULL,\n\t`created_at` text NOT NULL,\n\t`data` text NOT NULL\n)"}]}');
CREATE TABLE `recovery_rows` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`checkpoint` text NOT NULL,
	`table_name` text NOT NULL,
	`row_data` text NOT NULL
);
INSERT INTO "recovery_rows" VALUES(1,'before-unified-2026-09-11','paper_portfolios','{"__rowid":1,"id":"legacy","name":"المحفظة السابقة","currency":"MULTI","pin_hash":"","attempts":0,"window_started":0,"created_at":"2026-10-04 01:17:15","updated_at":"2026-10-04 01:17:15","data":"{\"id\":\"legacy\",\"name\":\"المحفظة السابقة\",\"currency\":\"MULTI\"}"}');
CREATE TABLE `research_budgets` (
	`id` text PRIMARY KEY NOT NULL,
	`reserved` integer DEFAULT 0 NOT NULL,
	`reported` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL
);
CREATE TABLE `research_locks` (
	`id` text PRIMARY KEY NOT NULL,
	`token` text NOT NULL,
	`until_ms` integer NOT NULL
);
CREATE TABLE `research_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`symbol` text NOT NULL,
	`created_at` text NOT NULL,
	`data` text NOT NULL
);
CREATE TABLE `research_state` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL,
	`updated_at` text NOT NULL
);
CREATE TABLE `backtest_results` (
	`id` text PRIMARY KEY NOT NULL,
	`run_id` text NOT NULL,
	`horizon` integer NOT NULL,
	`data` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`run_id`) REFERENCES `backtest_runs`(`id`) ON UPDATE no action ON DELETE cascade
);
CREATE TABLE `source_health` (
	`source_id` text PRIMARY KEY NOT NULL,
	`state` text DEFAULT 'unknown' NOT NULL,
	`success_count` integer DEFAULT 0 NOT NULL,
	`failure_count` integer DEFAULT 0 NOT NULL,
	`avg_latency_ms` real,
	`last_success_at` text,
	`last_failure_at` text,
	`last_error` text,
	`updated_at` text NOT NULL
);
CREATE TABLE `aziz_monitor_records` (
  `id` text PRIMARY KEY NOT NULL,
  `symbol` text NOT NULL,
  `market` text NOT NULL,
  `issued_at` text NOT NULL,
  `available_at` text NOT NULL,
  `horizon` integer NOT NULL,
  `base_price` real NOT NULL,
  `currency` text NOT NULL,
  `status` text NOT NULL,
  `data` text NOT NULL
);
INSERT INTO "aziz_monitor_records" VALUES('aziz-pilot-2222-2026-09-27-h5','2222.SR','sa','2026-09-26T23:19:00.000Z','2026-09-26T23:19:00.000Z',5,25.78,'SAR','pilot_untrained','{"kind":"aziz-pilot-monitor-v1","company":"Saudi Aramco","issuedLabel":"قبل افتتاح 27 سبتمبر 2026","source":"user-supplied Yahoo historical-price screenshots","lastMarketSession":"2026-09-24","expectedClose":25.77,"closeRange":[25.60,25.94],"intradayRange":[25.50,26.05],"direction":"محايد يميل للهبوط","support":[25.64,25.52],"resistance":[25.90,26.06],"targetSession":"2026-10-01","note":"قراءة تجريبية غير مدرّبة؛ لا توصية ولا توقع ميزان."}');
INSERT INTO "aziz_monitor_records" VALUES('aziz-pilot-2222-2026-09-27-h21','2222.SR','sa','2026-09-26T23:19:00.000Z','2026-09-26T23:19:00.000Z',21,25.78,'SAR','pilot_untrained','{"kind":"aziz-pilot-monitor-v1","company":"Saudi Aramco","issuedLabel":"قبل افتتاح 27 سبتمبر 2026","source":"user-supplied Yahoo historical-price screenshots","lastMarketSession":"2026-09-24","expectedClose":25.69,"closeRange":[25.20,26.18],"direction":"محايد يميل للهبوط","targetSession":"2026-10-25","note":"قراءة تجريبية غير مدرّبة؛ لا توصية ولا توقع ميزان."}');
CREATE TABLE customer_market_watch (
  account_key TEXT NOT NULL,
  symbol TEXT NOT NULL,
  market TEXT NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  data TEXT NOT NULL,
  PRIMARY KEY (account_key, symbol)
);
CREATE TABLE market_observations (
  id TEXT PRIMARY KEY NOT NULL,
  symbol TEXT NOT NULL,
  market TEXT NOT NULL,
  observed_at TEXT NOT NULL,
  source TEXT NOT NULL,
  data TEXT NOT NULL
);
CREATE TABLE council_runs (
  id TEXT PRIMARY KEY NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  trigger TEXT NOT NULL,
  status TEXT NOT NULL,
  task TEXT NOT NULL,
  data TEXT NOT NULL
);
CREATE TABLE screener_runs (
 id TEXT PRIMARY KEY NOT NULL,
 token_hash TEXT NOT NULL,
 created_at TEXT NOT NULL,
 completed_at TEXT,
 status TEXT NOT NULL CHECK(status IN ('scanning','complete')),
 plan_json TEXT NOT NULL CHECK(json_valid(plan_json)),
 result_json TEXT CHECK(result_json IS NULL OR json_valid(result_json)),
 fingerprint TEXT
);
CREATE TABLE screener_batches (
 run_id TEXT NOT NULL REFERENCES screener_runs(id),
 batch_index INTEGER NOT NULL CHECK(batch_index >= 0),
 created_at TEXT NOT NULL,
 result_json TEXT NOT NULL CHECK(json_valid(result_json)),
 PRIMARY KEY(run_id,batch_index)
);
CREATE TABLE screener_picks (
 run_id TEXT NOT NULL REFERENCES screener_runs(id),
 market TEXT NOT NULL CHECK(market IN ('sa','us')),
 rank INTEGER NOT NULL CHECK(rank BETWEEN 1 AND 10),
 forecast_id TEXT NOT NULL REFERENCES forecast_records(id),
 PRIMARY KEY(run_id,market,rank),
 UNIQUE(run_id,forecast_id)
);
CREATE TABLE aziz_import_runs (
  id TEXT PRIMARY KEY,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  requested_batch INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('running','completed','completed_with_errors','failed')),
  provider TEXT NOT NULL,
  requested_symbols_json TEXT NOT NULL,
  result_json TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE aziz_symbols (
  id TEXT PRIMARY KEY,
  market TEXT NOT NULL CHECK(market IN ('sa','us')),
  symbol TEXT NOT NULL,
  provider_symbol TEXT NOT NULL,
  name TEXT NOT NULL,
  sector TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  replacement_for TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(market, symbol)
);
INSERT INTO "aziz_symbols" VALUES('aziz-sa-2222','sa','2222.SR','2222','أرامكو','الطاقة',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-sa-1120','sa','1120.SR','1120','مصرف الراجحي','البنوك',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-sa-2010','sa','2010.SR','2010','سابك','الصناعات والمواد',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-sa-7010','sa','7010.SR','7010','stc','الاتصالات',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-sa-2082','sa','2082.SR','2082','أكوا باور','المرافق والطاقة',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-sa-4013','sa','4013.SR','4013','د. سليمان الحبيب','الرعاية الصحية',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-us-aapl','us','AAPL','AAPL','Apple','التقنية',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-us-msft','us','MSFT','MSFT','Microsoft','البرمجيات والسحابة',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-us-nvda','us','NVDA','NVDA','NVIDIA','أشباه الموصلات',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-us-xom','us','XOM','XOM','Exxon Mobil','الطاقة',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-us-jpm','us','JPM','JPM','JPMorgan','البنوك',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
INSERT INTO "aziz_symbols" VALUES('aziz-us-jnj','us','JNJ','JNJ','Johnson & Johnson','الرعاية الصحية',1,NULL,'2026-10-04 01:17:17','2026-10-04 01:17:17');
CREATE TABLE aziz_market_datasets (
  id TEXT PRIMARY KEY,
  import_run_id TEXT NOT NULL REFERENCES aziz_import_runs(id),
  symbol_id TEXT NOT NULL REFERENCES aziz_symbols(id),
  provider TEXT NOT NULL,
  endpoint TEXT NOT NULL,
  retrieved_at TEXT NOT NULL,
  availability_basis TEXT NOT NULL CHECK(availability_basis IN ('retrieval_time_only','provider_published_time')),
  raw_sha256 TEXT NOT NULL,
  raw_payload TEXT NOT NULL,
  source_status TEXT NOT NULL,
  source_message TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE aziz_market_bars (
  id TEXT PRIMARY KEY,
  dataset_id TEXT NOT NULL REFERENCES aziz_market_datasets(id),
  symbol_id TEXT NOT NULL REFERENCES aziz_symbols(id),
  provider TEXT NOT NULL,
  session_date TEXT NOT NULL,
  opened REAL NOT NULL,
  high REAL NOT NULL,
  low REAL NOT NULL,
  closed REAL NOT NULL,
  adjusted_close REAL,
  volume REAL,
  retrieved_at TEXT NOT NULL,
  available_at TEXT,
  availability_basis TEXT NOT NULL CHECK(availability_basis IN ('retrieval_time_only','provider_published_time')),
  quality_flags_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL,
  UNIQUE(symbol_id, provider, session_date)
);
CREATE TABLE aziz_corporate_events (
  id TEXT PRIMARY KEY,
  symbol_id TEXT NOT NULL REFERENCES aziz_symbols(id),
  provider TEXT NOT NULL,
  event_type TEXT NOT NULL,
  event_date TEXT,
  announced_at TEXT,
  available_at TEXT,
  source_url TEXT,
  source_payload TEXT,
  retrieved_at TEXT NOT NULL,
  availability_basis TEXT NOT NULL CHECK(availability_basis IN ('unknown','provider_published_time')),
  created_at TEXT NOT NULL
);
CREATE TABLE analysis_snapshot_rowid_history (
  issued_rowid INTEGER PRIMARY KEY NOT NULL
);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(-5);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(-1);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(1);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(2);
CREATE TABLE forecast_record_rowid_history (
  issued_rowid INTEGER PRIMARY KEY NOT NULL
);
INSERT INTO "forecast_record_rowid_history" VALUES(-5);
INSERT INTO "forecast_record_rowid_history" VALUES(-1);
INSERT INTO "forecast_record_rowid_history" VALUES(1);
INSERT INTO "forecast_record_rowid_history" VALUES(2);
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('d1_migrations',18);
INSERT INTO "sqlite_sequence" VALUES('recovery_rows',1);
CREATE INDEX `idx_forecast_symbol_date` ON `forecast_records` (`symbol`,`created_at`);
CREATE INDEX `idx_forecast_date` ON `forecast_records` (`created_at`);
CREATE INDEX `idx_trades_symbol_currency` ON `paper_trades` (`symbol`,`currency`);
CREATE INDEX `idx_cash_portfolio_currency` ON `paper_cash_entries` (`portfolio_id`,`currency`);
CREATE INDEX `idx_portfolio_sessions_expiry` ON `paper_portfolio_sessions` (`expires_at`);
CREATE INDEX `idx_portfolios_name` ON `paper_portfolios` (`name`);
CREATE INDEX `idx_trades_portfolio_currency` ON `paper_trades` (`portfolio_id`,`currency`);
CREATE INDEX `idx_admin_audit_date` ON `admin_audit` (`created_at`);
CREATE INDEX `idx_accuracy_rows_run_ordinal` ON `accuracy_rows` (`run_id`,`ordinal`);
CREATE INDEX `idx_accuracy_runs_created` ON `accuracy_runs` (`created_at`);
CREATE INDEX `idx_evaluation_forecast_revision` ON `evaluation_revisions` (`forecast_id`,`revision`);
CREATE INDEX `idx_tests_owner_date` ON `forecast_tests` (`owner`,`created_at`);
CREATE INDEX `idx_research_symbol_date` ON `research_runs` (`symbol`,`created_at`);
CREATE UNIQUE INDEX idx_tests_unique ON forecast_tests(owner,forecast_id,policy);
CREATE UNIQUE INDEX idx_evaluation_unique ON evaluation_revisions(forecast_id,revision);
CREATE INDEX `idx_backtest_runs_created` ON `backtest_runs` (`created_at`);
CREATE INDEX `idx_forecast_outcomes_eval` ON `forecast_outcomes` (`evaluated_at`);
CREATE INDEX `idx_forecast_symbol_horizon` ON `forecast_records` (`symbol`,`horizon`);
CREATE INDEX `idx_backtest_results_run` ON `backtest_results` (`run_id`);
CREATE UNIQUE INDEX `idx_backtest_results_run_horizon` ON `backtest_results` (`run_id`,`horizon`);
CREATE INDEX `idx_aziz_monitor_symbol_issued` ON `aziz_monitor_records` (`symbol`,`issued_at`);
CREATE INDEX `idx_aziz_monitor_horizon` ON `aziz_monitor_records` (`horizon`);
CREATE INDEX idx_customer_market_watch_symbol ON customer_market_watch(symbol);
CREATE UNIQUE INDEX idx_market_observations_dedupe ON market_observations(symbol, observed_at, source);
CREATE INDEX idx_market_observations_symbol_time ON market_observations(symbol, observed_at);
CREATE INDEX council_runs_created_idx
  ON council_runs(created_at DESC);
CREATE INDEX council_runs_status_idx
  ON council_runs(status, created_at DESC);
CREATE INDEX screener_runs_created ON screener_runs(created_at DESC);
CREATE INDEX screener_picks_forecast ON screener_picks(forecast_id);
CREATE INDEX aziz_bars_symbol_session_idx ON aziz_market_bars(symbol_id, session_date);
CREATE INDEX aziz_datasets_symbol_retrieved_idx ON aziz_market_datasets(symbol_id, retrieved_at);
CREATE INDEX aziz_events_symbol_available_idx ON aziz_corporate_events(symbol_id, available_at);
CREATE TRIGGER backtest_results_after_insert AFTER INSERT ON backtest_runs BEGIN
 INSERT OR IGNORE INTO backtest_results(id,run_id,horizon,data,created_at)
 SELECT NEW.id || ':' || json_extract(j.value,'$.horizon'),NEW.id,json_extract(j.value,'$.horizon'),j.value,NEW.created_at
 FROM json_each(CASE WHEN json_valid(NEW.data) THEN CASE json_extract(NEW.data,'$.kind') WHEN 'mizan-issued-forecast-audit-v1' THEN CASE WHEN json_type(NEW.data,'$.byHorizon')='array' THEN json_extract(NEW.data,'$.byHorizon') ELSE '[]' END WHEN 'mizan-issued-forecast-windows-v1' THEN CASE WHEN json_type(NEW.data,'$.aggregate.byHorizon')='array' THEN json_extract(NEW.data,'$.aggregate.byHorizon') ELSE '[]' END ELSE '[]' END ELSE '[]' END) j
 WHERE j.type='object' AND json_type(j.value,'$.horizon')='integer' AND json_extract(j.value,'$.horizon') IN (1,5,21,63,126,252);
END;
CREATE TRIGGER backtest_results_after_update AFTER UPDATE OF data ON backtest_runs BEGIN
 DELETE FROM backtest_results WHERE run_id=NEW.id;
 INSERT OR IGNORE INTO backtest_results(id,run_id,horizon,data,created_at)
 SELECT NEW.id || ':' || json_extract(j.value,'$.horizon'),NEW.id,json_extract(j.value,'$.horizon'),j.value,NEW.created_at
 FROM json_each(CASE WHEN json_valid(NEW.data) THEN CASE json_extract(NEW.data,'$.kind') WHEN 'mizan-issued-forecast-audit-v1' THEN CASE WHEN json_type(NEW.data,'$.byHorizon')='array' THEN json_extract(NEW.data,'$.byHorizon') ELSE '[]' END WHEN 'mizan-issued-forecast-windows-v1' THEN CASE WHEN json_type(NEW.data,'$.aggregate.byHorizon')='array' THEN json_extract(NEW.data,'$.aggregate.byHorizon') ELSE '[]' END ELSE '[]' END ELSE '[]' END) j
 WHERE j.type='object' AND json_type(j.value,'$.horizon')='integer' AND json_extract(j.value,'$.horizon') IN (1,5,21,63,126,252);
END;
CREATE TRIGGER screener_run_sealed BEFORE UPDATE ON screener_runs WHEN OLD.status='complete' BEGIN SELECT RAISE(ABORT,'screener_run_is_immutable'); END;
CREATE TRIGGER screener_run_keep BEFORE DELETE ON screener_runs BEGIN SELECT RAISE(ABORT,'screener_run_is_immutable'); END;
CREATE TRIGGER screener_batch_fixed BEFORE UPDATE ON screener_batches BEGIN SELECT RAISE(ABORT,'screener_batch_is_immutable'); END;
CREATE TRIGGER screener_batch_keep BEFORE DELETE ON screener_batches BEGIN SELECT RAISE(ABORT,'screener_batch_is_immutable'); END;
CREATE TRIGGER screener_pick_fixed BEFORE UPDATE ON screener_picks BEGIN SELECT RAISE(ABORT,'screener_pick_is_immutable'); END;
CREATE TRIGGER screener_pick_keep BEFORE DELETE ON screener_picks BEGIN SELECT RAISE(ABORT,'screener_pick_is_immutable'); END;
CREATE TRIGGER screener_forecast_fixed BEFORE UPDATE ON forecast_records WHEN OLD.snapshot_id LIKE 'screener:%' BEGIN SELECT RAISE(ABORT,'issued_screener_forecast_is_immutable'); END;
CREATE TRIGGER screener_forecast_keep BEFORE DELETE ON forecast_records WHEN OLD.snapshot_id LIKE 'screener:%' BEGIN SELECT RAISE(ABORT,'issued_screener_forecast_is_immutable'); END;
CREATE TRIGGER screener_input_fixed BEFORE UPDATE ON analysis_snapshots WHEN OLD.id LIKE 'screener:%' BEGIN SELECT RAISE(ABORT,'issued_screener_input_is_immutable'); END;
CREATE TRIGGER screener_input_keep BEFORE DELETE ON analysis_snapshots WHEN OLD.id LIKE 'screener:%' BEGIN SELECT RAISE(ABORT,'issued_screener_input_is_immutable'); END;
CREATE TRIGGER analysis_snapshot_no_id_reuse
BEFORE INSERT ON analysis_snapshots
WHEN EXISTS (SELECT 1 FROM analysis_snapshots WHERE id = NEW.id)
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_id_already_issued');
END;
CREATE TRIGGER analysis_snapshot_immutable_update
BEFORE UPDATE ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_immutable_delete
BEFORE DELETE ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_is_immutable');
END;
CREATE TRIGGER forecast_record_no_id_reuse
BEFORE INSERT ON forecast_records
WHEN EXISTS (SELECT 1 FROM forecast_records WHERE id = NEW.id)
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_id_already_issued');
END;
CREATE TRIGGER forecast_record_immutable_update
BEFORE UPDATE ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_is_immutable');
END;
CREATE TRIGGER forecast_record_immutable_delete
BEFORE DELETE ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_insert_guard
BEFORE INSERT ON analysis_snapshot_rowid_history
WHEN EXISTS (
  SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = NEW.issued_rowid
)
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_already_issued');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_update_guard
BEFORE UPDATE ON analysis_snapshot_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_history_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_delete_guard
BEFORE DELETE ON analysis_snapshot_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_history_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_track_rowid_after_insert
AFTER INSERT ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_already_issued')
  WHERE EXISTS (
    SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = NEW.rowid
  );
  INSERT INTO analysis_snapshot_rowid_history (issued_rowid) VALUES (NEW.rowid);
END;
CREATE TRIGGER forecast_record_rowid_history_insert_guard
BEFORE INSERT ON forecast_record_rowid_history
WHEN EXISTS (
  SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = NEW.issued_rowid
)
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_already_issued');
END;
CREATE TRIGGER forecast_record_rowid_history_update_guard
BEFORE UPDATE ON forecast_record_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_history_is_immutable');
END;
CREATE TRIGGER forecast_record_rowid_history_delete_guard
BEFORE DELETE ON forecast_record_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_history_is_immutable');
END;
CREATE TRIGGER forecast_record_track_rowid_after_insert
AFTER INSERT ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_already_issued')
  WHERE EXISTS (
    SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = NEW.rowid
  );
  INSERT INTO forecast_record_rowid_history (issued_rowid) VALUES (NEW.rowid);
END;