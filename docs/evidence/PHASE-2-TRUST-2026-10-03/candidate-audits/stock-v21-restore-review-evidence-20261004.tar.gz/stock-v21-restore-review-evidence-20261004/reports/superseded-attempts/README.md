# Earlier failed-fixture attempts (preserved verbatim)

- `functional-flows-report.json` is the initial narrow two-table import attempt. It correctly failed when the canonical outcome-correction flow reached missing `forecast_outcomes`; it did not establish application-flow compatibility.
- `full-functional-flows-report.json` is the earlier full-schema run whose frozen fixture time fell before the Saudi session-close condition. It is retained to make the correction traceable.
- The later aligned full-schema run is `../final/full-final-flows-report.json`.

These reports are historical test artifacts. They do not supersede the final report or change the rollout hold.
