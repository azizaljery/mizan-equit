# Independent review: P2-04 v2.1 restore-only prototype

## Verdict

The bounded ledger-repair mechanics passed local synthetic D1 checks. The v2 candidate remains **NOT_READY / HOLD for rollout**. This review does not approve a production restore, migration, merge, or deployment.

## Tested scope and findings

- Reviewed the full-schema Wrangler 4.92.0 local export/import and the test-only D1 rebaseline sequence. Synthetic source rowids `[-5, -1, 1, 2]` became `[1, 2, 3, 4]` on import while the exported history values stayed stale.
- The injected failure occurred after guard DDL and a source-row replacement; the D1 batch rolled back the source rows, both history ledgers, and all 14 triggers. The successful reset preserved the protected tables' logical-row hash and restored exact live-rowid/ledger parity.
- All six `rowid`, `_rowid_`, and `oid` replacement probes were rejected.
- After rebaseline, canonical synthetic `recordAnalysis`, two outcome revisions, and Saudi and US daily archive appends passed. Existing protected rows stayed unchanged. The screener plan path ran without network access, but the synthetic projection was neutral/low-confidence, so no eligible forecast was appended. Screener forecast append/sealing remains untested; no eligible candidate was fabricated.

## Remaining acceptance gaps

1. The offline flag and resume gate exist only in the temporary test Worker. They do not quiesce the actual application or scheduled writers. The harness resume check verifies ledger parity and trigger count, but does not enforce the pre/post logical-hash comparison. An owner-run, durable maintenance/quiescence gate and explicit integrity/resume checks are proposed prerequisites, not implemented enforcement.
2. A legitimate eligible screener candidate still needs to exercise the real forecast append and archive-sealing flow against the rebaselined database.

## Reviewed evidence and hashes

- Frozen review packet: `review-packet-v2.1.json`, SHA-256 `75faed7744fc383e825acc8bc1fc3bb0961b11a5ef02ba8534ad762bfd2b899b`.
- Frozen README: `README.md`, SHA-256 `4c6e7a000e57706b8559e152b5a63a23ee11e4a85ad0bd6943bfc388576690ff`.
- Candidate migration `../candidate/mizan-v45/drizzle/0016_forecast_rowid_history.sql`, SHA-256 `c237b29922f28ece3239bb8347f5d4a0f5d18719c108c1bec75c9956eb8c84af`.
- Test-only harness `worker.mjs`, SHA-256 `ec274b8d91e49cd1d8b9bbd249f276c0752b17990e770d99aab0e34d570dd726`.
- Fault rollback report `full-final-fault-report.json`, SHA-256 `bd65f352fa53dabd20e1cb2bcf259d48e3b311f320663c26f6810c204be73302`.
- Successful rebaseline report `full-final-rebaseline-report.json`, SHA-256 `5b5cb9a979991055059a4955acbc93e8693c11036f8f36a6bb16d44fb3e40c9a`.
- Alias rejection report `full-final-alias-report.json`, SHA-256 `50861a8b95cf8ecbda4a5b8a6dc29b0d0546fb2dc1d2730e69378620e793d3a0`.
- Final flow report `full-final-flows-report.json`, SHA-256 `28cde67908333453611a06553f9fa23dd85224f3d317c565683c4d89740782b3`.
- Protected logical-row hash before and after successful rebaseline: `488109875ab576860c0201202dd20f7a245979e2acd41b1bf0a1428eb866bc16`.

This is a local independent review of the bounded prototype only. Production quiescence, restore-chain behavior, and the missing screener append coverage remain outside what these results establish.
