PRAGMA defer_foreign_keys=TRUE;
CREATE TABLE analysis_snapshots(id TEXT PRIMARY KEY NOT NULL,symbol TEXT NOT NULL,created_at TEXT NOT NULL,data TEXT NOT NULL);
INSERT INTO "analysis_snapshots" VALUES('fresh-negative-s','NEG.SR','2026-10-04','new');
INSERT INTO "analysis_snapshots" VALUES('legacy-negative','NEG.SR','2026-01-02','negative-original');
INSERT INTO "analysis_snapshots" VALUES('legacy-snapshot','SYNTH.SR','2026-01-01','original');
INSERT INTO "analysis_snapshots" VALUES('auto-s','AUTO.SR','2026-10-04','new');
CREATE TABLE forecast_records(id TEXT PRIMARY KEY NOT NULL,snapshot_id TEXT NOT NULL,symbol TEXT NOT NULL,created_at TEXT NOT NULL,horizon INTEGER NOT NULL,model TEXT NOT NULL,market TEXT NOT NULL,sector TEXT NOT NULL,confidence TEXT NOT NULL,available INTEGER NOT NULL,data TEXT NOT NULL);
INSERT INTO "forecast_records" VALUES('fresh-negative-f','legacy-snapshot','NEG.SR','2026-10-04',5,'fixture-v2','sa','fixture','منخفض',1,'new');
INSERT INTO "forecast_records" VALUES('legacy-negative-f','legacy-negative','NEG.SR','2026-01-02',5,'fixture-v1','sa','fixture','منخفض',1,'negative-original');
INSERT INTO "forecast_records" VALUES('legacy-forecast','legacy-snapshot','SYNTH.SR','2026-01-01',5,'fixture-v1','sa','fixture','منخفض',1,'original');
INSERT INTO "forecast_records" VALUES('auto-f','legacy-snapshot','AUTO.SR','2026-10-04',5,'fixture-v2','sa','fixture','منخفض',1,'new');
CREATE TABLE analysis_snapshot_rowid_history (
  issued_rowid INTEGER PRIMARY KEY NOT NULL
);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(-5);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(-1);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(1);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(2);
CREATE TABLE forecast_record_rowid_history (
  issued_rowid INTEGER PRIMARY KEY NOT NULL
);
INSERT INTO "forecast_record_rowid_history" VALUES(-5);
INSERT INTO "forecast_record_rowid_history" VALUES(-1);
INSERT INTO "forecast_record_rowid_history" VALUES(1);
INSERT INTO "forecast_record_rowid_history" VALUES(2);
CREATE TRIGGER analysis_snapshot_no_id_reuse
BEFORE INSERT ON analysis_snapshots
WHEN EXISTS (SELECT 1 FROM analysis_snapshots WHERE id = NEW.id)
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_id_already_issued');
END;
CREATE TRIGGER analysis_snapshot_immutable_update
BEFORE UPDATE ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_immutable_delete
BEFORE DELETE ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_is_immutable');
END;
CREATE TRIGGER forecast_record_no_id_reuse
BEFORE INSERT ON forecast_records
WHEN EXISTS (SELECT 1 FROM forecast_records WHERE id = NEW.id)
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_id_already_issued');
END;
CREATE TRIGGER forecast_record_immutable_update
BEFORE UPDATE ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_is_immutable');
END;
CREATE TRIGGER forecast_record_immutable_delete
BEFORE DELETE ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_insert_guard
BEFORE INSERT ON analysis_snapshot_rowid_history
WHEN EXISTS (
  SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = NEW.issued_rowid
)
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_already_issued');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_update_guard
BEFORE UPDATE ON analysis_snapshot_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_history_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_delete_guard
BEFORE DELETE ON analysis_snapshot_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_history_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_track_rowid_after_insert
AFTER INSERT ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_already_issued')
  WHERE EXISTS (
    SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = NEW.rowid
  );
  INSERT INTO analysis_snapshot_rowid_history (issued_rowid) VALUES (NEW.rowid);
END;
CREATE TRIGGER forecast_record_rowid_history_insert_guard
BEFORE INSERT ON forecast_record_rowid_history
WHEN EXISTS (
  SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = NEW.issued_rowid
)
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_already_issued');
END;
CREATE TRIGGER forecast_record_rowid_history_update_guard
BEFORE UPDATE ON forecast_record_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_history_is_immutable');
END;
CREATE TRIGGER forecast_record_rowid_history_delete_guard
BEFORE DELETE ON forecast_record_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_history_is_immutable');
END;
CREATE TRIGGER forecast_record_track_rowid_after_insert
AFTER INSERT ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_already_issued')
  WHERE EXISTS (
    SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = NEW.rowid
  );
  INSERT INTO forecast_record_rowid_history (issued_rowid) VALUES (NEW.rowid);
END;