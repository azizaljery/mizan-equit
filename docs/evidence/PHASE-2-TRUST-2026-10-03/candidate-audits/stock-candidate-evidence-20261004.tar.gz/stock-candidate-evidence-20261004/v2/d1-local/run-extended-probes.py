import json,os,re,subprocess,pathlib,hashlib
w=pathlib.Path('/tmp/P2-TRUST-LOCAL-FORECAST-2026-10-04-IMMUTABILITY-V2'); repo=w/'candidate/mizan-v45'; d=w/'d1-local'; cli=repo/'node_modules/.bin/wrangler'
env=os.environ.copy();env.update({'HOME':str(w/'wrangler-home'),'XDG_CONFIG_HOME':str(w/'wrangler-config'),'WRANGLER_LOG_PATH':str(d/'wrangler.log'),'WRANGLER_WRITE_LOGS':'false','MINIFLARE_REGISTRY_PATH':str(d/'miniflare-registry')})
probes=[
 ('analysis_snapshot_multirow_replace_rollback',"INSERT OR REPLACE INTO analysis_snapshots(rowid,id,symbol,created_at,data) VALUES(10,'multi-new-s','NEW','later','first'),(1,'multi-evil-s','EVIL','later','second')",'analysis_snapshot_rowid_already_issued'),
 ('forecast_record_multirow_replace_rollback',"INSERT OR REPLACE INTO forecast_records(rowid,id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data) VALUES(10,'multi-new-f','legacy-snapshot','NEW','later',5,'v2','sa','fixture','متوسط',1,'first'),(1,'multi-evil-f','legacy-snapshot','EVIL','later',252,'bad','us','fake','مرتفع',1,'second')",'forecast_record_rowid_already_issued'),
 ('analysis_snapshot_rowid_upsert',"INSERT INTO analysis_snapshots(rowid,id,symbol,created_at,data) VALUES(1,'upsert-new-s','EVIL','later','bad') ON CONFLICT DO UPDATE SET id=excluded.id,symbol=excluded.symbol,data=excluded.data",'analysis_snapshot_is_immutable'),
 ('forecast_record_rowid_upsert',"INSERT INTO forecast_records(rowid,id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data) VALUES(1,'upsert-new-f','legacy-snapshot','EVIL','later',252,'bad','us','fake','مرتفع',1,'bad') ON CONFLICT DO UPDATE SET id=excluded.id,symbol=excluded.symbol,data=excluded.data",'forecast_record_is_immutable'),
]
results=[]
for name,sql,expected in probes:
 p=subprocess.run([str(cli),'d1','execute','DB','--local','--command',sql,'--config',str(d/'wrangler.jsonc'),'--persist-to',str(d/'state')],cwd=repo,env=env,text=True,capture_output=True)
 clean=lambda s:re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',s)
 stdout,stderr=clean(p.stdout),clean(p.stderr); observed=expected in stdout+stderr
 results.append({'name':name,'exit_code':p.returncode,'expected_error':expected,'error_observed':observed,'stdout':stdout[-500:],'stderr':stderr[-500:]})
 if p.returncode==0 or not observed: raise SystemExit(json.dumps({'failed':name,'result':results[-1]},ensure_ascii=False,indent=2))
q=subprocess.run([str(cli),'d1','execute','DB','--local','--file',str(d/'final.sql'),'--config',str(d/'wrangler.jsonc'),'--persist-to',str(d/'state'),'--json'],cwd=repo,env=env,text=True,capture_output=True)
if q.returncode: raise SystemExit(q.stderr)
(d/'final-extended.json').write_text(q.stdout)
records=json.loads(q.stdout)
idsS={r['id'] for r in records[0]['results']}; idsF={r['id'] for r in records[1]['results']}
assert not any(x.startswith(('multi-','upsert-')) for x in idsS|idsF)
assert {(r['rowid'],r['id'],r['data']) for r in records[0]['results'] if r['id'] in {'legacy-negative','legacy-snapshot'}}=={(-1,'legacy-negative','negative-original'),(1,'legacy-snapshot','original')}
assert {(r['rowid'],r['id'],r['data']) for r in records[1]['results'] if r['id'] in {'legacy-negative-f','legacy-forecast'}}=={(-1,'legacy-negative-f','negative-original'),(1,'legacy-forecast','original')}
report={'runtime':'Wrangler 4.92.0 local D1 only; synthetic DB, no --remote flag','recursive_triggers_default':0,'probes':results,'all_multirow_and_upsert_rejected':True,'original_rows_and_payloads_preserved':True,'post_probe_query_sha256':hashlib.sha256(q.stdout.encode()).hexdigest(),'post_probe_query':str(d/'final-extended.json')}
(d/'rowid-d1-extended-probe.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(results),'local D1 multirow/UPSERT probes; row contents unchanged')
