import json,os,re,subprocess,pathlib,hashlib
w=pathlib.Path('/tmp/P2-TRUST-LOCAL-FORECAST-2026-10-04-IMMUTABILITY-V2'); repo=w/'candidate/mizan-v45'; d=w/'d1-local'; cli=repo/'node_modules/.bin/wrangler'
env=os.environ.copy();env.update({'HOME':str(w/'wrangler-home'),'XDG_CONFIG_HOME':str(w/'wrangler-config'),'WRANGLER_LOG_PATH':str(d/'wrangler.log'),'WRANGLER_WRITE_LOGS':'false','MINIFLARE_REGISTRY_PATH':str(d/'miniflare-registry')})
probes=[
 ('analysis_snapshot_rowid_replace',"INSERT OR REPLACE INTO analysis_snapshots(rowid,id,symbol,created_at,data) VALUES(1,'evil-s','EVIL','later','changed')",'analysis_snapshot_rowid_already_issued'),
 ('forecast_record_rowid_replace',"INSERT OR REPLACE INTO forecast_records(rowid,id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data) VALUES(1,'evil-f','legacy-snapshot','EVIL','later',252,'fake','us','fake','مرتفع',1,'changed')",'forecast_record_rowid_already_issued'),
]
results=[]
for name,sql,expected in probes:
 p=subprocess.run([str(cli),'d1','execute','DB','--local','--command',sql,'--config',str(d/'wrangler.jsonc'),'--persist-to',str(d/'state')],cwd=repo,env=env,text=True,capture_output=True)
 scrub=lambda s:re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',s)
 stdout,stderr=scrub(p.stdout),scrub(p.stderr)
 observed=expected in stdout+stderr
 results.append({'name':name,'exit_code':p.returncode,'expected_error':expected,'error_observed':observed,'stdout':stdout[-700:],'stderr':stderr[-700:]})
 if p.returncode==0 or not observed: raise SystemExit(json.dumps({'failed':name,'result':results[-1]},ensure_ascii=False,indent=2))
q=subprocess.run([str(cli),'d1','execute','DB','--local','--file',str(d/'final.sql'),'--config',str(d/'wrangler.jsonc'),'--persist-to',str(d/'state'),'--json'],cwd=repo,env=env,text=True,capture_output=True)
if q.returncode: raise SystemExit(q.stderr)
(d/'final-post-probes.json').write_text(q.stdout)
records=json.loads(q.stdout)
expected_ids={'legacy-negative','legacy-snapshot','auto-s','fresh-negative-s'}
assert {r['id'] for r in records[0]['results']}==expected_ids
expected_forecasts={'legacy-negative-f','legacy-forecast','auto-f','fresh-negative-f'}
assert {r['id'] for r in records[1]['results']}==expected_forecasts
assert all(r['data'] in {'original','negative-original','new'} for table in records[:2] for r in table['results'])
report={'runtime':'Wrangler 4.92.0 local D1 only; config name and DB ID are synthetic, no --remote flag','recursive_triggers_default':0,'migrations_applied':['0015_immutable_forecast_inputs.sql','0016_forecast_rowid_history.sql'],'pre-existing_legacy_rows_seeded':[{'rowid':1,'id':'legacy-snapshot','data':'original'},{'rowid':-1,'id':'legacy-negative','data':'negative-original'}],'verified_ordinary_auto_rowid_append_after_negative_legacy_rows':True,'verified_new_negative_rowids_are_tracked':True,'probes':results,'post_probe_rows_hash':hashlib.sha256(q.stdout.encode()).hexdigest(),'post_probe_query':str(d/'final-post-probes.json'),'post_probe_snapshot_rows':records[0]['results'],'post_probe_forecast_rows':records[1]['results'],'no_production_access_or_writes':True}
(d/'rowid-replace-probe.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS: both D1 rowid REPLACE attempts rejected; original payloads and IDs preserved')
