INSERT INTO analysis_snapshots(id,symbol,created_at,data) VALUES('auto-s','AUTO.SR','2026-10-04','new');
INSERT INTO forecast_records(id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data) VALUES('auto-f','legacy-snapshot','AUTO.SR','2026-10-04',5,'fixture-v2','sa','fixture','منخفض',1,'new');
INSERT INTO analysis_snapshots(rowid,id,symbol,created_at,data) VALUES(-5,'fresh-negative-s','NEG.SR','2026-10-04','new');
INSERT INTO forecast_records(rowid,id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data) VALUES(-5,'fresh-negative-f','legacy-snapshot','NEG.SR','2026-10-04',5,'fixture-v2','sa','fixture','منخفض',1,'new');
