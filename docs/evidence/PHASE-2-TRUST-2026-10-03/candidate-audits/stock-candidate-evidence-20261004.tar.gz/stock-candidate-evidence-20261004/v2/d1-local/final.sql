SELECT rowid,id,symbol,created_at,data FROM analysis_snapshots ORDER BY rowid;
SELECT rowid,id,symbol,created_at,horizon,model,data FROM forecast_records ORDER BY rowid;
SELECT issued_rowid FROM analysis_snapshot_rowid_history ORDER BY issued_rowid;
SELECT issued_rowid FROM forecast_record_rowid_history ORDER BY issued_rowid;
