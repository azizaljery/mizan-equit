BEGIN TRANSACTION;
CREATE TABLE analysis_snapshot_rowid_history (
  issued_rowid INTEGER PRIMARY KEY NOT NULL
);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(-9);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(4);
INSERT INTO "analysis_snapshot_rowid_history" VALUES(100);
CREATE TABLE analysis_snapshots (id TEXT PRIMARY KEY, symbol TEXT);
INSERT INTO "analysis_snapshots" VALUES('analysis_snapshots--9','ORIGINAL');
INSERT INTO "analysis_snapshots" VALUES('analysis_snapshots-4','ORIGINAL');
INSERT INTO "analysis_snapshots" VALUES('analysis_snapshots-100','ORIGINAL');
CREATE TABLE forecast_record_rowid_history (
  issued_rowid INTEGER PRIMARY KEY NOT NULL
);
INSERT INTO "forecast_record_rowid_history" VALUES(-9);
INSERT INTO "forecast_record_rowid_history" VALUES(4);
INSERT INTO "forecast_record_rowid_history" VALUES(100);
CREATE TABLE forecast_records (id TEXT PRIMARY KEY, symbol TEXT);
INSERT INTO "forecast_records" VALUES('forecast_records--9','ORIGINAL');
INSERT INTO "forecast_records" VALUES('forecast_records-4','ORIGINAL');
INSERT INTO "forecast_records" VALUES('forecast_records-100','ORIGINAL');
CREATE TRIGGER analysis_snapshot_no_id_reuse
BEFORE INSERT ON analysis_snapshots
WHEN EXISTS (SELECT 1 FROM analysis_snapshots WHERE id = NEW.id)
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_id_already_issued');
END;
CREATE TRIGGER analysis_snapshot_immutable_update
BEFORE UPDATE ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_immutable_delete
BEFORE DELETE ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_is_immutable');
END;
CREATE TRIGGER forecast_record_no_id_reuse
BEFORE INSERT ON forecast_records
WHEN EXISTS (SELECT 1 FROM forecast_records WHERE id = NEW.id)
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_id_already_issued');
END;
CREATE TRIGGER forecast_record_immutable_update
BEFORE UPDATE ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_is_immutable');
END;
CREATE TRIGGER forecast_record_immutable_delete
BEFORE DELETE ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_insert_guard
BEFORE INSERT ON analysis_snapshot_rowid_history
WHEN EXISTS (
  SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = NEW.issued_rowid
)
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_already_issued');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_update_guard
BEFORE UPDATE ON analysis_snapshot_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_history_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_rowid_history_delete_guard
BEFORE DELETE ON analysis_snapshot_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_history_is_immutable');
END;
CREATE TRIGGER analysis_snapshot_track_rowid_after_insert
AFTER INSERT ON analysis_snapshots
BEGIN
  SELECT RAISE(ABORT, 'analysis_snapshot_rowid_already_issued')
  WHERE EXISTS (
    SELECT 1 FROM analysis_snapshot_rowid_history WHERE issued_rowid = NEW.rowid
  );
  INSERT INTO analysis_snapshot_rowid_history (issued_rowid) VALUES (NEW.rowid);
END;
CREATE TRIGGER forecast_record_rowid_history_insert_guard
BEFORE INSERT ON forecast_record_rowid_history
WHEN EXISTS (
  SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = NEW.issued_rowid
)
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_already_issued');
END;
CREATE TRIGGER forecast_record_rowid_history_update_guard
BEFORE UPDATE ON forecast_record_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_history_is_immutable');
END;
CREATE TRIGGER forecast_record_rowid_history_delete_guard
BEFORE DELETE ON forecast_record_rowid_history
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_history_is_immutable');
END;
CREATE TRIGGER forecast_record_track_rowid_after_insert
AFTER INSERT ON forecast_records
BEGIN
  SELECT RAISE(ABORT, 'forecast_record_rowid_already_issued')
  WHERE EXISTS (
    SELECT 1 FROM forecast_record_rowid_history WHERE issued_rowid = NEW.rowid
  );
  INSERT INTO forecast_record_rowid_history (issued_rowid) VALUES (NEW.rowid);
END;
COMMIT;
