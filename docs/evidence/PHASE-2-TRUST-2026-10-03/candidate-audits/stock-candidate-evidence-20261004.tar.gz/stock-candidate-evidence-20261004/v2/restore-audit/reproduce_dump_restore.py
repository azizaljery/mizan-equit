import json, pathlib, sqlite3, hashlib, datetime
base=pathlib.Path('/tmp/P2-TRUST-LOCAL-FORECAST-2026-10-04-IMMUTABILITY-V2')
candidate=base/'candidate/mizan-v45'

def execute_migration(conn, name):
    sql=(candidate/'drizzle'/name).read_text()
    for stmt in sql.split('--> statement-breakpoint'):
        stmt=stmt.strip()
        if stmt:
            conn.execute(stmt)

def attempt(conn, sql, params=()):
    try:
        conn.execute(sql, params)
        return {'accepted': True, 'error': None}
    except sqlite3.DatabaseError as exc:
        return {'accepted': False, 'error': str(exc)}

def setup():
    c=sqlite3.connect(':memory:')
    c.execute('PRAGMA recursive_triggers=OFF')
    c.execute('CREATE TABLE analysis_snapshots (id TEXT PRIMARY KEY, symbol TEXT)')
    c.execute('CREATE TABLE forecast_records (id TEXT PRIMARY KEY, symbol TEXT)')
    execute_migration(c,'0015_immutable_forecast_inputs.sql')
    execute_migration(c,'0016_forecast_rowid_history.sql')
    for table in ('analysis_snapshots','forecast_records'):
        for n in (-9,4,100):
            c.execute(f'INSERT INTO {table}(rowid,id,symbol) VALUES(?,?,?)',(n,f'{table}-{n}','ORIGINAL'))
    return c

def rows(c, table):
    core=[list(row) for row in c.execute(f'SELECT rowid,id,symbol FROM {table} ORDER BY rowid')]
    hist_table='analysis_snapshot_rowid_history' if table=='analysis_snapshots' else 'forecast_record_rowid_history'
    history=[r[0] for r in c.execute(f'SELECT issued_rowid FROM {hist_table} ORDER BY issued_rowid')]
    return {'core':core,'history':history}

conn=setup()
initial={t:rows(conn,t) for t in ('analysis_snapshots','forecast_records')}
dump='\n'.join(conn.iterdump())
(base/'restore-audit'/'sqlite_dump.sql').write_text(dump+'\n')
restored=sqlite3.connect(':memory:')
restored.execute('PRAGMA recursive_triggers=OFF')
restored.executescript(dump)
restored_rows={t:rows(restored,t) for t in ('analysis_snapshots','forecast_records')}
repl={}
append={}
for table in ('analysis_snapshots','forecast_records'):
    repl[table]=attempt(restored,f'INSERT OR REPLACE INTO {table}(rowid,id,symbol) VALUES(1,?,?)',(f'{table}-replacement','EVIL'))
    # Isolate default append by resetting restore for each protected table.
    fresh=sqlite3.connect(':memory:'); fresh.execute('PRAGMA recursive_triggers=OFF'); fresh.executescript(dump)
    append[table]=attempt(fresh,f'INSERT INTO {table}(id,symbol) VALUES(?,?)',(f'{table}-append','NEW'))
    append[table]['rows_after_attempt'] = [list(r) for r in fresh.execute(f'SELECT rowid,id,symbol FROM {table} ORDER BY rowid')]
post_replace={t:rows(restored,t) for t in ('analysis_snapshots','forecast_records')}
# The migration script's INSERT...SELECT backfill is rerun without dropping triggers.
# This approximates operator reapplication, independent of migration journal semantics.
reapply=[]
for table in ('analysis_snapshots','forecast_records'):
    hist='analysis_snapshot_rowid_history' if table=='analysis_snapshots' else 'forecast_record_rowid_history'
    result=attempt(restored,f'''INSERT INTO {hist}(issued_rowid)
      SELECT source.rowid FROM {table} AS source
      WHERE NOT EXISTS (SELECT 1 FROM {hist} WHERE issued_rowid=source.rowid)''')
    reapply.append({'table':table,**result})
reapplied={t:rows(restored,t) for t in ('analysis_snapshots','forecast_records')}
post_reapply_replace={}
post_reapply_append={}
for table in ('analysis_snapshots','forecast_records'):
    # On each re-applied schema the original row was already replaced above in the shared conn,
    # so test rowid collision with the *remaining* protected rowid 2 in this connection.
    post_reapply_replace[table]=attempt(restored,f'INSERT OR REPLACE INTO {table}(rowid,id,symbol) VALUES(2,?,?)',(f'{table}-replacement2','EVIL'))
    post_reapply_append[table]=attempt(restored,f'INSERT INTO {table}(id,symbol) VALUES(?,?)',(f'{table}-append-after-reapply','NEW'))
report={
 'classification':'local synthetic SQLite dump/import audit; no production data or database',
 'candidate_migration':'0016_forecast_rowid_history.sql',
 'recursive_triggers':0,
 'initial_hidden_rowids':[-9,4,100],
 'initial':initial,
 'dump_omits_explicit_hidden_rowid':True,
 'restored':restored_rows,
 'replace_at_restored_rowid_1_before_reapply':repl,
 'default_auto_append_before_reapply':append,
 'rows_after_replace':post_replace,
 'reapply_backfill_attempts':reapply,
 'after_reapply':reapplied,
 'replace_at_restored_rowid_2_after_reapply':post_reapply_replace,
 'default_auto_append_after_reapply':post_reapply_append,
 'limitations':'Reapplication is a direct rerun of the migration backfill INSERT...SELECT only; it does not reinitialize stale ledger entries. The default append attempt after restore used an isolated freshly restored dump, not the instance mutated by the REPLACE probe.'
}
out=base/'restore-audit'/'dump-restore-findings.json'
out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2,sort_keys=True))
