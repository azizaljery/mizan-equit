const realFetch=globalThis.fetch.bind(globalThis);
globalThis.fetch=async (input,init)=>{
  const raw=typeof input==='string'||input instanceof URL?String(input):input.url;
  const url=new URL(raw);
  if(!['127.0.0.1','localhost','[::1]'].includes(url.hostname)) throw new Error('Network forbidden in P2 synthetic verification: '+url.hostname);
  return realFetch(input,init);
};
