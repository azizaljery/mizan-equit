globalThis.fetch = async () => { throw new Error('Network forbidden in P2 synthetic verification'); };
