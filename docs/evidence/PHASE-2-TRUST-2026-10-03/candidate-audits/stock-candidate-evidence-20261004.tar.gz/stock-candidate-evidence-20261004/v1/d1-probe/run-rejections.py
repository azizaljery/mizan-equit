import json,os,re,subprocess,pathlib
w=pathlib.Path('/tmp/P2-TRUST-LOCAL-FORECAST-2026-10-03-V1')
repo=w/'candidate/mizan-v45'
cli=repo/'node_modules/.bin/wrangler'
config=w/'d1-probe/wrangler.jsonc'
persist=w/'d1-probe/state'
env=os.environ.copy();env.update({'HOME':str(w/'wrangler-home'),'XDG_CONFIG_HOME':str(w/'wrangler-home/.config'),'WRANGLER_LOG_PATH':str(w/'wrangler.log'),'WRANGLER_WRITE_LOGS':'false'})
ops=[
('update_snapshot','UPDATE analysis_snapshots SET data=\'changed\' WHERE id=\'legacy-snapshot\'','analysis_snapshot_is_immutable'),
('delete_snapshot','DELETE FROM analysis_snapshots WHERE id=\'legacy-snapshot\'','analysis_snapshot_is_immutable'),
('replace_snapshot','INSERT OR REPLACE INTO analysis_snapshots VALUES(\'legacy-snapshot\',\'EVIL.SR\',\'2099-01-01\',\'{}\')','analysis_snapshot_id_already_issued'),
('upsert_snapshot','INSERT INTO analysis_snapshots VALUES(\'legacy-snapshot\',\'EVIL.SR\',\'2099-01-01\',\'{}\') ON CONFLICT(id) DO UPDATE SET data=excluded.data','analysis_snapshot_id_already_issued'),
('update_forecast','UPDATE forecast_records SET data=\'changed\' WHERE id=\'legacy-forecast\'','forecast_record_is_immutable'),
('delete_forecast','DELETE FROM forecast_records WHERE id=\'legacy-forecast\'','forecast_record_is_immutable'),
('replace_forecast','INSERT OR REPLACE INTO forecast_records VALUES(\'legacy-forecast\',\'legacy-snapshot\',\'EVIL.SR\',\'2099-01-01\',252,\'fake\',\'us\',\'fake\',\'مرتفع\',1,\'{}\')','forecast_record_id_already_issued'),
('upsert_forecast','INSERT INTO forecast_records VALUES(\'legacy-forecast\',\'legacy-snapshot\',\'EVIL.SR\',\'2099-01-01\',252,\'fake\',\'us\',\'fake\',\'مرتفع\',1,\'{}\') ON CONFLICT(id) DO UPDATE SET data=excluded.data','forecast_record_id_already_issued'),
]
results=[]
for name,sql,expected in ops:
 p=subprocess.run([str(cli),'d1','execute','mizan-p2-trust-local','--local','--command',sql,'--config',str(config),'--persist-to',str(persist)],cwd=repo,env=env,text=True,capture_output=True)
 stderr=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',p.stderr)
 matched=expected in stderr
 results.append({'name':name,'exit_code':p.returncode,'expected_error':expected,'expected_error_observed':matched})
 if p.returncode==0 or not matched:
  raise SystemExit(json.dumps({'failed_check':name,'return_code':p.returncode,'stderr':stderr[-1200:]},indent=2))
q=subprocess.run([str(cli),'d1','execute','mizan-p2-trust-local','--local','--command',"SELECT id,symbol,created_at,data FROM analysis_snapshots WHERE id='legacy-snapshot'; SELECT id,symbol,created_at,horizon,model,data FROM forecast_records WHERE id='legacy-forecast';",'--config',str(config),'--persist-to',str(persist)],cwd=repo,env=env,text=True,capture_output=True)
if q.returncode: raise SystemExit(q.stderr)
(w/'d1-probe/rejection-cases.json').write_text(json.dumps({'runtime':'Wrangler 4.92.0 local D1 (Miniflare/workerd); compatibilityDate 2026-05-22, latest date supported by bundled runtime','network':'local DB only; no --remote flag or production binding','migration':'candidate 0015_immutable_forecast_inputs.sql applied to pre-existing synthetic legacy rows','checks':results,'post_rejection_query_stdout':q.stdout},ensure_ascii=False,indent=2)+'\n')
print('D1 rejections verified:',len(results))
print(q.stdout[-900:])
