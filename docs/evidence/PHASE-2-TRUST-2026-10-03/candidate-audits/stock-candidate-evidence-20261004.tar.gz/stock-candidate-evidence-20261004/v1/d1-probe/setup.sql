CREATE TABLE analysis_snapshots(id TEXT PRIMARY KEY NOT NULL,symbol TEXT NOT NULL,created_at TEXT NOT NULL,data TEXT NOT NULL);
CREATE TABLE forecast_records(id TEXT PRIMARY KEY NOT NULL,snapshot_id TEXT NOT NULL,symbol TEXT NOT NULL,created_at TEXT NOT NULL,horizon INTEGER NOT NULL,model TEXT NOT NULL,market TEXT NOT NULL,sector TEXT NOT NULL,confidence TEXT NOT NULL,available INTEGER NOT NULL,data TEXT NOT NULL);
CREATE TABLE evaluation_revisions(id TEXT PRIMARY KEY NOT NULL,forecast_id TEXT NOT NULL,revision INTEGER NOT NULL,created_at TEXT NOT NULL,fingerprint TEXT NOT NULL,data TEXT NOT NULL);
CREATE TABLE forecast_outcomes(id TEXT PRIMARY KEY NOT NULL,evaluated_at TEXT NOT NULL,data TEXT NOT NULL);
INSERT INTO analysis_snapshots VALUES('legacy-snapshot','SYNTH.SR','2026-01-01T00:00:00.000Z','{"synthetic":true}');
INSERT INTO forecast_records VALUES('legacy-forecast','legacy-snapshot','SYNTH.SR','2026-01-01T00:00:00.000Z',5,'fixture-v1','sa','fixture','منخفض',1,'{"synthetic":true}');
