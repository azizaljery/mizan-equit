INSERT INTO analysis_snapshots VALUES('new-snapshot','NEW.SR','2026-02-01','{}');
INSERT INTO forecast_records VALUES('new-forecast','new-snapshot','NEW.SR','2026-02-01',5,'fixture-v1','sa','fixture','منخفض',1,'{}');
INSERT INTO evaluation_revisions VALUES('revision-1','legacy-forecast',0,'2026-02-01','a','{}');
INSERT INTO forecast_outcomes VALUES('legacy-forecast','2026-02-01','{"actualPrice":101}');
INSERT INTO evaluation_revisions VALUES('revision-2','legacy-forecast',1,'2026-02-02','b','{}');
INSERT INTO forecast_outcomes(id,evaluated_at,data) VALUES('legacy-forecast','2026-02-02','{"actualPrice":102}') ON CONFLICT(id) DO UPDATE SET evaluated_at=excluded.evaluated_at,data=excluded.data;
SELECT (SELECT count(*) FROM analysis_snapshots) AS snapshots,
       (SELECT count(*) FROM forecast_records) AS forecasts,
       (SELECT count(*) FROM evaluation_revisions) AS revisions,
       json_extract((SELECT data FROM forecast_outcomes WHERE id='legacy-forecast'),'$.actualPrice') AS corrected_outcome;
