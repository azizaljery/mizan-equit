from pathlib import Path
import json,hashlib,difflib,re,subprocess
W=Path('/tmp/P2-TRUST-LOCAL-FORECAST-2026-10-03-V1')
BASE=Path('/tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45')
CAND=W/'candidate/mizan-v45'
files=['drizzle/0015_immutable_forecast_inputs.sql','drizzle/meta/_journal.json','tests/background-jobs.test.mjs','tests/calculations.test.mjs','tests/forecast-conformal.test.mjs','tests/state-backtest.test.mjs']
# Patch is a review artifact derived from the canonical materialization; no repository tree is modified.
parts=[]
for rel in files:
 old=(BASE/rel).read_text(encoding='utf-8') if (BASE/rel).exists() else ''
 new=(CAND/rel).read_text(encoding='utf-8')
 old_lines=old.splitlines(keepends=True)
 new_lines=new.splitlines(keepends=True)
 if not old_lines and new_lines:
  diff=difflib.unified_diff([],new_lines,fromfile='/dev/null',tofile='b/'+rel,n=3)
 else:
  diff=difflib.unified_diff(old_lines,new_lines,fromfile='a/'+rel,tofile='b/'+rel,n=3)
 parts.extend(diff)
patch=W/'candidate-immutability.patch'
patch.write_text(''.join(parts),encoding='utf-8')
# Sanitized TAP keeps only test-result and summary lines; excludes app debug/fixture payload logs.
raw=(W/'candidate-npm-test.log').read_text(encoding='utf-8')
status_lines=[line for line in raw.splitlines() if re.match(r'^(?:✔|✖|﹣|ℹ)',line)]
tap=W/'candidate-npm-test.sanitized.tap';tap.write_text('\n'.join(status_lines)+'\n',encoding='utf-8')
# Verify all previously-existing SQL migration bytes remain identical.
old_migs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'drizzle').glob('*.sql')}
new_migs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (CAND/'drizzle').glob('*.sql') if p.name!='0015_immutable_forecast_inputs.sql'}
existing_unchanged=old_migs==new_migs
filehashes={rel:hashlib.sha256((CAND/rel).read_bytes()).hexdigest() for rel in files}
# Candidate-specific addendum to read-only path audit.
audit_path=W/'p2-04-path-audit.json'
audit=json.loads(audit_path.read_text(encoding='utf-8'))
audit['recommendation']="Candidate-only implementation is available for review: migration adds unconditional BEFORE UPDATE/DELETE guards plus BEFORE INSERT duplicate-ID guards on analysis_snapshots and forecast_records, preventing SQLite REPLACE/UPSERT from rewriting an existing ID. The immutable source tables remain separate from evaluation_revisions/forecast_outcomes. Existing test fixtures now insert the intended historical/malformed/unavailable cases before applying guards rather than mutating issued rows. Do not adopt without human review of retention, restore, database-operator threat boundary, and archive policy. No fix was applied to production or canonical baseline."
audit['candidate_fix']={
 'status':'local candidate only; not deployed',
 'candidate_directory':str(CAND),
 'patch':str(patch),
 'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),
 'changed_files':filehashes,
 'previous_sql_migrations_0000_0014_unchanged':existing_unchanged,
 'node_sqlite':'PASS: pre-existing rows guarded after migration; UPDATE/DELETE/INSERT OR REPLACE/UPSERT rejected; new IDs append; actual recordAnalysis appends; outcome correction creates two evaluation revisions and updates forecast_outcomes; source rows preserved through VACUUM INTO and restore, with triggers still active.',
 'local_d1':'PASS: exact migration applied with Wrangler 4.92 local D1 to synthetic rows seeded before migration; eight UPDATE/DELETE/OR REPLACE/UPSERT attempts rejected; new inserts and correction writes succeeded; original row bytes queried unchanged afterward.',
 'full_test':'PASS: `npm test` exit 0; 213 tests, 212 pass, 0 fail, 1 skip. The skipped test is `Current Saudi and US behavior matches the actual pre-change module with identical inputs and a fixed clock`; `MIZAN_LIVE_BASELINE_MODULE` was unset, so optional pre-change module comparison did not run.',
 'human_review_limits':['DB triggers enforce ordinary DML while installed; a trusted operator with schema/admin capability can drop triggers/tables or restore a database copy that omits them.','Future authorized cleanup, correction by same-ID replacement, or retention deletion of snapshot/forecast rows will now be rejected. No current app retention path deletes these rows; the existing retention feature is read-only preview.','Recovery from recovery_rows can reinsert missing IDs, but same-ID replacement is intentionally blocked. A repair process must preserve the original and append an audited correction/new record.','Append-only growth requires a separate archival/retention decision; do not silently purge issued rows.'],
 'build':'Not run: `npm run build` refused because the materialized candidate has no Git checkout revision and no verified CI commit for the modified tree. No synthetic commit was supplied; no build identity or deployment was invented.',
 'typecheck':'`tsc --noEmit` remains failing on canonical baseline errors; candidate log SHA-256 is byte-identical to a separate unmodified 18ba8f baseline-copy run.',
 'lint':'Repository lint remains failing: 635 errors; baseline copy also 635 errors. Candidate has 2,516 warnings vs baseline 2,517; no lint errors in changed files. Full lint artifact is saved.'
}
audit['status']='Baseline supported-flow invariance PASS; baseline general DB immutability PARTIAL. Candidate append-only DML enforcement passed isolated Node SQLite and local D1 checks; overall P2-04 remains PARTIAL pending root/human review and any authorized deployment.'
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Stable concise candidate evidence index.
evidence={
 'task':'P2-04 snapshot/forecast immutability candidate review',
 'source':{'commit':'18ba8f39f3399a7a27d4ad16c2ed1e9b5f6fa241','materialization':'file-by-file canonical source tree; no Git object','canonical_directory':str(BASE),'parity_manifest':audit['source']['parity_manifest'],'parity_manifest_sha256':audit['source']['parity_manifest_sha256']},
 'candidate_directory':str(CAND),'candidate_is_separate_copy':True,'canonical_baseline_unchanged':True,
 'changed_files':filehashes,'patch':str(patch),'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'old_migrations_unchanged':existing_unchanged,
 'node_sqlite_full_test':{'command':'npm test','exit_code':0,'tests':213,'passed':212,'failed':0,'skipped':1,'skip_name':'Current Saudi and US behavior matches the actual pre-change module with identical inputs and a fixed clock','skip_reason':'Optional pre-change module was not supplied; MIZAN_LIVE_BASELINE_MODULE is unset.','raw_log':str(W/'candidate-npm-test.log'),'raw_log_sha256':hashlib.sha256((W/'candidate-npm-test.log').read_bytes()).hexdigest(),'sanitized_tap':str(tap),'sanitized_tap_sha256':hashlib.sha256(tap.read_bytes()).hexdigest()},
 'd1_local':{'runtime':'Wrangler 4.92.0 local D1 (Miniflare/workerd); compatibilityDate 2026-05-22 (maximum supported by installed runtime binary)','remote':False,'credentialed':False,'synthetic_rows_only':True,'migration_applied_to_seeded_existing_rows':True,'dml_rejections':'8/8 UPDATE, DELETE, INSERT OR REPLACE, UPSERT attempts across snapshots and forecasts rejected with expected trigger constraint.','post_rejection_rows_unchanged':True,'new_insert_and_outcome_revision_success':'2 snapshots, 2 forecasts, 2 evaluation revisions; current materialized outcome value 102 after correction','artifact':str(W/'d1-probe/rejection-cases.json'),'artifact_sha256':hashlib.sha256((W/'d1-probe/rejection-cases.json').read_bytes()).hexdigest(),'migration_stdout':str(W/'d1-probe/migrate.json'),'migration_stdout_sha256':hashlib.sha256((W/'d1-probe/migrate.json').read_bytes()).hexdigest(),'success_sql_stdout':str(W/'d1-probe/success.json'),'success_sql_stdout_sha256':hashlib.sha256((W/'d1-probe/success.json').read_bytes()).hexdigest()},
 'typecheck':{'command':'./node_modules/.bin/tsc --noEmit','exit_code':1,'candidate_log':str(W/'candidate-tsc-check.log'),'candidate_log_sha256':hashlib.sha256((W/'candidate-tsc-check.log').read_bytes()).hexdigest(),'canonical_baseline_log':str(W/'baseline-tsc-check.log'),'canonical_baseline_log_sha256':hashlib.sha256((W/'baseline-tsc-check.log').read_bytes()).hexdigest(),'byte_identical_to_baseline':(W/'candidate-tsc-check.log').read_bytes()==(W/'baseline-tsc-check.log').read_bytes()},
 'lint':{'command':'npm run lint','exit_code':1,'candidate_log':str(W/'candidate-lint-check.log'),'candidate_log_sha256':hashlib.sha256((W/'candidate-lint-check.log').read_bytes()).hexdigest(),'canonical_baseline_log':str(W/'baseline-lint-check.log'),'canonical_baseline_log_sha256':hashlib.sha256((W/'baseline-lint-check.log').read_bytes()).hexdigest(),'candidate_errors':635,'baseline_errors':635,'candidate_warnings':2516,'baseline_warnings':2517,'changed_file_errors':0},
 'build':{'command':'npm run build','exit_code':1,'result':'refused before build; build identity resolver requires verified checked-out or CI commit, neither exists for modified source-only candidate.','artifact':str(W/'candidate-build-check.log'),'artifact_sha256':hashlib.sha256((W/'candidate-build-check.log').read_bytes()).hexdigest()},
 'decision':'Candidate evidence is local only. Baseline P2-04 supported-flow check passes; overall P2-04 remains PARTIAL until root/human review and any separately authorized rollout. No production migration, deployment, or source write occurred.'
}
# Save report after updating audit. It references patch hash but not its own hash.
out=W/'p2-04-candidate-evidence.json';out.write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('patch',patch,hashlib.sha256(patch.read_bytes()).hexdigest(),patch.stat().st_size)
print('sanitized tap',tap,hashlib.sha256(tap.read_bytes()).hexdigest(),tap.stat().st_size)
print('audit',audit_path,hashlib.sha256(audit_path.read_bytes()).hexdigest(),audit_path.stat().st_size)
print('evidence',out,hashlib.sha256(out.read_bytes()).hexdigest(),out.stat().st_size)
print('migrations unchanged',existing_unchanged)
print('candidate hashes',json.dumps(filehashes,indent=2))
