// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/supporting-sources.ts
var SUPPORTING_SOURCES = [
  { id: "tadawul-watch", name: "\u062A\u062F\u0627\u0648\u0644 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u2014 \u0645\u0631\u0627\u0642\u0628\u0629 \u0627\u0644\u0633\u0648\u0642 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629", url: "https://www.saudiexchange.sa/wps/portal/saudiexchange/ourmarkets/main-market-watch?locale=ar", official: true, role: "\u0645\u0631\u062C\u0639 \u0631\u0633\u0645\u064A \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629", note: "\u062A\u064F\u0631\u0627\u062C\u0639 \u0647\u0648\u064A\u0629 \u0627\u0644\u0633\u0647\u0645 \u0648\u0627\u0644\u0639\u0645\u0644\u0629 \u0648\u0648\u0642\u062A \u0622\u062E\u0631 \u0635\u0641\u0642\u0629. \u0627\u0644\u0635\u0641\u062D\u0629 \u062A\u0646\u0628\u0651\u0647 \u0625\u0644\u0649 \u062A\u0623\u062E\u0631 \u0627\u0644\u0623\u0633\u0639\u0627\u0631\u061B \u0644\u0627 \u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0645\u0633\u062A\u0648\u0649 \u062A\u0627\u0633\u064A \u0628\u062F\u0644 \u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0643\u0629.", priceFeedEnabled: false },
  { id: "sahm-reference", name: "\u0633\u0647\u0645 \u2014 \u0627\u0644\u0623\u0633\u0647\u0645 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u0648\u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629", url: "https://www.sahmcapital.com/invest/stocks", official: false, role: "\u0645\u0631\u062C\u0639 \u062B\u0627\u0646\u0648\u064A \u0644\u0644\u0645\u0642\u0627\u0631\u0646\u0629", note: "\u0627\u0644\u0635\u0641\u062D\u0629 \u062A\u0630\u0643\u0631 \u062A\u0623\u062E\u0631 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 15 \u062F\u0642\u064A\u0642\u0629. \u064A\u0644\u0632\u0645 \u0641\u062A\u062D \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0648\u0631\u0642\u0629 \u0646\u0641\u0633\u0647\u0627 \u0648\u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0631\u0645\u0632 \u0648\u0627\u0644\u0633\u0648\u0642 \u0648\u0627\u0644\u0639\u0645\u0644\u0629 \u0648\u0627\u0644\u062A\u0627\u0631\u064A\u062E\u061B \u0648\u062C\u0648\u062F \u062E\u0627\u0646\u0629 \u062A\u0637\u0647\u064A\u0631 \u0644\u0627 \u064A\u062B\u0628\u062A \u062A\u0648\u0627\u0641\u0642\u064B\u0627 \u0634\u0631\u0639\u064A\u064B\u0627.", priceFeedEnabled: false },
  { id: "investing-reference", name: "Investing.com \u2014 \u0627\u0644\u0623\u0633\u0647\u0645 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629", url: "https://sa.investing.com/equities/saudi-arabia", official: false, role: "\u0645\u0631\u062C\u0639 \u062B\u0627\u0646\u0648\u064A \u0644\u0644\u0645\u0642\u0627\u0631\u0646\u0629", note: "\u062F\u0644\u064A\u0644 \u0644\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0634\u0631\u0643\u0629. \u0644\u0627 \u062A\u064F\u062E\u0644\u0637 \u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0623\u0633\u0647\u0645 \u0628\u0627\u0644\u0645\u0624\u0634\u0631\u0627\u062A \u0623\u0648 \u0627\u0644\u0623\u062E\u0628\u0627\u0631 \u0648\u0627\u0644\u062A\u062D\u0644\u064A\u0644\u0627\u062A\u060C \u0648\u064A\u064F\u0631\u0627\u062C\u0639 \u062A\u0648\u0642\u064A\u062A \u0627\u0644\u0633\u0639\u0631 \u0648\u0646\u0648\u0639 \u0627\u0644\u0648\u0631\u0642\u0629 \u0641\u064A \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0647\u0627.", priceFeedEnabled: false },
  { id: "capital-reference", name: "Capital.com", url: "https://capital.com/ar-int", official: false, role: "\u0635\u0641\u062D\u0629 \u062A\u0633\u0648\u064A\u0642\u064A\u0629 \u2014 \u0645\u0633\u062A\u0628\u0639\u062F\u0629 \u0645\u0646 \u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u0623\u0633\u0639\u0627\u0631", note: "\u0627\u0644\u0631\u0627\u0628\u0637 \u064A\u0639\u0631\u0636 \u062E\u062F\u0645\u0627\u062A \u0648\u0639\u0642\u0648\u062F \u0641\u0631\u0648\u0642\u0627\u062A. \u0633\u0639\u0631 \u0639\u0642\u062F \u0627\u0644\u0641\u0631\u0648\u0642\u0627\u062A \u0644\u064A\u0633 \u0633\u0639\u0631 \u0627\u0644\u0633\u0647\u0645 \u0627\u0644\u0623\u0635\u0644\u064A\u060C \u0648\u0644\u0627 \u064A\u064F\u0646\u0642\u0644 \u0625\u0644\u0649 \u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0623\u0648 \u0627\u0644\u0645\u062D\u0641\u0638\u0629 \u0643\u0633\u0639\u0631 \u0633\u0647\u0645.", priceFeedEnabled: false }
];

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/source-catalog.ts
var sa = [
  ["tadawul", "\u062A\u062F\u0627\u0648\u0644 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629", "https://www.saudiexchange.sa/wps/portal/saudiexchange/trading/market-services/market-information-services/market-data", "prices", "licensed-api", true, "\u0627\u062E\u062A\u064A\u0627\u0631 \u062A\u063A\u0630\u064A\u0629 \u0623\u0633\u0639\u0627\u0631 \u0645\u0631\u062E\u0635\u0629\u061B \u0642\u0627\u0631\u0626 \u0635\u0641\u062D\u0629 \u0627\u0644\u0634\u0631\u0643\u0629 \u0627\u0644\u062D\u0627\u0644\u064A \u0645\u0633\u062A\u0642\u0644 \u0639\u0646 \u0627\u0634\u062A\u0631\u0627\u0643 \u0627\u0644\u0623\u0633\u0639\u0627\u0631."],
  ["cma", "\u0647\u064A\u0626\u0629 \u0627\u0644\u0633\u0648\u0642 \u0627\u0644\u0645\u0627\u0644\u064A\u0629", "https://cma.gov.sa/MediaCenter/NEWS/Pages/default.aspx", "news", "document", true, "\u0642\u0627\u0631\u0626 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u062A\u0646\u0638\u064A\u0645\u064A\u0629\u061B \u0644\u064A\u0633\u062A \u062A\u063A\u0630\u064A\u0629 \u0623\u0633\u0639\u0627\u0631."],
  ["sama", "\u0627\u0644\u0628\u0646\u0643 \u0627\u0644\u0645\u0631\u0643\u0632\u064A \u0627\u0644\u0633\u0639\u0648\u062F\u064A", "https://www.sama.gov.sa/ar-sa/Statistics/Indices/Pages/default.aspx", "general", "document", true, "\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0633\u0644\u0627\u0633\u0644 \u0627\u0644\u0646\u0642\u062F\u064A\u0629 \u0648\u0627\u0644\u0645\u0635\u0631\u0641\u064A\u0629 \u0627\u0644\u0645\u0646\u0627\u0633\u0628\u0629 \u0644\u0644\u0641\u062A\u0631\u0629."],
  ["gastat", "\u0627\u0644\u0647\u064A\u0626\u0629 \u0627\u0644\u0639\u0627\u0645\u0629 \u0644\u0644\u0625\u062D\u0635\u0627\u0621", "https://www.stats.gov.sa/", "general", "document", true, "\u0627\u062E\u062A\u0628\u0627\u0631 \u0627\u0644\u0648\u0635\u0648\u0644 \u0648\u062A\u062D\u062F\u064A\u062F \u0645\u062C\u0645\u0648\u0639\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0627\u0642\u062A\u0635\u0627\u062F\u064A\u0629."],
  ["mof", "\u0648\u0632\u0627\u0631\u0629 \u0627\u0644\u0645\u0627\u0644\u064A\u0629", "https://www.mof.gov.sa/financialreport/Pages/default.aspx", "general", "document", true, "\u0642\u0631\u0627\u0621\u0629 \u062A\u0642\u0627\u0631\u064A\u0631 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 \u0628\u062A\u0627\u0631\u064A\u062E \u0646\u0634\u0631\u0647\u0627."],
  ["datasaudi", "DataSaudi", "https://datasaudi.sa/ar", "general", "reference", true, "\u062A\u062D\u062F\u064A\u062F \u0645\u062C\u0645\u0648\u0639\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0648\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0648\u0635\u0648\u0644 \u0627\u0644\u0645\u062A\u0627\u062D\u0629."],
  ["ndmc", "\u0627\u0644\u0645\u0631\u0643\u0632 \u0627\u0644\u0648\u0637\u0646\u064A \u0644\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u062F\u064A\u0646", "https://ndmc.gov.sa/ar/reports-and-statistics", "general", "document", true, "\u062A\u0642\u0627\u0631\u064A\u0631 \u0627\u0644\u062A\u0645\u0648\u064A\u0644 \u0648\u0627\u0644\u0625\u0635\u062F\u0627\u0631\u0627\u062A \u0627\u0644\u062D\u0643\u0648\u0645\u064A\u0629\u061B \u0644\u064A\u0633\u062A \u0623\u0633\u0639\u0627\u0631 \u0623\u0633\u0647\u0645."],
  ["argaam", "\u0623\u0631\u0642\u0627\u0645", "https://www.argaam.com/ar", "financials", "reference", false, "\u062A\u062D\u062F\u064A\u062F \u062E\u062F\u0645\u0629 \u0627\u0644\u0631\u0628\u0637 \u0648\u0627\u0644\u0625\u0630\u0646 \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A."],
  ["mubasher", "\u0645\u0628\u0627\u0634\u0631", "https://www.mubasher.info/countries/sa", "news", "reference", false, "\u0645\u0631\u062C\u0639 \u0645\u0642\u0627\u0631\u0646\u0629\u061B \u0644\u0627 \u064A\u0641\u062A\u0631\u0636 \u0648\u062C\u0648\u062F API \u0639\u0627\u0645."],
  ["investing-reference", "Investing.com \u2014 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629", "https://sa.investing.com/equities/saudi-arabia", "prices", "reference", false, "\u0645\u0631\u062C\u0639 \u0645\u0642\u0627\u0631\u0646\u0629\u061B \u0644\u0627 \u064A\u0639\u062A\u0645\u062F \u0643\u062A\u063A\u0630\u064A\u0629 \u0648\u062D\u064A\u062F\u0629."],
  ["directfn", "DirectFN", "https://directfn.com/ar/", "prices", "licensed-api", false, "\u0627\u062A\u0641\u0627\u0642\u064A\u0629 \u062A\u063A\u0630\u064A\u0629 \u0648\u062D\u0642 \u0639\u0631\u0636 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u062F\u0627\u062E\u0644 \u0645\u064A\u0632\u0627\u0646."],
  ["tickerchart", "\u062A\u0643\u0631\u062A\u0634\u0627\u0631\u062A", "https://www.tickerchart.com/", "prices", "licensed-api", false, "\u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0642 \u0627\u0644\u0631\u0628\u0637 \u0648\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645\u060C \u0644\u0627 \u0627\u0634\u062A\u0631\u0627\u0643 \u0627\u0644\u0639\u0631\u0636 \u0648\u062D\u062F\u0647."],
  ["lseg", "LSEG Data & Analytics", "https://www.lseg.com/en/data-analytics", "prices", "licensed-api", false, "\u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0645\u0646\u062A\u062C \u0648\u0627\u0644\u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u0648\u062D\u0642 \u0627\u0644\u0639\u0631\u0636."],
  ["six", "SIX Financial Information", "https://www.six-group.com/en/products-services/financial-information.html", "prices", "licensed-api", false, "\u062E\u062F\u0645\u0629 \u0645\u0631\u062E\u0635\u0629 \u0644\u0644\u0623\u0633\u0639\u0627\u0631 \u0648\u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0631\u062C\u0639\u064A\u0629 \u0648\u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0627\u0644\u0634\u0631\u0643\u0627\u062A."],
  ["factset", "FactSet", "https://developer.factset.com/", "financials", "licensed-api", false, "\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0646\u062A\u062C \u0648\u0627\u0644\u062D\u0642\u0648\u0644 \u0648\u0627\u0644\u0635\u0644\u0627\u062D\u064A\u0627\u062A \u0641\u064A \u0627\u0644\u0627\u062A\u0641\u0627\u0642\u064A\u0629."],
  ["spa", "\u0648\u0643\u0627\u0644\u0629 \u0627\u0644\u0623\u0646\u0628\u0627\u0621 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629", "https://www.spa.gov.sa/", "news", "document", true, "\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u062E\u0628\u0631 \u0627\u0644\u0623\u0635\u0644\u064A\u061B \u0644\u0627 \u064A\u064F\u0633\u062A\u0646\u062A\u062C \u0627\u0644\u0623\u062B\u0631 \u0645\u0646 \u0639\u0646\u0648\u0627\u0646 \u0641\u0642\u0637."],
  ["aramco-ir", "\u0623\u0631\u0627\u0645\u0643\u0648 \u2014 \u0639\u0644\u0627\u0642\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631\u064A\u0646", "https://www.aramco.com/en/investors", "financials", "document", true, "\u062A\u0642\u0627\u0631\u064A\u0631 \u0627\u0644\u0634\u0631\u0643\u0629 2222 \u0641\u0642\u0637\u060C \u0645\u0639 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0641\u062A\u0631\u0629 \u0648\u0627\u0644\u0646\u0634\u0631."],
  ["stc-ir", "stc \u2014 \u0639\u0644\u0627\u0642\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631\u064A\u0646", "https://www.stc.com/en/investors.html", "financials", "document", true, "\u062A\u0642\u0627\u0631\u064A\u0631 \u0627\u0644\u0634\u0631\u0643\u0629 7010 \u0641\u0642\u0637\u060C \u0645\u0639 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0641\u062A\u0631\u0629 \u0648\u0627\u0644\u0646\u0634\u0631."],
  ["jarir-ir", "\u062C\u0631\u064A\u0631 \u2014 \u0627\u0644\u062A\u0642\u0627\u0631\u064A\u0631", "https://www.jarir.com/about-jarir/reports", "financials", "document", true, "\u062A\u0642\u0627\u0631\u064A\u0631 \u0627\u0644\u0634\u0631\u0643\u0629 4190 \u0641\u0642\u0637\u060C \u0645\u0639 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0641\u062A\u0631\u0629 \u0648\u0627\u0644\u0646\u0634\u0631."],
  ["idealratings", "IdealRatings", "https://www.idealratings.com/islamic-finance-solutions/", "financials", "licensed-api", false, "\u062A\u0631\u062E\u064A\u0635 \u0648\u062A\u063A\u0637\u064A\u0629 \u0648\u0641\u062D\u0635 \u062A\u0648\u0627\u0641\u0642 \u0627\u0644\u0645\u0646\u0647\u062C \u0627\u0644\u0634\u0631\u0639\u064A \u0645\u0639 \u0645\u0639\u0627\u064A\u064A\u0631 \u0627\u0644\u0645\u0634\u0631\u0648\u0639."]
];
var us = [
  ["sec", "SEC \u2014 EDGAR", "https://www.sec.gov/search-filings/edgar-application-programming-interfaces", "financials", "public-api", true, "\u0642\u0627\u0631\u0626 \u062E\u0627\u062F\u0645 submissions/companyfacts \u0648\u0627\u0644\u0645\u0633\u062A\u0646\u062F \u0627\u0644\u0623\u0635\u0644\u064A\u061B \u0644\u0627 \u064A\u062A\u0637\u0644\u0628 \u0645\u0641\u062A\u0627\u062D\u064B\u0627\u060C \u0648\u064A\u0644\u062A\u0632\u0645 \u0628\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u0648\u0635\u0648\u0644."],
  ["nasdaq-data-link", "Nasdaq Data Link", "https://docs.data.nasdaq.com/", "prices", "licensed-api", true, "\u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u062C\u0645\u0648\u0639\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0648\u0627\u0644\u0645\u0641\u062A\u0627\u062D \u0648\u0627\u0644\u062A\u063A\u0637\u064A\u0629 \u0648\u062D\u0642\u0648\u0642 \u0627\u0644\u0639\u0631\u0636."],
  ["nyse", "NYSE", "https://www.nyse.com/data-products", "prices", "licensed-api", true, "\u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u0646\u062A\u062C \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0648\u062A\u0631\u062E\u064A\u0635\u0647."],
  ["cboe", "Cboe", "https://www.cboe.com/data/market-data-services/us/equities", "prices", "licensed-api", true, "\u062A\u062D\u062F\u064A\u062F \u062A\u063A\u0637\u064A\u0629 \u0623\u0633\u0648\u0627\u0642 Cboe\u061B \u0644\u064A\u0633\u062A \u062A\u063A\u0630\u064A\u0629 \u0645\u062C\u0645\u0639\u0629 \u0645\u0641\u062A\u0631\u0636\u0629."],
  ["finra", "FINRA Data", "https://www.finra.org/finra-data", "general", "public-api", true, "\u062A\u062D\u062F\u064A\u062F \u0645\u062C\u0645\u0648\u0639\u0629 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0634\u0641\u0627\u0641\u064A\u0629\u061B \u0644\u064A\u0633\u062A \u062A\u063A\u0630\u064A\u0629 \u0623\u0633\u0639\u0627\u0631 \u0634\u0627\u0645\u0644\u0629."],
  ["alpaca", "Alpaca \u2014 \u0628\u064A\u0627\u0646\u0627\u062A \u0641\u0642\u0637", "https://docs.alpaca.markets/us/docs/about-market-data-api", "prices", "licensed-api", false, "\u0642\u0627\u0631\u0626 GET \u062C\u0627\u0647\u0632 \u0644\u0644\u0625\u0639\u062F\u0627\u062F. \u0639\u0644\u0649 \u0627\u0644\u062E\u0627\u062F\u0645: ALPACA_API_KEY \u0648ALPACA_API_SECRET \u0648ALPACA_DATA_FEED=iex \u0623\u0648 sip \u0648ALPACA_DELAY_MINUTES=0 \u0623\u0648 15 \u0648ALPACA_DISPLAY_AUTHORIZED=true \u0628\u0639\u062F \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0642\u0648\u0642 \u0627\u0644\u0639\u0631\u0636\u061B \u0644\u0627 \u0623\u0648\u0627\u0645\u0631 \u062A\u062F\u0627\u0648\u0644."],
  ["massive", "Massive", "https://massive.com/docs", "prices", "licensed-api", false, "\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0646\u062A\u062C \u0648\u0627\u0644\u0645\u0641\u062A\u0627\u062D \u0648\u0627\u0644\u062A\u0623\u062E\u064A\u0631 \u0648\u0627\u0644\u062A\u0631\u062E\u064A\u0635."],
  ["alpha-vantage", "Alpha Vantage", "https://www.alphavantage.co/documentation/", "prices", "licensed-api", false, "\u0645\u0641\u062A\u0627\u062D \u0648\u062E\u0637\u0629 \u0648\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0642\u0648\u0642 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0648\u062A\u0623\u062E\u064A\u0631\u0647\u0627."],
  ["tiingo", "Tiingo", "https://www.tiingo.com/documentation/general/overview", "prices", "licensed-api", false, "\u0645\u0641\u062A\u0627\u062D \u0648\u0645\u0631\u0627\u062C\u0639\u0629 \u0645\u0633\u062A\u0642\u0644\u0629 \u0644\u062D\u0642\u0648\u0642 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0639\u0631\u0636 \u062F\u0627\u062E\u0644 \u0645\u0646\u0635\u0629."],
  ["databento", "Databento", "https://databento.com/docs", "prices", "licensed-api", false, "\u062A\u062D\u062F\u064A\u062F \u0645\u062C\u0645\u0648\u0639\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0648\u0627\u0644\u062A\u0631\u062E\u064A\u0635 \u0648\u0627\u0644\u0645\u0641\u062A\u0627\u062D."],
  ["intrinio", "Intrinio", "https://intrinio.com/docs", "prices", "licensed-api", false, "\u062A\u062D\u062F\u064A\u062F \u062A\u063A\u0630\u064A\u0629 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0648\u0627\u0644\u062A\u0623\u062E\u064A\u0631 \u0648\u0627\u0644\u0635\u0644\u0627\u062D\u064A\u0627\u062A."],
  ["finnhub", "Finnhub", "https://finnhub.io/docs/api", "financials", "licensed-api", false, "\u0645\u0641\u062A\u0627\u062D \u0648\u062E\u0637\u0629 \u0648\u0627\u062E\u062A\u0628\u0627\u0631 \u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u062D\u0642\u0648\u0644 \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629."],
  ["fred", "FRED / ALFRED", "https://fred.stlouisfed.org/docs/api/fred/", "general", "public-api", true, "\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0633\u0644\u0627\u0633\u0644 \u0648\u0627\u0644\u0625\u0635\u062F\u0627\u0631\u0627\u062A \u0627\u0644\u062A\u0627\u0631\u064A\u062E\u064A\u0629 \u0648\u0645\u0641\u062A\u0627\u062D API\u061B \u0644\u064A\u0633 \u0633\u0639\u0631 \u0627\u0644\u0633\u0647\u0645."],
  ["federal-reserve", "Federal Reserve", "https://www.federalreserve.gov/data.htm", "general", "document", true, "\u0642\u0631\u0627\u0621\u0629 \u0625\u0635\u062F\u0627\u0631\u0627\u062A \u0627\u0644\u0641\u0627\u0626\u062F\u0629 \u0648\u0627\u0644\u0646\u0642\u062F \u0648\u0627\u0644\u0627\u0626\u062A\u0645\u0627\u0646 \u0628\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0646\u0634\u0631."],
  ["bls", "BLS", "https://www.bls.gov/developers/", "general", "public-api", true, "\u062A\u062D\u062F\u064A\u062F \u0633\u0644\u0627\u0633\u0644 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0648\u0627\u0644\u0639\u0645\u0644 \u0648\u062D\u062F\u0648\u062F \u0627\u0644\u0637\u0644\u0628\u0627\u062A."],
  ["bea", "BEA", "https://www.bea.gov/", "general", "public-api", true, "\u0628\u0648\u0627\u0628\u0629 \u0627\u0644\u0645\u0637\u0648\u0631\u064A\u0646: https://www.bea.gov/resources/for-developers \u061B \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u062C\u0645\u0648\u0639\u0629 \u0648\u0627\u0644\u0645\u0641\u062A\u0627\u062D."],
  ["census", "US Census Bureau", "https://www.census.gov/data/developers.html", "general", "public-api", true, "\u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u062C\u0645\u0648\u0639\u0629 \u0627\u0642\u062A\u0635\u0627\u062F\u064A\u0629 \u0623\u0648 \u0642\u0637\u0627\u0639\u064A\u0629 \u0648\u062A\u062D\u062F\u064A\u062F \u0645\u062A\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0645\u0641\u062A\u0627\u062D."],
  ["eia", "EIA", "https://www.eia.gov/opendata/", "general", "public-api", true, "\u0627\u062E\u062A\u064A\u0627\u0631 \u0633\u0644\u0627\u0633\u0644 \u0627\u0644\u0637\u0627\u0642\u0629 \u0648\u0645\u0641\u062A\u0627\u062D \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0641\u062A\u0648\u062D\u0629."],
  ["apple-ir", "Apple \u2014 \u0639\u0644\u0627\u0642\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631\u064A\u0646", "https://investor.apple.com/investor-relations/default.aspx", "financials", "document", true, "\u062A\u0642\u0627\u0631\u064A\u0631 Apple \u0641\u0642\u0637\u061B \u0627\u0643\u062A\u0634\u0627\u0641 \u0625\u0641\u0635\u0627\u062D \u0627\u0644\u0634\u0631\u0643\u0629 \u0627\u0644\u0623\u0635\u0644\u064A \u0645\u0646 SEC."],
  ["microsoft-ir", "Microsoft \u2014 \u0639\u0644\u0627\u0642\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631\u064A\u0646", "https://www.microsoft.com/en-us/investor/default", "financials", "document", true, "\u062A\u0642\u0627\u0631\u064A\u0631 Microsoft \u0641\u0642\u0637\u061B \u0627\u0643\u062A\u0634\u0627\u0641 \u0625\u0641\u0635\u0627\u062D \u0627\u0644\u0634\u0631\u0643\u0629 \u0627\u0644\u0623\u0635\u0644\u064A \u0645\u0646 SEC."]
];
var SOURCE_CANDIDATES = [...sa.map((r) => ({ r, market: "sa" })), ...us.map((r) => ({ r, market: "us" }))].map(({ r: [id, name, url, kind, access, official, setup], market }) => ({
  id,
  name,
  url,
  kind,
  access,
  market,
  setup,
  authority: official ? "official" : "secondary",
  dataTypes: id === "idealratings" ? ["sharia", "purification"] : id === "tadawul" ? ["prices", "financials", "disclosures"] : id === "sec" ? ["financials", "disclosures"] : id === "cma" ? ["regulation", "disclosures"] : [kind],
  docsUrl: id === "bea" ? "https://www.bea.gov/resources/for-developers" : url,
  licenseRequired: access === "licensed-api",
  keyRequired: access === "licensed-api" || ["fred", "eia", "bea"].includes(id),
  coverage: "\u0644\u0645 \u062A\u064F\u062E\u062A\u0628\u0631 \u0627\u0644\u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A\u0629 \u0628\u0639\u062F",
  delayMinutes: null,
  symbolMapping: id === "sec" ? "\u0631\u0645\u0632 \u0627\u0644\u062A\u062F\u0627\u0648\u0644 \u2190 CIK \u0645\u0646 \u062F\u0644\u064A\u0644 SEC \u0627\u0644\u0631\u0633\u0645\u064A" : "\u064A\u062D\u062F\u062F \u0639\u0646\u062F \u062A\u0647\u064A\u0626\u0629 \u0627\u0644\u0642\u0627\u0631\u0626\u061B \u0631\u0627\u0628\u0637 \u0627\u0644\u0635\u0641\u062D\u0629 \u0644\u0627 \u064A\u0631\u0628\u0637 \u0627\u0644\u0631\u0645\u0648\u0632",
  fieldMapping: id === "sec" ? "us-gaap \u2192 \u0628\u0646\u0648\u062F \u0645\u0627\u0644\u064A\u0629\u060C \u0645\u0639 \u0627\u0644\u0641\u062A\u0631\u0629 \u0648\u0627\u0644\u0639\u0645\u0644\u0629 \u0648\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0625\u064A\u062F\u0627\u0639" : "\u064A\u062D\u062F\u062F \u0648\u064A\u062E\u062A\u0628\u0631 \u0642\u0628\u0644 \u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A",
  lineage: id
}));
function candidateMetadata(id) {
  const c = SOURCE_CANDIDATES.find((s) => s.id === id);
  if (!c) return;
  const { name, url, authority, kind, id: _, ...metadata } = c;
  return metadata;
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/admin-config.ts
var HOME_SECTIONS = [["search", "\u0627\u0644\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u0634\u0631\u0643\u0629"], ["ask", "\u0627\u0633\u0623\u0644 \u0645\u064A\u0632\u0627\u0646"], ["welcome", "\u062E\u0637\u0648\u0627\u062A \u0627\u0644\u062A\u062D\u0644\u064A\u0644"], ["company", "\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u062A\u062D\u0644\u064A\u0644"], ["files", "\u0625\u0636\u0627\u0641\u0629 \u0645\u0644\u0641 \u2014 \u0627\u062E\u062A\u064A\u0627\u0631\u064A"], ["sources", "\u0627\u0644\u0645\u0631\u0627\u062C\u0639 \u0627\u0644\u0625\u0636\u0627\u0641\u064A\u0629"], ["workspace", "\u0645\u062A\u0627\u0628\u0639\u0629 \u0648\u0642\u064A\u0627\u0633 \u0645\u064A\u0632\u0627\u0646"], ["sample", "\u0627\u062E\u062A\u0628\u0627\u0631 \u0639\u064A\u0646\u0629 \u0645\u0646 20 \u0634\u0631\u0643\u0629"]];
var COMPANY_SECTIONS = [["decision", "\u063A\u0631\u0641\u0629 \u0627\u0644\u0642\u0631\u0627\u0631"], ["changes", "\u0645\u0627\u0630\u0627 \u062A\u063A\u064A\u0631 \u0645\u0646\u0630 \u0622\u062E\u0631 \u062A\u062D\u0644\u064A\u0644\u061F"], ["pulse", "\u0646\u0628\u0636 \u0627\u0644\u0634\u0631\u0643\u0629"], ["summary", "\u0627\u0644\u062E\u0644\u0627\u0635\u0629 \u0627\u0644\u062A\u062D\u0644\u064A\u0644\u064A\u0629"], ["executive", "\u0627\u0644\u0645\u0644\u062E\u0635 \u0627\u0644\u062A\u0646\u0641\u064A\u0630\u064A"], ["fundamental", "\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u0623\u0633\u0627\u0633\u064A"], ["valuation", "\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u0645\u0627\u0644\u064A \u0648\u0627\u0644\u062A\u0642\u064A\u064A\u0645"], ["chart", "\u0627\u0644\u0634\u0627\u0631\u062A \u0648\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u0641\u0646\u064A"], ["liquidity", "\u0627\u0644\u0633\u064A\u0648\u0644\u0629 \u0648\u0627\u0644\u062A\u0630\u0628\u0630\u0628"], ["news", "\u0627\u0644\u0623\u062E\u0628\u0627\u0631 \u0648\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A"], ["risk", "\u0627\u0644\u0645\u062E\u0627\u0637\u0631"], ["gaps", "\u0645\u0627 \u0627\u0644\u0630\u064A \u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646\u0647\u061F"], ["sources", "\u0627\u0644\u0645\u0635\u0627\u062F\u0631 \u0648\u0637\u0631\u064A\u0642\u0629 \u0627\u062D\u062A\u0633\u0627\u0628 \u0627\u0644\u062F\u0631\u062C\u0629"], ["strengths", "\u0646\u0642\u0627\u0637 \u0627\u0644\u0642\u0648\u0629 \u0648\u0627\u0644\u0636\u0639\u0641"], ["forecasts", "\u0627\u0644\u062A\u0648\u0642\u0639\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u0642\u0628\u0644\u064A\u0629"], ["temporal", "\u0627\u0644\u0645\u062E\u062A\u0628\u0631 \u0627\u0644\u0632\u0645\u0646\u064A"], ["conclusion", "\u062E\u0644\u0627\u0635\u0629 \u0645\u064A\u0632\u0627\u0646"], ["paper", "\u0627\u0644\u0645\u062D\u0641\u0638\u0629 \u0627\u0644\u0648\u0647\u0645\u064A\u0629"], ["private", "\u0645\u064A\u0632\u0627\u0646 \u0627\u0644\u062E\u0627\u0635"]];
var sectionDefaults = (rows) => rows.map(([id, title]) => ({ id, title, visible: true, deleted: false, audience: "everyone" }));
var DEFAULT_SOURCE_CONFIG = [
  { id: "tadawul", name: "\u062A\u062F\u0627\u0648\u0644 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629", url: "https://www.saudiexchange.sa/wps/portal/saudiexchange/ourmarkets/main-market-watch?locale=ar", authority: "official", kind: "financials", adapter: "builtin", enabled: true, deleted: false, priority: 1 },
  { id: "sec", name: "\u0647\u064A\u0626\u0629 \u0627\u0644\u0623\u0648\u0631\u0627\u0642 \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629 SEC", url: "https://www.sec.gov/edgar/search/", authority: "official", kind: "financials", adapter: "builtin", enabled: true, deleted: false, priority: 2 },
  { id: "yahoo", name: "Yahoo Finance", url: "https://finance.yahoo.com/", authority: "secondary", kind: "prices", adapter: "builtin", enabled: true, deleted: false, priority: 3 },
  ...SUPPORTING_SOURCES.filter((s) => !s.official).map((s, i) => ({ id: s.id, name: s.name, url: s.url, authority: "secondary", kind: "general", adapter: "reference", enabled: true, deleted: false, priority: i + 4 }))
];
for (const source of DEFAULT_SOURCE_CONFIG) source.metadata = candidateMetadata(source.id);
for (const c of SOURCE_CANDIDATES) if (!DEFAULT_SOURCE_CONFIG.some((s) => s.id === c.id)) DEFAULT_SOURCE_CONFIG.push({ id: c.id, name: c.name, url: c.url, authority: c.authority, kind: c.kind, adapter: c.id === "alpaca" ? "alpaca" : "reference", enabled: false, deleted: false, priority: DEFAULT_SOURCE_CONFIG.length + 1, metadata: candidateMetadata(c.id) });

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/site-settings.ts
var PERIODS = [1, 5, 21, 63, 126, 252];
var DEFAULT_SETTINGS = {
  description: "\u064A\u0642\u0648\u0645 \u0627\u0644\u0646\u0638\u0627\u0645 \u0628\u0641\u0647\u0645 \u0627\u0644\u0633\u0624\u0627\u0644\u060C \u062B\u0645 \u064A\u0628\u062D\u062B \u0648\u064A\u062D\u0644\u0644 \u0627\u0644\u0634\u0631\u0643\u0627\u062A \u0627\u0644\u0645\u0646\u0627\u0633\u0628\u0629 \u0628\u062F\u0644 \u0645\u0637\u0627\u0644\u0628\u062A\u0643 \u0628\u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0634\u0631\u0643\u0627\u062A \u0648\u0627\u062D\u062F\u0629 \u0648\u0627\u062D\u062F\u0629.",
  market: "sa",
  horizon: "medium",
  count: 5,
  minTurnover: 0,
  enabledMarkets: ["sa", "us", "global"],
  askEnabled: true,
  questions: [],
  detail: "simple",
  tooltips: true,
  expandedHelp: true,
  indicators: { financial: true, technical: true, liquidity: true },
  sources: { yahoo: true, tadawul: true, sec: true },
  periods: Object.fromEntries(PERIODS.map((n) => [String(n), { enabled: true, expanded: false }])),
  weights: { fundamental: 100, technical: 100, liquidity: 100, risk: 100 },
  maxSigma: 3,
  minConfidence: "low",
  trading: { minTurnover: 0, maxVolatility: 150, positiveMomentum: false, excludeHighRisk: false },
  investing: { minTurnover: 0, maxVolatility: 100, positiveCashFlow: false, excludeHighRisk: false },
  paperEnabled: true,
  hiddenMetrics: [],
  sourceConfig: structuredClone(DEFAULT_SOURCE_CONFIG),
  layout: { home: sectionDefaults(HOME_SECTIONS), company: sectionDefaults(COMPANY_SECTIONS) },
  updatedAt: ""
};
function adjustedWeights(base, settings) {
  const group = (k) => ["growth", "quality", "debt", "valuation"].includes(k) ? "fundamental" : ["trend", "momentum", "levels"].includes(k) ? "technical" : k === "liquidity" ? "liquidity" : "risk";
  const w = Object.fromEntries(Object.entries(base).map(([k, v]) => [k, v * settings.weights[group(k)]]));
  const sum = Object.values(w).reduce((s, v) => s + v, 0);
  return Object.fromEntries(Object.entries(w).map(([k, v]) => [k, sum ? v / sum * 100 : 0]));
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/analysis.ts
var LEVELS = ["\u0645\u0646\u062E\u0641\u0636 \u062C\u062F\u0627", "\u0645\u0646\u062E\u0641\u0636", "\u0645\u062A\u0648\u0633\u0637", "\u0645\u0631\u062A\u0641\u0639", "\u0645\u0631\u062A\u0641\u0639 \u062C\u062F\u0627"];
var FIELDS = [
  { key: "revenue", label: "\u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A", group: "\u0627\u0644\u0631\u0628\u062D\u064A\u0629 \u0648\u0627\u0644\u0646\u0645\u0648" },
  { key: "previousRevenue", label: "\u0625\u064A\u0631\u0627\u062F\u0627\u062A \u0627\u0644\u0641\u062A\u0631\u0629 \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629", group: "\u0627\u0644\u0631\u0628\u062D\u064A\u0629 \u0648\u0627\u0644\u0646\u0645\u0648" },
  { key: "netIncome", label: "\u0635\u0627\u0641\u064A \u0627\u0644\u0631\u0628\u062D \u0627\u0644\u0639\u0627\u0626\u062F \u0644\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646", group: "\u0627\u0644\u0631\u0628\u062D\u064A\u0629 \u0648\u0627\u0644\u0646\u0645\u0648" },
  { key: "operatingIncome", label: "\u0627\u0644\u0631\u0628\u062D \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A (EBIT)", group: "\u0627\u0644\u0631\u0628\u062D\u064A\u0629 \u0648\u0627\u0644\u0646\u0645\u0648" },
  { key: "ebitda", label: "EBITDA", group: "\u0627\u0644\u0631\u0628\u062D\u064A\u0629 \u0648\u0627\u0644\u0646\u0645\u0648" },
  { key: "equity", label: "\u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646", group: "\u0627\u0644\u0645\u0644\u0627\u0621\u0629 \u0648\u0627\u0644\u062F\u064A\u0648\u0646" },
  { key: "assets", label: "\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0623\u0635\u0648\u0644", group: "\u0627\u0644\u0645\u0644\u0627\u0621\u0629 \u0648\u0627\u0644\u062F\u064A\u0648\u0646" },
  { key: "liabilities", label: "\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A", group: "\u0627\u0644\u0645\u0644\u0627\u0621\u0629 \u0648\u0627\u0644\u062F\u064A\u0648\u0646" },
  { key: "debt", label: "\u0627\u0644\u062F\u064A\u0648\u0646 \u0627\u0644\u062A\u0645\u0648\u064A\u0644\u064A\u0629", group: "\u0627\u0644\u0645\u0644\u0627\u0621\u0629 \u0648\u0627\u0644\u062F\u064A\u0648\u0646" },
  { key: "cash", label: "\u0627\u0644\u0646\u0642\u062F \u0648\u0645\u0627 \u0641\u064A \u062D\u0643\u0645\u0647", group: "\u0627\u0644\u0645\u0644\u0627\u0621\u0629 \u0648\u0627\u0644\u062F\u064A\u0648\u0646" },
  { key: "currentAssets", label: "\u0627\u0644\u0623\u0635\u0648\u0644 \u0627\u0644\u0645\u062A\u062F\u0627\u0648\u0644\u0629", group: "\u0627\u0644\u0645\u0644\u0627\u0621\u0629 \u0648\u0627\u0644\u062F\u064A\u0648\u0646" },
  { key: "currentLiabilities", label: "\u0627\u0644\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A \u0627\u0644\u0645\u062A\u062F\u0627\u0648\u0644\u0629", group: "\u0627\u0644\u0645\u0644\u0627\u0621\u0629 \u0648\u0627\u0644\u062F\u064A\u0648\u0646" },
  { key: "interestExpense", label: "\u062A\u0643\u0644\u0641\u0629 \u0627\u0644\u062A\u0645\u0648\u064A\u0644 (\u0645\u0648\u062C\u0628\u0629)", group: "\u0627\u0644\u0645\u0644\u0627\u0621\u0629 \u0648\u0627\u0644\u062F\u064A\u0648\u0646" },
  { key: "operatingCashFlow", label: "\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u0646\u0642\u062F\u064A \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A", group: "\u0627\u0644\u0646\u0642\u062F \u0648\u0627\u0644\u062A\u0642\u064A\u064A\u0645" },
  { key: "capex", label: "\u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0627\u0644\u0631\u0623\u0633\u0645\u0627\u0644\u064A (\u0645\u0648\u062C\u0628)", group: "\u0627\u0644\u0646\u0642\u062F \u0648\u0627\u0644\u062A\u0642\u064A\u064A\u0645" },
  { key: "marketCap", label: "\u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0633\u0648\u0642\u064A\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629", group: "\u0627\u0644\u0646\u0642\u062F \u0648\u0627\u0644\u062A\u0642\u064A\u064A\u0645" },
  { key: "peerPE", label: "\u0648\u0633\u064A\u0637 \u0645\u0643\u0631\u0631 \u0631\u0628\u062D\u064A\u0629 \u0627\u0644\u0646\u0638\u0631\u0627\u0621", group: "\u0627\u0644\u0646\u0642\u062F \u0648\u0627\u0644\u062A\u0642\u064A\u064A\u0645" },
  { key: "dividends", label: "\u0627\u0644\u062A\u0648\u0632\u064A\u0639\u0627\u062A \u0627\u0644\u0646\u0642\u062F\u064A\u0629 \u0644\u0644\u0641\u062A\u0631\u0629", group: "\u0627\u0644\u0646\u0642\u062F \u0648\u0627\u0644\u062A\u0642\u064A\u064A\u0645" }
];
var blankFinancials = () => Object.fromEntries(FIELDS.map((f) => [f.key, null]));
var today = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
var blankMeta = () => ({ name: "", symbol: "", market: "sa", currency: "SAR", priceCurrency: "SAR", sector: "general", periodEnd: "", publishedAt: "", period: "annual", unit: "million", priceSource: "", financialSource: "", peerSource: "", asOf: today(), shariaStatus: "unknown", shariaSource: "", shariaDate: "", accounting: "IFRS" });
var blankChecks = () => ({ financial: false, prices: false, events: false });
var blankEvents = () => ({ goingConcern: false, suspended: false, adverseAudit: false, qualifiedAudit: false, upcoming: false });
function finite(x) {
  return typeof x === "number" && Number.isFinite(x);
}
function fmt(v, d = 2) {
  return finite(v) ? new Intl.NumberFormat("en-US", { maximumFractionDigits: d, minimumFractionDigits: 0 }).format(v) : "\u2014";
}
function level(s) {
  return Math.min(4, Math.max(0, Math.floor(s / 20)));
}
function label(s) {
  return s === null ? "\u0628\u064A\u0627\u0646\u0627\u062A \u063A\u064A\u0631 \u0643\u0627\u0641\u064A\u0629" : LEVELS[level(s)];
}
function validDate(s) {
  return /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s)) && new Date(s).toISOString().slice(0, 10) === s;
}
function ageDays(a, b) {
  return (Date.parse(a) - Date.parse(b)) / 864e5;
}
function sma(values, n) {
  let sum = 0;
  return values.map((v, i) => {
    sum += v;
    if (i >= n) sum -= values[i - n];
    return i >= n - 1 ? sum / n : null;
  });
}
function ema(values, n) {
  const out = Array(values.length).fill(null);
  if (values.length < n) return out;
  let prev = values.slice(0, n).reduce((a, b) => a + b, 0) / n;
  out[n - 1] = prev;
  for (let i = n; i < values.length; i++) {
    prev = values[i] * 2 / (n + 1) + prev * (1 - 2 / (n + 1));
    out[i] = prev;
  }
  return out;
}
function rsi(values, n = 14) {
  const out = Array(values.length).fill(null);
  if (values.length <= n) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= n; i++) {
    const d = values[i] - values[i - 1];
    gain += Math.max(d, 0);
    loss += Math.max(-d, 0);
  }
  gain /= n;
  loss /= n;
  const value = () => gain === 0 && loss === 0 ? 50 : loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  out[n] = value();
  for (let i = n + 1; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    gain = (gain * (n - 1) + Math.max(d, 0)) / n;
    loss = (loss * (n - 1) + Math.max(-d, 0)) / n;
    out[i] = value();
  }
  return out;
}
function atr(p, n = 14) {
  const tr = p.map((v, i) => i ? Math.max(v.high - v.low, Math.abs(v.high - p[i - 1].close), Math.abs(v.low - p[i - 1].close)) : v.high - v.low);
  const out = Array(p.length).fill(null);
  if (p.length < n) return out;
  let prev = tr.slice(0, n).reduce((a, b) => a + b, 0) / n;
  out[n - 1] = prev;
  for (let i = n; i < p.length; i++) {
    prev = (prev * (n - 1) + tr[i]) / n;
    out[i] = prev;
  }
  return out;
}
var mean = (v) => v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
var last = (a) => a.length ? a[a.length - 1] : null;
function technical(prices) {
  const close = prices.map((p2) => p2.close), a50 = sma(close, 50), a200 = sma(close, 200), r = rsi(close), a = atr(prices), e12 = ema(close, 12), e26 = ema(close, 26);
  const macd = close.map((_, i) => finite(e12[i]) && finite(e26[i]) ? e12[i] - e26[i] : null);
  const mvals = macd.filter(finite);
  const signal = Array(Math.min(25, prices.length)).fill(null).concat(ema(mvals, 9));
  const macdHist = macd.map((v, i) => finite(v) && finite(signal[i]) ? v - signal[i] : null);
  let peak = 0, maxDD = 0;
  for (const v of close.slice(-252)) {
    peak = Math.max(peak, v);
    if (peak > 0) maxDD = Math.max(maxDD, (peak - v) / peak * 100);
  }
  const returns = close.slice(1).map((v, i) => Math.log(v / close[i])).slice(-60);
  const mu = mean(returns);
  const vol = returns.length >= 20 ? Math.sqrt(returns.reduce((s, v) => s + (v - mu) ** 2, 0) / (returns.length - 1)) * Math.sqrt(252) * 100 : null;
  const p = last(prices), avgV20 = mean(prices.slice(-20).map((p2) => p2.volume)), priorV20 = prices.length >= 40 ? mean(prices.slice(-40, -20).map((p2) => p2.volume)) : null;
  const history = prices.slice(-122);
  const lows = [], highs = [];
  for (let i = 2; i < history.length - 2; i++) {
    const v = history[i], window = history.slice(i - 2, i + 3);
    if (window.every((x) => x.low >= v.low)) lows.push(v.low);
    if (window.every((x) => x.high <= v.high)) highs.push(v.high);
  }
  const below = lows.filter((v) => p && v < p.close), above = highs.filter((v) => p && v > p.close);
  const support = below.length ? Math.max(...below) : null, resistance = above.length ? Math.min(...above) : null;
  return { sma50: a50, sma200: a200, rsi: r, atr: a, macd, signal, macdHist, last: p, atrPct: p && finite(last(a)) ? last(a) / p.close * 100 : null, maxDD: prices.length ? maxDD : null, vol, avgV20, turnover: mean(prices.slice(-20).map((p2) => p2.close * p2.volume)), relativeVolume: p && avgV20 && avgV20 > 0 ? p.volume / avgV20 : null, volumeRatio: avgV20 !== null && priorV20 && priorV20 > 0 ? avgV20 / priorV20 : null, zeroVolume: prices.length >= 20 ? prices.slice(-20).filter((p2) => p2.volume === 0).length : null, support, resistance };
}
var ratio = (a, b) => finite(a) && finite(b) && b > 0 ? a / b : null;
function weighted(f) {
  const v = f.filter((x) => x.score !== null);
  return v.length ? v.reduce((a, b) => a + b.score * b.weight, 0) / v.reduce((a, b) => a + b.weight, 0) : null;
}
function analyze(f, p, m, c, ev) {
  const t = technical(p);
  const factors = [];
  const add = (key, name, category, v, score, weight, reason, rule, suffix = "") => factors.push({ key, name, category, value: v, display: v === null && score !== null ? "\u062D\u0627\u0644\u0629 \u062E\u0627\u0635\u0629" : fmt(v) + (v !== null ? suffix : ""), score: finite(score) ? score : null, weight, reason: v === null && score === null ? "\u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0644\u0627\u0632\u0645\u0629 \u0644\u0647\u0630\u0627 \u0627\u0644\u0639\u0627\u0645\u0644 \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644\u0629." : reason, rule });
  const margin = ratio(f.netIncome, f.revenue);
  add("margin", "\u0647\u0627\u0645\u0634 \u0635\u0627\u0641\u064A \u0627\u0644\u0631\u0628\u062D", "financial", margin === null ? null : margin * 100, margin === null ? null : margin < 0 ? 90 : margin < 0.05 ? 65 : margin < 0.15 ? 40 : 20, 10, margin !== null && margin < 0 ? "\u0627\u0644\u0634\u0631\u0643\u0629 \u062A\u0633\u062C\u0644 \u062E\u0633\u0627\u0631\u0629 \u062E\u0644\u0627\u0644 \u0627\u0644\u0641\u062A\u0631\u0629." : "\u064A\u0642\u064A\u0633 \u0645\u0627 \u064A\u062A\u0628\u0642\u0649 \u0645\u0646 \u0627\u0644\u0625\u064A\u0631\u0627\u062F \u0643\u0631\u0628\u062D\u061B \u064A\u062A\u0623\u062B\u0631 \u0628\u0637\u0628\u064A\u0639\u0629 \u0627\u0644\u0642\u0637\u0627\u0639.", "\u0635\u0627\u0641\u064A \u0627\u0644\u0631\u0628\u062D \xF7 \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A. \u062F\u0631\u062C\u0627\u062A 90 / 65 / 40 / 20 \u0639\u0646\u062F: <0% / <5% / <15% / \u226515%.", "%");
  const growth = finite(f.revenue) && finite(f.previousRevenue) && f.previousRevenue > 0 ? (f.revenue / f.previousRevenue - 1) * 100 : null;
  add("growth", "\u0646\u0645\u0648 \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A", "financial", growth, growth === null ? null : growth < -15 ? 85 : growth < 0 ? 65 : growth < 10 ? 40 : 20, 10, growth !== null && growth < 0 ? "\u062A\u0631\u0627\u062C\u0639\u062A \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A \u0639\u0646 \u0627\u0644\u0641\u062A\u0631\u0629 \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629." : "\u062A\u062A\u0637\u0644\u0628 \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629 \u0646\u0641\u0633 \u0645\u062F\u0629 \u0627\u0644\u0641\u062A\u0631\u0629 \u0648\u0646\u0637\u0627\u0642 \u0627\u0644\u0642\u0648\u0627\u0626\u0645.", "(\u0625\u064A\u0631\u0627\u062F\u0627\u062A \u0627\u0644\u0641\u062A\u0631\u0629 \xF7 \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629 \u2212 1) \xD7 100. \u062F\u0631\u062C\u0627\u062A 85 / 65 / 40 / 20 \u0639\u0646\u062F: <\u221215% / <0% / <10% / \u226510%.", "%");
  const de = ratio(f.debt, f.equity);
  add("de", "\u0627\u0644\u062F\u064A\u0646 \u0625\u0644\u0649 \u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646", "financial", de, finite(f.equity) && f.equity <= 0 ? 100 : de === null ? null : de > 2 ? 90 : de > 1 ? 70 : de > 0.5 ? 45 : 20, 14, "\u0627\u0631\u062A\u0641\u0627\u0639 \u0627\u0644\u0627\u0639\u062A\u0645\u0627\u062F \u0639\u0644\u0649 \u0627\u0644\u062F\u064A\u0646 \u064A\u0632\u064A\u062F \u062D\u0633\u0627\u0633\u064A\u0629 \u0627\u0644\u0634\u0631\u0643\u0629 \u0644\u0644\u062A\u0645\u0648\u064A\u0644.", "\u0627\u0644\u062F\u064A\u0648\u0646 \u0627\u0644\u062A\u0645\u0648\u064A\u0644\u064A\u0629 \xF7 \u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646. \u062F\u0631\u062C\u0627\u062A 90 / 70 / 45 / 20 \u0639\u0646\u062F: >2 / >1 / >0.5 / \u22640.5\u061B \u062D\u0642\u0648\u0642 \u063A\u064A\u0631 \u0645\u0648\u062C\u0628\u0629: 100.", "\xD7");
  const nd = finite(f.debt) && finite(f.cash) ? f.debt - f.cash : null;
  const ndE = ratio(nd, f.ebitda);
  add("nd", "\u0635\u0627\u0641\u064A \u0627\u0644\u062F\u064A\u0646 \u0625\u0644\u0649 EBITDA", "financial", ndE, finite(f.ebitda) && f.ebitda <= 0 && finite(nd) && nd > 0 ? 95 : ndE === null ? null : ndE > 4 ? 90 : ndE > 3 ? 75 : ndE > 1.5 ? 45 : 20, 14, "\u064A\u064F\u0642\u0627\u0631\u0646 \u0639\u0628\u0621 \u0627\u0644\u062F\u064A\u0646 \u0628\u0635\u0627\u0641\u064A \u0627\u0644\u0646\u0642\u062F \u0648\u0627\u0644\u0642\u062F\u0631\u0629 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A\u0629 \u0642\u0628\u0644 \u0627\u0644\u0627\u0633\u062A\u0647\u0644\u0627\u0643.", "(\u0627\u0644\u062F\u064A\u0646 \u2212 \u0627\u0644\u0646\u0642\u062F) \xF7 EBITDA. \u062F\u0631\u062C\u0627\u062A 90 / 75 / 45 / 20 \u0639\u0646\u062F: >4 / >3 / >1.5 / \u22641.5\u061B EBITDA \u063A\u064A\u0631 \u0645\u0648\u062C\u0628\u0629 \u0645\u0639 \u0635\u0627\u0641\u064A \u062F\u064A\u0646 \u0645\u0648\u062C\u0628: 95.", "\xD7");
  const cr = ratio(f.currentAssets, f.currentLiabilities);
  add("current", "\u0627\u0644\u0633\u064A\u0648\u0644\u0629 \u0627\u0644\u062C\u0627\u0631\u064A\u0629", "financial", cr, cr === null ? null : cr < 0.75 ? 90 : cr < 1 ? 75 : cr < 1.5 ? 45 : 20, 12, "\u062A\u0642\u064A\u0633 \u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u0623\u0635\u0648\u0644 \u0627\u0644\u0645\u062A\u062F\u0627\u0648\u0644\u0629 \u0644\u0644\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A \u0627\u0644\u0642\u0635\u064A\u0631\u0629.", "\u0627\u0644\u0623\u0635\u0648\u0644 \u0627\u0644\u0645\u062A\u062F\u0627\u0648\u0644\u0629 \xF7 \u0627\u0644\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A \u0627\u0644\u0645\u062A\u062F\u0627\u0648\u0644\u0629. \u062F\u0631\u062C\u0627\u062A 90 / 75 / 45 / 20 \u0639\u0646\u062F: <0.75 / <1 / <1.5 / \u22651.5.", "\xD7");
  const cc = ratio(f.operatingCashFlow, f.netIncome);
  add("cash", "\u062A\u062D\u0648\u0644 \u0627\u0644\u0623\u0631\u0628\u0627\u062D \u0625\u0644\u0649 \u0646\u0642\u062F", "financial", cc, cc === null ? null : cc < 0 ? 90 : cc < 0.5 ? 75 : cc < 1 ? 45 : 20, 14, "\u0636\u0639\u0641 \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A \u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u0627\u0644\u0623\u0631\u0628\u0627\u062D \u064A\u0633\u062A\u0644\u0632\u0645 \u0645\u0631\u0627\u062C\u0639\u0629 \u062C\u0648\u062F\u0629 \u0627\u0644\u0623\u0631\u0628\u0627\u062D.", "\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A \xF7 \u0627\u0644\u0631\u0628\u062D \u0627\u0644\u0645\u0648\u062C\u0628. \u062F\u0631\u062C\u0627\u062A 90 / 75 / 45 / 20 \u0639\u0646\u062F: <0 / <0.5 / <1 / \u22651\u061B \u0645\u0639 \u062E\u0633\u0627\u0631\u0629 \u0644\u0627 \u064A\u064F\u0641\u0633\u064E\u0651\u0631 \u0647\u0630\u0627 \u0627\u0644\u0645\u0639\u062F\u0644.", "\xD7");
  const fcf = finite(f.operatingCashFlow) && finite(f.capex) ? f.operatingCashFlow - f.capex : null, fcfm = ratio(fcf, f.revenue);
  add("fcf", "\u0647\u0627\u0645\u0634 \u0627\u0644\u0646\u0642\u062F \u0627\u0644\u062D\u0631", "financial", fcfm === null ? null : fcfm * 100, fcfm === null ? null : fcfm < -0.1 ? 85 : fcfm < 0 ? 65 : fcfm < 0.1 ? 40 : 20, 14, "\u0627\u0644\u0646\u0642\u062F \u0628\u0639\u062F \u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0627\u0644\u0631\u0623\u0633\u0645\u0627\u0644\u064A\u061B \u0642\u062F \u064A\u0646\u062E\u0641\u0636 \u0645\u0624\u0642\u062A\u064B\u0627 \u0628\u0633\u0628\u0628 \u0627\u0644\u062A\u0648\u0633\u0639.", "(\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A \u2212 \u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0627\u0644\u0631\u0623\u0633\u0645\u0627\u0644\u064A) \xF7 \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A. \u062F\u0631\u062C\u0627\u062A 85 / 65 / 40 / 20 \u0639\u0646\u062F: <\u221210% / <0% / <10% / \u226510%.", "%");
  const ic = ratio(f.operatingIncome, f.interestExpense);
  add("interest", "\u062A\u063A\u0637\u064A\u0629 \u062A\u0643\u0644\u0641\u0629 \u0627\u0644\u062A\u0645\u0648\u064A\u0644", "financial", ic, f.interestExpense === 0 && finite(f.operatingIncome) && f.operatingIncome > 0 ? 20 : ic === null ? null : ic < 1 ? 95 : ic < 2 ? 75 : ic < 4 ? 45 : 20, 12, "\u062A\u0642\u0627\u0631\u0646 \u0627\u0644\u0623\u0631\u0628\u0627\u062D \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A\u0629 \u0628\u062A\u0643\u0644\u0641\u0629 \u0627\u0644\u062A\u0645\u0648\u064A\u0644 \u0627\u0644\u0633\u0646\u0648\u064A\u0629.", "EBIT \xF7 \u062A\u0643\u0644\u0641\u0629 \u0627\u0644\u062A\u0645\u0648\u064A\u0644. \u062F\u0631\u062C\u0627\u062A 95 / 75 / 45 / 20 \u0639\u0646\u062F: <1 / <2 / <4 / \u22654\u061B \u062A\u0643\u0644\u0641\u0629 \u0635\u0641\u0631 \u0645\u0639 EBIT \u0645\u0648\u062C\u0628: 20.", "\xD7");
  const pe = ratio(f.marketCap, f.netIncome), peR = ratio(pe, f.peerPE);
  add("pe", "\u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0645\u0642\u0627\u0628\u0644 \u0627\u0644\u0646\u0638\u0631\u0627\u0621", "valuation", peR, f.netIncome !== null && f.netIncome <= 0 && finite(f.marketCap) ? 85 : peR === null ? null : peR > 2 ? 90 : peR > 1.5 ? 75 : peR > 1.1 ? 50 : 25, 100, "\u0645\u0643\u0631\u0631 \u0627\u0644\u0634\u0631\u0643\u0629 \u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u0648\u0633\u064A\u0637 \u0646\u0638\u0631\u0627\u0621 \u0645\u0645\u0627\u062B\u0644\u064A\u0646\u061B \u0627\u0644\u0627\u0646\u062E\u0641\u0627\u0636 \u0648\u062D\u062F\u0647 \u0644\u0627 \u064A\u062B\u0628\u062A \u0631\u062E\u0635 \u0627\u0644\u0633\u0647\u0645.", "(\u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0633\u0648\u0642\u064A\u0629 \xF7 \u0631\u0628\u062D 12 \u0634\u0647\u0631\u064B\u0627) \xF7 \u0645\u0643\u0631\u0631 \u0627\u0644\u0646\u0638\u0631\u0627\u0621. \u062F\u0631\u062C\u0627\u062A 90 / 75 / 50 / 25 \u0639\u0646\u062F: >2 / >1.5 / >1.1 / \u22641.1\u061B \u0645\u0639 \u062E\u0633\u0627\u0631\u0629: 85.", "\xD7");
  const lp = t.last?.close ?? null, s50 = last(t.sma50), s200 = last(t.sma200);
  let trend = null;
  if (lp !== null && finite(s50)) trend = finite(s200) ? lp < s50 && s50 < s200 ? 85 : lp > s50 && s50 > s200 ? 20 : 55 : 55;
  add("trend", "\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0633\u0639\u0631", "technical", s50, trend, 30, trend !== null && trend >= 80 ? "\u0627\u0644\u0633\u0639\u0631 \u0623\u0633\u0641\u0644 \u0645\u062A\u0648\u0633\u0637 50\u060C \u0648\u0645\u062A\u0648\u0633\u0637 50 \u0623\u0633\u0641\u0644 200 \u062C\u0644\u0633\u0629." : trend === 20 ? "\u0627\u0644\u0633\u0639\u0631 \u0623\u0639\u0644\u0649 \u0645\u062A\u0648\u0633\u0637 50\u060C \u0648\u0645\u062A\u0648\u0633\u0637 50 \u0623\u0639\u0644\u0649 200 \u062C\u0644\u0633\u0629." : "\u0627\u0644\u0627\u062A\u062C\u0627\u0647 \u0645\u062E\u062A\u0644\u0637 \u0623\u0648 \u062A\u0627\u0631\u064A\u062E 200 \u062C\u0644\u0633\u0629 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D.", "\u062F\u0631\u062C\u0627\u062A 85 \u0644\u0644\u062A\u0631\u062A\u064A\u0628 \u0627\u0644\u0647\u0627\u0628\u0637\u061B 20 \u0644\u0644\u062A\u0631\u062A\u064A\u0628 \u0627\u0644\u0635\u0627\u0639\u062F\u061B 55 \u0644\u0644\u062A\u0631\u062A\u064A\u0628 \u0627\u0644\u0645\u062E\u062A\u0644\u0637 \u0623\u0648 \u063A\u064A\u0627\u0628 \u0645\u062A\u0648\u0633\u0637 200.");
  const ap = t.atrPct;
  add("atr", "\u0627\u062A\u0633\u0627\u0639 \u0627\u0644\u062D\u0631\u0643\u0629 \u0627\u0644\u064A\u0648\u0645\u064A\u0629", "technical", ap, ap === null ? null : ap > 7 ? 95 : ap > 4 ? 75 : ap > 2 ? 55 : ap > 1 ? 30 : 15, 25, "ATR \u064A\u0635\u0641 \u0627\u062A\u0633\u0627\u0639 \u0627\u0644\u062D\u0631\u0643\u0629 \u0628\u0645\u0627 \u064A\u0634\u0645\u0644 \u0627\u0644\u0641\u062C\u0648\u0627\u062A\u060C \u0648\u0644\u0627 \u064A\u062D\u062F\u062F \u0627\u062A\u062C\u0627\u0647\u0647\u0627.", "ATR(14) \u0628\u062A\u0646\u0639\u064A\u0645 Wilder \xF7 \u0622\u062E\u0631 \u0625\u063A\u0644\u0627\u0642. \u062F\u0631\u062C\u0627\u062A 95 / 75 / 55 / 30 / 15 \u0639\u0646\u062F: >7% / >4% / >2% / >1% / \u22641%.", "%");
  const dd = t.maxDD;
  add("drawdown", "\u0623\u0643\u0628\u0631 \u062A\u0631\u0627\u062C\u0639 \u0641\u064A \u0627\u0644\u0646\u0627\u0641\u0630\u0629", "technical", dd, dd === null ? null : dd > 40 ? 90 : dd > 25 ? 75 : dd > 15 ? 55 : dd > 5 ? 35 : 15, 20, "\u0623\u0643\u0628\u0631 \u0647\u0628\u0648\u0637 \u0645\u0646 \u0642\u0645\u0629 \u0625\u0644\u0649 \u0642\u0627\u0639 \u0644\u0627\u062D\u0642 \u062E\u0644\u0627\u0644 \u0622\u062E\u0631 252 \u062C\u0644\u0633\u0629 \u0645\u062A\u0627\u062D\u0629.", "\u0623\u0643\u0628\u0631 \u062A\u0631\u0627\u062C\u0639 \u0646\u0633\u0628\u064A \u0645\u0646 \u0642\u0645\u0629 \u0633\u0627\u0628\u0642\u0629. \u062F\u0631\u062C\u0627\u062A 90 / 75 / 55 / 35 / 15 \u0639\u0646\u062F: >40% / >25% / >15% / >5% / \u22645%.", "%");
  const rv = last(t.rsi);
  add("rsi", "\u062A\u0637\u0631\u0641 \u0627\u0644\u0632\u062E\u0645", "technical", rv, rv === null ? null : rv > 80 || rv < 20 ? 75 : rv > 70 || rv < 30 ? 60 : 35, 15, "\u0627\u0644\u0642\u0631\u0627\u0621\u0627\u062A \u0627\u0644\u0645\u062A\u0637\u0631\u0641\u0629 \u062A\u0631\u0641\u0639 \u0639\u062F\u0645 \u0627\u0644\u064A\u0642\u064A\u0646\u061B \u0644\u064A\u0633\u062A \u0623\u0645\u0631\u064B\u0627 \u0644\u0644\u062A\u062F\u0627\u0648\u0644.", "RSI(14) \u0628\u0637\u0631\u064A\u0642\u0629 Wilder. \u062F\u0631\u062C\u0629 75 \u062E\u0627\u0631\u062C 20\u201380\u061B 60 \u062E\u0627\u0631\u062C 30\u201370\u061B 35 \u0641\u064A\u0645\u0627 \u0639\u062F\u0627 \u0630\u0644\u0643.");
  const zv = t.zeroVolume;
  add("volume", "\u0627\u0633\u062A\u0645\u0631\u0627\u0631\u064A\u0629 \u0627\u0644\u0633\u064A\u0648\u0644\u0629", "technical", t.volumeRatio, zv !== null && zv > 0 ? Math.min(95, 65 + zv * 5) : t.volumeRatio === null ? null : t.volumeRatio < 0.4 ? 75 : t.volumeRatio < 0.7 ? 50 : 25, 10, "\u064A\u0642\u0627\u0631\u0646 \u0645\u062A\u0648\u0633\u0637 \u0627\u0644\u062D\u062C\u0645 \u0644\u0622\u062E\u0631 20 \u062C\u0644\u0633\u0629 \u0628\u0627\u0644\u0639\u0634\u0631\u064A\u0646 \u0627\u0644\u0633\u0627\u0628\u0642\u0629 \u0648\u064A\u0631\u0635\u062F \u0627\u0644\u062C\u0644\u0633\u0627\u062A \u0628\u0644\u0627 \u062A\u062F\u0627\u0648\u0644.", "\u062C\u0644\u0633\u0627\u062A \u0628\u0644\u0627 \u062D\u062C\u0645: 65 + 5 \u0644\u0643\u0644 \u062C\u0644\u0633\u0629\u060C \u062D\u062A\u0649 95\u061B \u0648\u0625\u0644\u0627 \u0646\u0633\u0628\u0629 \u0627\u0644\u062D\u062C\u0645 <0.4: 75\u061B <0.7: 50\u061B \u0645\u0627 \u0639\u062F\u0627 \u0630\u0644\u0643: 25.", "\xD7");
  const eventScore = ev.goingConcern || ev.suspended || ev.adverseAudit ? 100 : ev.qualifiedAudit ? 80 : ev.upcoming ? 65 : 20;
  add("events", "\u0627\u0644\u0623\u062D\u062F\u0627\u062B \u0648\u0627\u0644\u0625\u0641\u0635\u0627\u062D\u0627\u062A", "events", c.events ? eventScore : null, c.events ? eventScore : null, 100, "\u064A\u0639\u062A\u0645\u062F \u0647\u0630\u0627 \u0627\u0644\u0645\u062D\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0648\u0642\u0627\u0626\u0639 \u0627\u0644\u062A\u064A \u0631\u0627\u062C\u0639\u0647\u0627 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0623\u062B\u0628\u062A\u0647\u0627.", "\u0627\u0644\u0627\u0633\u062A\u0645\u0631\u0627\u0631\u064A\u0629/\u0627\u0644\u062A\u0639\u0644\u064A\u0642/\u0631\u0623\u064A \u0633\u0644\u0628\u064A: 100\u061B \u0631\u0623\u064A \u0645\u062A\u062D\u0641\u0638: 80\u061B \u062D\u062F\u062B \u0642\u0631\u064A\u0628: 65\u061B \u0644\u0627 \u062D\u062F\u062B \u0636\u0645\u0646 \u0627\u0644\u0628\u0646\u0648\u062F \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629: 20.");
  const fin = factors.filter((f2) => f2.category === "financial"), finN = fin.filter((f2) => f2.score !== null).length;
  const scores = { financial: weighted(fin), technical: weighted(factors.filter((f2) => f2.category === "technical")), valuation: weighted(factors.filter((f2) => f2.category === "valuation")), events: c.events ? eventScore : null };
  const blockers = [], warnings = [];
  const as = m.asOf;
  if (!c.financial) blockers.push("\u0631\u0627\u062C\u0639 \u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u0648\u0627\u0644\u0641\u062A\u0631\u0629 \u0648\u0627\u0644\u0648\u062D\u062F\u0629 \u0648\u0627\u0639\u062A\u0645\u062F \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629.");
  if (!c.prices) blockers.push("\u0631\u0627\u062C\u0639 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0648\u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0627\u0644\u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0627\u0644\u0631\u0623\u0633\u0645\u0627\u0644\u064A\u0629 \u0648\u0627\u0639\u062A\u0645\u062F\u0647\u0627.");
  if (!c.events) blockers.push("\u0631\u0627\u062C\u0639 \u0623\u062D\u062F\u062B \u0627\u0644\u0625\u0641\u0635\u0627\u062D\u0627\u062A \u0648\u0627\u0644\u0623\u062D\u062F\u0627\u062B \u0627\u0644\u062C\u0648\u0647\u0631\u064A\u0629.");
  if (!m.name.trim() || !m.symbol.trim()) blockers.push("\u0623\u062F\u062E\u0644 \u0627\u0633\u0645 \u0627\u0644\u0634\u0631\u0643\u0629 \u0648\u0631\u0645\u0632 \u0627\u0644\u0648\u0631\u0642\u0629 \u0627\u0644\u0645\u0627\u0644\u064A\u0629.");
  if (!m.financialSource.trim() || !m.priceSource.trim()) blockers.push("\u0633\u062C\u0651\u0644 \u0645\u0635\u062F\u0631 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0648\u0645\u0635\u062F\u0631 \u0627\u0644\u0623\u0633\u0639\u0627\u0631.");
  if (m.sector !== "general") blockers.push("\u0647\u0630\u0627 \u0627\u0644\u0642\u0637\u0627\u0639 \u064A\u062D\u062A\u0627\u062C \u0646\u0645\u0648\u0630\u062C\u064B\u0627 \u0645\u062A\u062E\u0635\u0635\u064B\u0627\u061B \u0627\u0644\u062D\u0633\u0627\u0628 \u0627\u0644\u0639\u0627\u0645 \u0644\u0627 \u064A\u0635\u062F\u0631 \u0644\u0647 \u062A\u0635\u0646\u064A\u0641\u064B\u0627.");
  if (m.period === "interim") blockers.push("\u064A\u0644\u0632\u0645 \u062A\u062C\u0645\u064A\u0639 \u0622\u062E\u0631 12 \u0634\u0647\u0631\u064B\u0627 \u0623\u0648 \u0633\u0646\u0629 \u0643\u0627\u0645\u0644\u0629 \u0642\u0628\u0644 \u0625\u0635\u062F\u0627\u0631 \u0627\u0644\u062A\u0635\u0646\u064A\u0641\u061B \u0644\u0627 \u062A\u064F\u0633\u0646\u0648\u0646 \u0627\u0644\u0623\u0631\u0628\u0627\u062D \u0627\u0644\u0641\u0635\u0644\u064A\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627.");
  if (finN < 7) blockers.push(`\u0627\u0644\u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0627\u0644\u0645\u062A\u0627\u062D\u0629 ${finN} \u0645\u0646 8\u061B \u064A\u0644\u0632\u0645 7 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.`);
  if (p.length < 60) blockers.push("\u064A\u0644\u0632\u0645 \u062A\u0627\u0631\u064A\u062E \u064A\u0648\u0645\u064A \u0644\u0627 \u064A\u0642\u0644 \u0639\u0646 60 \u062C\u0644\u0633\u0629\u060C \u0648\u0627\u0644\u0623\u0641\u0636\u0644 200 \u062C\u0644\u0633\u0629.");
  if (m.currency !== m.priceCurrency) blockers.push("\u0639\u0645\u0644\u0629 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u062A\u062E\u062A\u0644\u0641 \u0639\u0646 \u0639\u0645\u0644\u0629 \u0627\u0644\u0633\u0639\u0631\u061B \u0648\u062D\u0651\u062F \u0627\u0644\u0639\u0645\u0644\u0629 \u0648\u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0633\u0648\u0642\u064A\u0629 \u0623\u0648\u0644\u064B\u0627.");
  if (!validDate(as)) blockers.push("\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D.");
  else if (ageDays(as, today()) > 0) blockers.push("\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0635\u062F\u0627\u0631 \u062A\u0642\u064A\u064A\u0645 \u0643\u0645\u0627 \u0644\u0648 \u0643\u0627\u0646\u062A \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u0642\u0628\u0644\u064A\u0629 \u0645\u062A\u0627\u062D\u0629.");
  if (!validDate(m.periodEnd) || !validDate(m.publishedAt)) blockers.push("\u062D\u062F\u0651\u062F \u062A\u0627\u0631\u064A\u062E \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0641\u062A\u0631\u0629 \u0648\u062A\u0627\u0631\u064A\u062E \u0646\u0634\u0631 \u0627\u0644\u0642\u0648\u0627\u0626\u0645.");
  else if (validDate(as)) {
    if (ageDays(m.publishedAt, m.periodEnd) < 0) blockers.push("\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0646\u0634\u0631 \u064A\u0633\u0628\u0642 \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0641\u062A\u0631\u0629.");
    if (ageDays(as, m.publishedAt) < 0 || ageDays(as, m.periodEnd) < 0) blockers.push("\u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0644\u0645 \u062A\u0643\u0646 \u0645\u062A\u0627\u062D\u0629 \u0641\u064A \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u0642\u064A\u064A\u0645.");
    if (ageDays(as, m.periodEnd) > 550) blockers.push("\u0627\u0644\u0641\u062A\u0631\u0629 \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0642\u062F\u064A\u0645\u0629 \u062C\u062F\u064B\u0627 \u0644\u0647\u0630\u0627 \u0627\u0644\u062A\u0642\u064A\u064A\u0645 (\u0623\u0643\u062B\u0631 \u0645\u0646 550 \u064A\u0648\u0645\u064B\u0627).");
    else if (ageDays(as, m.periodEnd) > 240) warnings.push("\u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0641\u062A\u0631\u0629 \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0645\u0636\u0649 \u0639\u0644\u064A\u0647\u0627 \u0623\u0643\u062B\u0631 \u0645\u0646 240 \u064A\u0648\u0645\u064B\u0627.");
  }
  if (p.length && validDate(as)) {
    if (p.some((v) => ageDays(as, v.date) < 0)) blockers.push("\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062A\u062A\u0636\u0645\u0646 \u062C\u0644\u0633\u0627\u062A \u0644\u0627\u062D\u0642\u0629 \u0644\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u0642\u064A\u064A\u0645.");
    if (ageDays(as, p[p.length - 1].date) > 7) blockers.push("\u0622\u062E\u0631 \u0633\u0639\u0631 \u0623\u0642\u062F\u0645 \u0645\u0646 7 \u0623\u064A\u0627\u0645 \u062A\u0642\u0648\u064A\u0645\u064A\u0629\u061B \u062D\u062F\u0651\u062B \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0623\u0648 \u0627\u062E\u062A\u0631 \u062A\u0627\u0631\u064A\u062E \u062A\u0642\u064A\u064A\u0645 \u062A\u0627\u0631\u064A\u062E\u064A\u064B\u0627.");
  }
  for (const k of ["assets", "liabilities", "debt", "cash", "currentAssets", "currentLiabilities", "interestExpense", "capex", "marketCap", "dividends"]) if (finite(f[k]) && f[k] < 0) blockers.push(`\u0642\u064A\u0645\u0629 \u0633\u0627\u0644\u0628\u0629 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629 \u0641\u064A \xAB${FIELDS.find((v) => v.key === k)?.label}\xBB.`);
  if (finite(f.assets) && finite(f.liabilities) && finite(f.equity) && Math.abs(f.assets - f.liabilities - f.equity) > Math.max(Math.abs(f.assets) * 0.02, 1e-3)) blockers.push("\u0627\u0644\u0623\u0635\u0648\u0644 \u0644\u0627 \u062A\u0633\u0627\u0648\u064A \u0627\u0644\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A + \u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646 \u0636\u0645\u0646 \u0647\u0627\u0645\u0634 2%\u061B \u0631\u0627\u062C\u0639 \u0627\u0644\u0646\u0637\u0627\u0642 \u0648\u0627\u0644\u0648\u062D\u062F\u0629 \u0648\u062D\u0642\u0648\u0642 \u0627\u0644\u0623\u0642\u0644\u064A\u0629.");
  if (finite(f.currentAssets) && finite(f.assets) && f.currentAssets > f.assets) blockers.push("\u0627\u0644\u0623\u0635\u0648\u0644 \u0627\u0644\u0645\u062A\u062F\u0627\u0648\u0644\u0629 \u0623\u0643\u0628\u0631 \u0645\u0646 \u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0623\u0635\u0648\u0644.");
  if (finite(f.currentLiabilities) && finite(f.liabilities) && f.currentLiabilities > f.liabilities) blockers.push("\u0627\u0644\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A \u0627\u0644\u0645\u062A\u062F\u0627\u0648\u0644\u0629 \u0623\u0643\u0628\u0631 \u0645\u0646 \u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0627\u0644\u062A\u0632\u0627\u0645\u0627\u062A.");
  if (p.length > 1) {
    const gap = p.slice(1).some((v, i) => Math.abs(v.close / p[i].close - 1) > 0.4);
    if (gap) warnings.push("\u062A\u063A\u064A\u0631 \u064A\u0648\u0645\u064A \u064A\u062A\u062C\u0627\u0648\u0632 40%: \u0631\u0627\u062C\u0639 \u0627\u0644\u062A\u062C\u0632\u0626\u0629 \u0648\u0627\u0644\u062D\u0642\u0648\u0642 \u0648\u0627\u0644\u062A\u0648\u0632\u064A\u0639\u0627\u062A \u0648\u0633\u0644\u0627\u0645\u0629 \u0627\u0644\u0633\u0644\u0633\u0644\u0629.");
  }
  if (p.length >= 60 && p.length < 200) warnings.push("\u0645\u062A\u0648\u0633\u0637 200 \u062C\u0644\u0633\u0629 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u061B \u0627\u0644\u0627\u062A\u062C\u0627\u0647 \u0637\u0648\u064A\u0644 \u0627\u0644\u0623\u062C\u0644 \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644.");
  if (scores.valuation === null) warnings.push("\u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0646\u0633\u0628\u064A \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644\u061B \u064A\u0644\u0632\u0645 \u0631\u0628\u062D 12 \u0634\u0647\u0631\u064B\u0627 \u0648\u0642\u064A\u0645\u0629 \u0633\u0648\u0642\u064A\u0629 \u0648\u0645\u0643\u0631\u0631 \u0646\u0638\u0631\u0627\u0621 \u0645\u0648\u062B\u0651\u0642.");
  if (finite(f.peerPE) && f.peerPE > 0 && !m.peerSource.trim()) warnings.push("\u0645\u0635\u062F\u0631 \u0645\u0642\u0627\u0631\u0646\u0629 \u0627\u0644\u0646\u0638\u0631\u0627\u0621 \u063A\u064A\u0631 \u0645\u0648\u062B\u0642.");
  if (finN < 8) warnings.push("\u0639\u0627\u0645\u0644 \u0645\u0627\u0644\u064A \u0648\u0627\u062D\u062F \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D.");
  const critical = ev.suspended || ev.goingConcern || ev.adverseAudit || finite(f.equity) && f.equity <= 0;
  const missingCritical = scores.valuation === null || finN < 8 || p.length < 200 || !!(finite(f.peerPE) && !m.peerSource.trim()) || warnings.some((w) => w.includes("240") || w.includes("40%"));
  function composite(mode) {
    if (blockers.length) return null;
    const w = mode === "trader" ? { financial: 0.2, technical: 0.55, valuation: 0.1, events: 0.15 } : { financial: 0.55, technical: 0.15, valuation: 0.2, events: 0.1 };
    let total = Object.entries(w).reduce((sum, [key, weight]) => sum + (scores[key] ?? 60) * weight, 0);
    if (missingCritical) total = Math.max(total, 40);
    if (critical) total = Math.max(total, 85);
    else if (ev.qualifiedAudit) total = Math.max(total, 65);
    return Math.round(Math.min(100, Math.max(0, total)));
  }
  const available = factors.filter((f2) => f2.score !== null).length;
  const coverage = Math.round(available / factors.length * 100);
  return { factors, scores, technical: t, blockers: [...new Set(blockers)], warnings, coverage, trader: composite("trader"), investor: composite("investor"), critical, pe, fcf, dividendYield: finite(f.dividends) && finite(f.marketCap) && f.marketCap > 0 ? f.dividends / f.marketCap * 100 : null, financialCount: finN, version: "1.0.0" };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/source-resolution.ts
function sourceStrength(source) {
  try {
    const u = new URL(source), h = u.hostname.toLowerCase();
    if (u.protocol !== "https:") return 0;
    if (h === "sec.gov" || h.endsWith(".sec.gov") || h === "saudiexchange.sa" || h.endsWith(".saudiexchange.sa") || h === "cma.gov.sa" || h.endsWith(".cma.gov.sa")) return 4;
    if (h.endsWith(".gov") || h.endsWith(".gov.sa")) return 3;
    return 2;
  } catch {
    return 1;
  }
}
function resolveFinancialSources(report) {
  const cutoff = Date.parse(report.asOf + "T23:59:59.999Z");
  const all = [...report.facts, ...report.official?.facts || [], ...report.regulatory?.facts || []];
  const groups = /* @__PURE__ */ new Map();
  for (const raw of all) {
    if (raw.unit && !["base", "thousand", "million"].includes(raw.unit)) continue;
    const f = { ...raw, value: raw.value * (raw.unit === "million" ? 1e6 : raw.unit === "thousand" ? 1e3 : 1), ...raw.unit ? { unit: "base" } : {} };
    if (!finite(f.value) || !validDate(f.date) || f.date > report.asOf || !f.currency || !f.source || f.publishedAt && (!Number.isFinite(Date.parse(f.publishedAt)) || Date.parse(f.publishedAt) > cutoff)) continue;
    const k = [f.key, f.period, f.date, f.currency].join("|"), list = groups.get(k) || [];
    if (!list.some((v) => v.source === f.source && v.value === f.value && v.publishedAt === f.publishedAt)) list.push(f);
    groups.set(k, list);
  }
  const facts = [], comparisons = [];
  for (const list of groups.values()) {
    list.sort((a, b) => sourceStrength(b.source) - sourceStrength(a.source) || (Date.parse(b.publishedAt || "") || 0) - (Date.parse(a.publishedAt || "") || 0) || a.source.localeCompare(b.source));
    const chosen = list[0];
    const ambiguous = list.slice(1).some((other) => sourceStrength(other.source) === sourceStrength(chosen.source) && (other.publishedAt || "") === (chosen.publishedAt || "") && Math.abs(other.value - chosen.value) > Math.max(1, Math.abs(chosen.value) * 5e-3));
    if (!ambiguous) facts.push(chosen);
    for (const other of list.slice(1)) {
      const diff = other.value - chosen.value, disagreed = Math.abs(diff) > Math.max(1, Math.abs(chosen.value) * 5e-3);
      comparisons.push({ ...chosen, providerValue: other.value, alternativeSource: other.source, diff, differencePct: chosen.value ? diff / Math.abs(chosen.value) * 100 : null, disagreed, conflict: false, resolved: !ambiguous, excluded: ambiguous, sameLineage: !!chosen.lineage && chosen.lineage === other.lineage, selectionReason: ambiguous ? "\u0627\u0633\u062A\u064F\u0628\u0639\u062F \u0647\u0630\u0627 \u0627\u0644\u0639\u0627\u0645\u0644 \u0648\u062D\u062F\u0647: \u0627\u062E\u062A\u0644\u0627\u0641 \u0645\u0624\u062B\u0631 \u0628\u064A\u0646 \u0645\u0635\u0627\u062F\u0631 \u0645\u062A\u0633\u0627\u0648\u064A\u0629 \u0641\u064A \u0627\u0644\u0623\u0648\u0644\u0648\u064A\u0629 \u0648\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0646\u0634\u0631\u060C \u062F\u0648\u0646 \u0642\u0631\u064A\u0646\u0629 \u0644\u062A\u0631\u062C\u064A\u062D \u0631\u0642\u0645." : sourceStrength(chosen.source) > sourceStrength(other.source) ? "\u0627\u0644\u0645\u0635\u062F\u0631 \u0627\u0644\u0623\u0639\u0644\u0649 \u0623\u0648\u0644\u0648\u064A\u0629 \u0644\u0644\u0645\u0639\u0644\u0648\u0645\u0629 \u0646\u0641\u0633\u0647\u0627" : chosen.publishedAt !== other.publishedAt ? "\u0627\u0644\u0623\u062D\u062F\u062B \u0646\u0634\u0631\u064B\u0627 \u0628\u064A\u0646 \u0645\u0635\u0627\u062F\u0631 \u0628\u0646\u0641\u0633 \u0627\u0644\u0623\u0648\u0644\u0648\u064A\u0629" : "\u0623\u0631\u0642\u0627\u0645 \u0645\u062A\u0648\u0627\u0641\u0642\u0629 \u0636\u0645\u0646 \u0647\u0627\u0645\u0634 \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629\u061B \u0644\u0627 \u062A\u064F\u062C\u0645\u0639 \u0643\u0645\u0635\u0627\u062F\u0631 \u0645\u0633\u062A\u0642\u0644\u0629" });
    }
  }
  return { facts, comparisons, provisional: facts.some((f) => sourceStrength(f.source) < 4 || !f.publishedAt), changed: comparisons.filter((c) => c.disagreed).length };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/market-data.ts
function latestFact(facts, key, period = "annual", date2) {
  return facts.filter((f) => f.key === key && f.period === period && (date2 === void 0 || f.date === date2)).sort((a, b) => b.date.localeCompare(a.date))[0];
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/automatic-analysis.ts
var divide = (a, b) => finite(a) && finite(b) && b > 0 ? a / b : null;
var percent = (v) => v === null ? null : v * 100;
var average = (a, b) => finite(a) && finite(b) ? (a + b) / 2 : null;
var median = (values) => {
  const v = [...values].sort((a, b) => a - b);
  return v.length ? v.length % 2 ? v[(v.length - 1) / 2] : (v[v.length / 2 - 1] + v[v.length / 2]) / 2 : null;
};
function automaticAnalysis(report, mode = "trader") {
  const resolution = resolveFinancialSources(report), facts = resolution.facts, annualDate = latestFact(facts, "revenue")?.date || latestFact(facts, "netIncome")?.date || "";
  const currency = latestFact(facts, "revenue", "annual", annualDate)?.currency || "";
  const get = (key, date2 = annualDate, period = "annual") => {
    const f = latestFact(facts, key, period, date2);
    return f && f.currency === currency ? f.value : null;
  };
  const annualDates = [...new Set(facts.filter((f) => f.key === "revenue" && f.period === "annual").map((f) => f.date))].sort();
  const previousDate = annualDates.filter((d) => d < annualDate).at(-1) || "";
  const annual = blankFinancials();
  for (const key of Object.keys(annual)) annual[key] = get(key);
  annual.previousRevenue = get("revenue", previousDate);
  const ttmDate = latestFact(facts, "netIncome", "trailing")?.date || "";
  const ttm = (key) => get(key, ttmDate, "trailing");
  const sharesFact = facts.filter((f) => f.key === "shares" && f.period !== "trailing").sort((a, b) => b.date.localeCompare(a.date))[0];
  const price = report.prices.at(-1)?.close ?? null, prevPrice = report.prices.at(-2)?.close ?? null;
  const sharesAffected = !!sharesFact && (report.corporateActions || []).some((c) => c.kind === "split" && c.date > sharesFact.date && c.date <= report.asOf);
  const shares = report.official?.shares ?? (sharesFact && !sharesAffected && ageDays(report.asOf, sharesFact.date) < 210 ? sharesFact.value : null);
  const currencyMatches = currency === report.currency;
  const quoteUnit = report.currency === "GBp" && currency === "GBP" ? 0.01 : report.currency === "ZAc" && currency === "ZAR" ? 0.01 : 1;
  const valuationCurrencyOk = currencyMatches || quoteUnit !== 1;
  const cap = report.official?.marketCap ?? (shares && price ? shares * price * quoteUnit : null);
  const financialCap = valuationCurrencyOk ? cap : null;
  const peerPE = median(report.peers.map((p) => p.pe).filter(finite).filter((p) => p > 0));
  const peerCount = report.peers.filter((p) => finite(p.pe) && p.pe > 0).length;
  const pe = divide(financialCap, ttm("netIncome")), pb = divide(financialCap, annual.equity);
  const enterprise = finite(financialCap) && finite(annual.debt) && finite(annual.cash) && finite(get("minorityInterest")) && finite(get("preferredStock")) ? financialCap + annual.debt + get("minorityInterest") + get("preferredStock") - annual.cash : null;
  const evEbitda = divide(enterprise, ttm("ebitda"));
  const roe = percent(divide(annual.netIncome, average(annual.equity, get("equity", previousDate))));
  const roa = percent(divide(annual.netIncome, average(annual.assets, get("assets", previousDate))));
  const history = annualDates.slice(-3).map((date2) => ({ date: date2, revenue: get("revenue", date2), cfo: get("operatingCashFlow", date2), grossMargin: percent(divide(get("grossProfit", date2), get("revenue", date2))), operatingMargin: percent(divide(get("operatingIncome", date2), get("revenue", date2))) }));
  const cagr = (key) => {
    const first = history[0], last2 = history.at(-1), years = first && last2 ? (Date.parse(last2.date) - Date.parse(first.date)) / (365.25 * 864e5) : 0;
    return history.length >= 3 && first[key] !== null && last2?.[key] !== null && first[key] > 0 && last2[key] > 0 && years > 1.8 && years < 2.2 ? (Math.pow(last2[key] / first[key], 1 / 2) - 1) * 100 : null;
  };
  const avgAssets = average(annual.assets, get("assets", previousDate)), avgEquity = average(annual.equity, get("equity", previousDate));
  const dupont = { margin: divide(annual.netIncome, annual.revenue), turnover: divide(annual.revenue, avgAssets), leverage: divide(avgAssets, avgEquity) };
  const meta = { ...blankMeta(), name: report.company.name, symbol: report.company.symbol, asOf: report.asOf, currency: currency || report.currency, priceCurrency: report.currency, periodEnd: annualDate };
  const base = analyze(annual, report.prices, meta, blankChecks(), blankEvents()), tech = base.technical;
  const sourceComparisons = resolution.comparisons;
  const conflicts = sourceComparisons.filter((c) => c.conflict);
  const blockers = [];
  if (conflicts.length) blockers.push("\u062A\u0639\u0627\u0631\u0636 \u0645\u0627\u0644\u064A \u0628\u064A\u0646 \u0627\u0644\u0645\u0635\u0627\u062F\u0631\u061B \u064A\u0644\u0632\u0645 \u062D\u0633\u0645\u0647 \u0642\u0628\u0644 \u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u062F\u0631\u062C\u0629 \u0623\u0648 \u0645\u0646\u0627\u0637\u0642 \u0627\u0644\u062A\u062F\u0627\u0648\u0644.");
  if (!price || report.prices.length < 60) blockers.push("\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0623\u0642\u0644 \u0645\u0646 60 \u062C\u0644\u0633\u0629.");
  if (tech.last && ageDays(report.asOf, tech.last.date) > 3) blockers.push("\u0622\u062E\u0631 \u0633\u0639\u0631 \u0623\u0642\u062F\u0645 \u0645\u0646 3 \u0623\u064A\u0627\u0645\u061B \u0644\u0627 \u062A\u0635\u0644\u062D \u0627\u0644\u0645\u0633\u062A\u0648\u064A\u0627\u062A \u0643\u0625\u0634\u0627\u0631\u0629 \u062D\u0627\u0644\u064A\u0629.");
  const specialized = report.company.instrument === "ETF" || /bank|insurance|reit|مصرف|بنك|تأمين|ريت/i.test([report.company.name, report.company.sector, report.company.industry].join(" "));
  if (specialized) blockers.push("\u0647\u0630\u0647 \u0627\u0644\u0648\u0631\u0642\u0629 \u062A\u062D\u062A\u0627\u062C \u0646\u0645\u0648\u0630\u062C\u064B\u0627 \u0645\u062A\u062E\u0635\u0635\u064B\u0627\u061B \u062A\u062A\u0627\u062D \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0641\u0646\u064A\u0629 \u062F\u0648\u0646 \u062F\u0631\u062C\u0629 \u0645\u0627\u0644\u064A\u0629 \u0639\u0627\u0645\u0629 \u0623\u0648 \u062A\u0648\u0635\u064A\u0629 \u0634\u0631\u0627\u0621.");
  if (!specialized && (!annualDate || ageDays(report.asOf, annualDate) > 550)) blockers.push("\u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0627\u0644\u0633\u0646\u0648\u064A\u0629 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629 \u0623\u0648 \u0642\u062F\u064A\u0645\u0629 \u062C\u062F\u064B\u0627.");
  if (!specialized && !valuationCurrencyOk) blockers.push("\u0639\u0645\u0644\u0629 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u0644\u0627 \u062A\u0637\u0627\u0628\u0642 \u0639\u0645\u0644\u0629 \u0627\u0644\u0633\u0639\u0631\u061B \u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0646\u0642\u062F\u064A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u062F\u0648\u0646 \u062A\u062D\u0648\u064A\u0644 \u0645\u0648\u062B\u0642.");
  if (finite(annual.equity) && annual.equity <= 0) blockers.push("\u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646 \u063A\u064A\u0631 \u0645\u0648\u062C\u0628\u0629.");
  const bid = report.official?.bid ?? null, ask = report.official?.ask ?? null;
  const spread = finite(bid) && finite(ask) && bid > 0 && ask >= bid ? (ask - bid) / ((ask + bid) / 2) * 100 : null;
  const rsi2 = tech.rsi.at(-1) ?? null, macd = tech.macdHist.at(-1) ?? null, s200 = tech.sma200.at(-1) ?? null, s50 = tech.sma50.at(-1) ?? null;
  const trend = price && finite(s200) && finite(s50) ? price > s50 && s50 > s200 ? 80 : price < s50 && s50 < s200 ? 15 : 45 : null;
  const riskFactors = base.factors.filter((f) => ["atr", "drawdown", "rsi"].includes(f.key) && f.score !== null);
  const technicalSafety = riskFactors.length ? 100 - riskFactors.reduce((s, f) => s + f.score * f.weight, 0) / riskFactors.reduce((s, f) => s + f.weight, 0) : null;
  const financialFactors = base.factors.filter((f) => f.category === "financial" && f.score !== null);
  const financial = financialFactors.length >= 4 ? 100 - financialFactors.reduce((s, f) => s + f.score * f.weight, 0) / financialFactors.reduce((s, f) => s + f.weight, 0) : null;
  const valuation = pe && peerPE && peerCount >= 2 ? pe / peerPE > 2 ? 10 : pe / peerPE > 1.5 ? 25 : pe / peerPE > 1.1 ? 50 : 75 : null;
  const turnover = tech.turnover;
  const liquidity = tech.zeroVolume !== null && turnover !== null ? tech.zeroVolume > 0 ? 15 : tech.volumeRatio !== null && tech.volumeRatio < 0.4 ? 25 : 60 : null;
  const momentum = finite(rsi2) && finite(macd) ? rsi2 > 80 || rsi2 < 20 ? 25 : rsi2 >= 50 && macd > 0 ? 75 : rsi2 < 40 && macd < 0 ? 25 : 50 : null;
  const baseWeights = mode === "investor" ? [40, 20, 10, 5, 15, 10] : [20, 10, 25, 10, 20, 15];
  const modifiers = report.forecast?.settingsUsed?.weights || DEFAULT_SETTINGS.weights;
  const groups = ["fundamental", "fundamental", "technical", "liquidity", "risk", "technical"];
  const rawWeights = baseWeights.map((w, i) => w * modifiers[groups[i]]), weightTotal = rawWeights.reduce((s, v) => s + v, 0);
  const weights = rawWeights.map((w) => weightTotal ? w / weightTotal * 100 : 0);
  const axes = [{ name: "\u0627\u0644\u0642\u0648\u0629 \u0627\u0644\u0645\u0627\u0644\u064A\u0629", value: specialized ? null : financial, weight: weights[0], note: `${financialFactors.length}/8 \u0639\u0648\u0627\u0645\u0644\u061B \u0633\u0646\u0629 ${annualDate || "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629"}` }, { name: "\u0627\u0644\u062A\u0642\u064A\u064A\u0645", value: valuation, weight: weights[1], note: peerCount >= 2 ? "\u0645\u0643\u0631\u0631 \u0622\u062E\u0631 12 \u0634\u0647\u0631\u064B\u0627 \u0645\u0642\u0627\u0628\u0644 \u0639\u064A\u0646\u0629 \u0627\u0644\u0646\u0638\u0631\u0627\u0621" : "\u0644\u0645 \u062A\u0643\u062A\u0645\u0644 \u0639\u064A\u0646\u0629 \u0646\u0638\u0631\u0627\u0621 \u0635\u0627\u0644\u062D\u0629 \u0644\u0644\u0645\u0642\u0627\u0631\u0646\u0629" }, { name: "\u0627\u0644\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0641\u0646\u064A", value: trend, weight: weights[2], note: "\u0627\u0644\u0633\u0639\u0631 \u0648\u0645\u062A\u0648\u0633\u0637\u0627 50 \u0648200 \u062C\u0644\u0633\u0629" }, { name: "\u0627\u0644\u0633\u064A\u0648\u0644\u0629", value: liquidity, weight: weights[3], note: "\u0627\u0633\u062A\u0645\u0631\u0627\u0631\u064A\u0629 \u0627\u0644\u062A\u062F\u0627\u0648\u0644\u061B \u0627\u0644\u0641\u0627\u0631\u0642 \u0627\u0644\u0644\u062D\u0638\u064A \u063A\u064A\u0631 \u0645\u062A\u062D\u0642\u0642" }, { name: "\u062A\u062D\u0645\u0644 \u0627\u0644\u062A\u0630\u0628\u0630\u0628 \u0648\u0627\u0644\u0647\u0628\u0648\u0637", value: technicalSafety, weight: weights[4], note: "ATR \u0648\u0627\u0644\u062A\u0631\u0627\u062C\u0639 \u0627\u0644\u062A\u0627\u0631\u064A\u062E\u064A \u0648\u062A\u0637\u0631\u0641 RSI" }, { name: "\u0627\u0644\u0632\u062E\u0645", value: momentum, weight: weights[5], note: "RSI \u0648MACD" }];
  const coverage = axes.filter((a) => a.value !== null).reduce((s, a) => s + a.weight, 0), weighted2 = axes.reduce((s, a) => s + (a.value ?? 0) * a.weight, 0);
  const score = blockers.length || coverage < 60 ? null : Math.round(weighted2 / coverage);
  const scoreRange = [Math.round(weighted2 / 100), Math.round((weighted2 + (100 - coverage) * 100) / 100)];
  const observedRisk = financial !== null && technicalSafety !== null ? (100 - financial) * 0.45 + (100 - technicalSafety) * 0.55 : technicalSafety === null ? null : 100 - technicalSafety;
  const risk = score === null ? null : Math.max(40, conflicts.length ? 60 : 0, observedRisk ?? 60);
  const missing = ["\u062A\u0635\u0646\u064A\u0641 \u0634\u0631\u0639\u064A \u0644\u0644\u0634\u0631\u0643\u0629 \u0639\u0646 \u0622\u062E\u0631 \u0631\u0628\u0639 \u0648\u0645\u0646\u0647\u062C\u064A\u0629 \u0645\u0639\u0644\u0646\u0629 \u0648\u062A\u0637\u0647\u064A\u0631 \u0627\u0644\u0633\u0647\u0645.", "\u062A\u0642\u0648\u064A\u0645 \u0643\u0627\u0645\u0644 \u0644\u0644\u0646\u062A\u0627\u0626\u062C \u0648\u0627\u0644\u062C\u0645\u0639\u064A\u0627\u062A \u0648\u0627\u0644\u0623\u062D\u062F\u0627\u062B \u0627\u0644\u062C\u0648\u0647\u0631\u064A\u0629 \u0627\u0644\u0642\u0627\u062F\u0645\u0629.", "\u0646\u0635 \u0631\u0623\u064A \u0627\u0644\u0645\u0631\u0627\u062C\u0639 \u0648\u0627\u0644\u062A\u062D\u0641\u0638\u0627\u062A \u0648\u0627\u0644\u0627\u0633\u062A\u0645\u0631\u0627\u0631\u064A\u0629\u061B \u0627\u0633\u0645 \u0627\u0644\u0645\u0631\u0627\u062C\u0639 \u0648\u062D\u062F\u0647 \u0644\u0627 \u064A\u062B\u0628\u062A \u0633\u0644\u0627\u0645\u0629 \u0627\u0644\u0631\u0623\u064A.", "\u062A\u0648\u0642\u064A\u062A \u0644\u0642\u0637\u0629 \u0627\u0644\u0639\u0631\u0636 \u0648\u0627\u0644\u0637\u0644\u0628\u061B \u0648\u0642\u062A \u062C\u0644\u0628 \u0627\u0644\u0635\u0641\u062D\u0629 \u0644\u0627 \u064A\u064F\u0639\u062A\u0628\u0631 \u0648\u0642\u062A \u0627\u0644\u062A\u0633\u0639\u064A\u0631."];
  if (!facts.some((f) => f.publishedAt)) missing.push("\u062A\u0627\u0631\u064A\u062E \u0646\u0634\u0631 \u0645\u0648\u062B\u0642 \u0644\u0643\u0644 \u0628\u0646\u062F \u0645\u0627\u0644\u064A \u0645\u0633\u062A\u0648\u0631\u062F \u0645\u0646 \u0627\u0644\u0645\u0632\u0648\u0651\u062F.");
  if (sharesAffected && !report.official?.shares) missing.push("\u0639\u062F\u062F \u0627\u0644\u0623\u0633\u0647\u0645 \u0627\u0644\u0633\u0627\u0628\u0642 \u0644\u0625\u062C\u0631\u0627\u0621 \u0627\u0644\u062A\u062C\u0632\u0626\u0629 \u0645\u0633\u062A\u0628\u0639\u062F \u0645\u0646 \u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u062D\u062A\u0649 \u062A\u062A\u0637\u0627\u0628\u0642 \u0648\u062D\u062F\u0627\u062A \u0627\u0644\u0633\u0639\u0631 \u0648\u0627\u0644\u0623\u0633\u0647\u0645.");
  for (const c of resolution.comparisons.filter((c2) => c2.excluded)) missing.push(c.key + ": " + c.selectionReason);
  if (peerCount < 2) missing.push("\u0646\u0638\u0631\u0627\u0621 \u0643\u0627\u0641\u0648\u0646 \u0645\u0646 \u0627\u0644\u0646\u0634\u0627\u0637 \u0646\u0641\u0633\u0647 \u0644\u062D\u0633\u0627\u0628 \u0646\u0637\u0627\u0642 \u0642\u064A\u0645\u0629 \u0639\u0627\u062F\u0644 \u0642\u0627\u0628\u0644 \u0644\u0644\u0627\u0639\u062A\u0645\u0627\u062F.");
  if (conflicts.length) missing.push(`${conflicts.length} \u0627\u062E\u062A\u0644\u0627\u0641\u0627\u062A \u0628\u064A\u0646 \u0628\u0646\u0648\u062F \u0627\u0644\u0645\u0635\u062F\u0631\u064A\u0646\u060C \u0642\u062F \u062A\u0646\u062A\u062C \u0639\u0646 \u0627\u062E\u062A\u0644\u0627\u0641 \u0627\u0644\u062A\u0639\u0631\u064A\u0641 \u0623\u0648 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0639\u0631\u0636.`);
  if (!ttmDate) missing.push("\u0623\u0631\u0628\u0627\u062D \u0622\u062E\u0631 12 \u0634\u0647\u0631\u064B\u0627 \u0644\u062D\u0633\u0627\u0628 \u0645\u0643\u0631\u0631 \u0627\u0644\u0631\u0628\u062D\u064A\u0629.");
  const providerQuarter = latestFact(facts, "revenue", "quarterly")?.date || "";
  const officialQuarter = report.official?.facts.filter((f) => f.period === "quarterly").sort((a, b) => b.date.localeCompare(a.date))[0]?.date || "";
  if (officialQuarter > providerQuarter) missing.push(`\u062A\u062F\u0627\u0648\u0644 \u064A\u0639\u0631\u0636 \u0641\u062A\u0631\u0629 \u0623\u062D\u062F\u062B (${officialQuarter}) \u0645\u0646 \u0645\u0632\u0648\u062F \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644 (${providerQuarter || "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D"})\u061B \u0644\u0645 \u062A\u064F\u062E\u0644\u0637 \u0627\u0644\u0641\u062A\u0631\u062A\u0627\u0646.`);
  const strengths = base.factors.filter((f) => f.score !== null && f.score <= 35).slice(0, 4).map((f) => `${f.name}: ${f.display}. ${f.reason}`);
  const weaknesses = base.factors.filter((f) => f.score !== null && f.score >= 60).slice(0, 4).map((f) => `${f.name}: ${f.display}. ${f.reason}`);
  if (conflicts.length) weaknesses.unshift("\u0627\u062E\u062A\u0644\u0627\u0641\u0627\u062A \u0641\u064A \u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u0628\u064A\u0646 \u0627\u0644\u0645\u0635\u0627\u062F\u0631 \u062A\u062D\u062A\u0627\u062C \u062D\u0633\u0645\u064B\u0627 \u0642\u0628\u0644 \u0642\u0631\u0627\u0631 \u0645\u0627\u0644\u064A.");
  if (price && s200 !== null && price < s200) weaknesses.unshift("\u0627\u0644\u0633\u0639\u0631 \u0623\u062F\u0646\u0649 \u0645\u062A\u0648\u0633\u0637 200 \u062C\u0644\u0633\u0629.");
  const opinion = blockers.length ? "\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644" : risk !== null && risk >= 60 ? "\u0645\u062E\u0627\u0637\u0631 \u0645\u0631\u062A\u0641\u0639\u0629 \u2014 \u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062A\u062D\u0642\u0642" : "\u0645\u0631\u0627\u0642\u0628\u0629 \u0645\u0634\u0631\u0648\u0637\u0629 \u2014 \u0627\u0644\u0642\u0631\u0627\u0631 \u0644\u0645 \u064A\u0643\u062A\u0645\u0644";
  const eps = divide(ttm("netIncome"), shares), fair = eps && peerPE && peerCount >= 2 ? [eps * peerPE * 0.8 / quoteUnit, eps * peerPE * 1.2 / quoteUnit] : null;
  const latestQuarterDate = latestFact(facts, "revenue", "quarterly")?.date || "";
  return { factorDetails: base.factors, annual, annualDate, currency, ttmDate, ttmIncome: ttm("netIncome"), latestQuarterDate, latestQuarterRevenue: get("revenue", latestQuarterDate, "quarterly"), latestQuarterIncome: get("netIncome", latestQuarterDate, "quarterly"), price, priceChange: price && prevPrice ? (price / prevPrice - 1) * 100 : null, shares, sharesDate: report.official ? "\u062D\u0633\u0628 \u0635\u0641\u062D\u0629 \u062A\u062F\u0627\u0648\u0644 \u2014 \u0644\u064A\u0633 \u0639\u062F\u062F \u0627\u0644\u0623\u0633\u0647\u0645 \u0627\u0644\u062D\u0631\u0629" : sharesFact?.date || "", cap, pe, pb, evEbitda, roe, roa, dupont, history, cagrRevenue: cagr("revenue"), cagrCfo: cagr("cfo"), grossMargin: percent(divide(get("grossProfit"), annual.revenue)), operatingMargin: percent(divide(annual.operatingIncome, annual.revenue)), netDebtEbitda: divide(finite(annual.debt) && finite(annual.cash) ? annual.debt - annual.cash : null, annual.ebitda), interestCoverage: divide(annual.operatingIncome, annual.interestExpense), cashConversion: divide(annual.operatingCashFlow, annual.netIncome), dividendPayout: percent(divide(annual.dividends, annual.netIncome)), tech, bid, ask, spread, axes, coverage, score, scoreRange, risk, riskLabel: label(risk), blockers, missing, sourceComparisons, strengths, weaknesses, opinion, fair, peerPE, peerCount, specialized, format: (v) => fmt(v) };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/forecast-metrics.ts
var EVALUATION_POLICY = "mizan-end-close-v2";
var number = (v) => typeof v === "number" && Number.isFinite(v);
function directionOf(change, neutralThresholdPct = 0) {
  return change > neutralThresholdPct ? "\u0635\u0627\u0639\u062F" : change < -neutralThresholdPct ? "\u0647\u0627\u0628\u0637" : "\u0645\u062D\u0627\u064A\u062F";
}
function forecastMetrics(input) {
  const { reference: p0, predicted: pf, actual: pt } = input;
  const epsilon = Math.max(1, Math.abs(p0 || 0), Math.abs(pt || 0), Math.abs(pf || 0)) * 1e-12;
  const referenceValid = number(p0) && Math.abs(p0) > epsilon, actualValid = number(pt) && Math.abs(pt) > epsilon, point = number(pf) && number(pt);
  const expectedChange = number(pf) && number(p0) ? pf - p0 : null, actualChange = number(pt) && number(p0) ? pt - p0 : null;
  const expectedChangePct = referenceValid && expectedChange !== null ? 100 * expectedChange / p0 : null, actualChangePct = referenceValid && actualChange !== null ? 100 * actualChange / p0 : null;
  const signedError = point ? pt - pf : null, absoluteError = signedError === null ? null : Math.abs(signedError);
  const relativeErrorPct = actualValid && absoluteError !== null ? 100 * absoluteError / Math.abs(pt) : null;
  const movementErrorPp = expectedChangePct !== null && actualChangePct !== null ? Math.abs(expectedChangePct - actualChangePct) : null;
  const actualDirection = actualChangePct === null ? null : directionOf(actualChangePct, input.neutralThresholdPct ?? 0);
  const range = input.range, rangeValid = Array.isArray(range) && range.length === 2 && range.every(number) && range[0] <= range[1];
  return { expectedChange, expectedChangePct, actualChange, actualChangePct, signedError, absoluteError, relativeErrorPct, movementErrorPp, actualDirection, directionCorrect: actualDirection && ["\u0635\u0627\u0639\u062F", "\u0647\u0627\u0628\u0637", "\u0645\u062D\u0627\u064A\u062F"].includes(input.direction || "") ? actualDirection === input.direction : null, endRangeHit: rangeValid && number(pt) ? pt >= range[0] && pt <= range[1] : null, rangeWidth: rangeValid ? range[1] - range[0] : null, baselineErrorPct: referenceValid && actualValid ? 100 * Math.abs(pt - p0) / Math.abs(pt) : null, pointReason: number(pf) ? null : "\u0644\u0645 \u064A\u0635\u062F\u0631 \u0633\u0639\u0631 \u0645\u0631\u0643\u0632\u064A \u0641\u064A \u0627\u0644\u062A\u0648\u0642\u0639 \u0627\u0644\u0623\u0635\u0644\u064A\u061B \u064A\u064F\u0642\u0627\u0633 \u0627\u062A\u062C\u0627\u0647\u0647 \u0648\u0646\u0637\u0627\u0642\u0647 \u0641\u0642\u0637.", denominatorReason: !referenceValid ? "\u0633\u0639\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0635\u0641\u0631 \u0623\u0648 \u0642\u0631\u064A\u0628 \u0645\u0646 \u0627\u0644\u0635\u0641\u0631\u061B \u0646\u0633\u0628\u0629 \u0627\u0644\u062D\u0631\u0643\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629." : !actualValid ? "\u0633\u0639\u0631 \u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u0635\u0641\u0631 \u0623\u0648 \u0642\u0631\u064A\u0628 \u0645\u0646 \u0627\u0644\u0635\u0641\u0631\u061B \u0627\u0644\u062E\u0637\u0623 \u0627\u0644\u0646\u0633\u0628\u064A \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u060C \u0648\u064A\u064F\u0639\u0631\u0636 \u0627\u0644\u062E\u0637\u0623 \u0627\u0644\u0646\u0642\u062F\u064A." : null };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/forecast-window.ts
function localDate(time, zone) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(time));
}
function localClose(date2, hour, zone) {
  const target = Date.parse(date2 + "T" + String(hour).padStart(2, "0") + ":00:00Z");
  let utc = target;
  for (let i = 0; i < 3; i++) {
    const p = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).formatToParts(new Date(utc)).map((p2) => [p2.type, p2.value]));
    const represented = Date.parse(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}Z`);
    utc += target - represented;
  }
  return new Date(utc).toISOString();
}
function forecastWindow(symbol, sessions, asOf, now, historical = false) {
  const sa2 = symbol.endsWith(".SR"), zone = sa2 ? "Asia/Riyadh" : "America/New_York";
  const knownMarket = sa2 || /^[A-Z][A-Z0-9.-]*$/.test(symbol), anchorDate = historical ? asOf : knownMarket ? localDate(now, zone) : asOf;
  let date2 = anchorDate, count = 0;
  if (knownMarket) while (count < sessions) {
    date2 = new Date(Date.parse(date2 + "T12:00:00Z") + 864e5).toISOString().slice(0, 10);
    const day = (/* @__PURE__ */ new Date(date2 + "T12:00:00Z")).getUTCDay();
    if (sa2 ? day !== 5 && day !== 6 : day !== 0 && day !== 6) count++;
  }
  return {
    anchorDate,
    startAt: historical ? null : new Date(now).toISOString(),
    estimatedEndAt: knownMarket ? localClose(date2, sa2 ? 15 : 16, zone) : null,
    timezone: knownMarket ? zone : null,
    calendarVerified: false,
    definition: sessions === 1 ? "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629 \u0644\u062A\u0627\u0631\u064A\u062E \u0628\u062F\u0621 \u0627\u0644\u062A\u0648\u0642\u0639" : "\u0625\u063A\u0644\u0627\u0642 \u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u062F\u0627\u0648\u0644 \u0631\u0642\u0645 " + sessions + " \u0628\u0639\u062F \u062A\u0627\u0631\u064A\u062E \u0628\u062F\u0621 \u0627\u0644\u062A\u0648\u0642\u0639",
    deadlineNote: "\u0648\u0642\u062A \u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u062A\u0642\u062F\u064A\u0631\u064A: \u064A\u0633\u062A\u062B\u0646\u064A \u0639\u0637\u0644\u0629 \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0623\u0633\u0628\u0648\u0639\u060C \u0648\u0644\u0645 \u064A\u064F\u0631\u0628\u0637 \u062A\u0642\u0648\u064A\u0645 \u0627\u0644\u0639\u0637\u0644\u0627\u062A \u0648\u0627\u0644\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0645\u0628\u0643\u0631. \u0627\u0644\u0642\u064A\u0627\u0633 \u0627\u0644\u0646\u0647\u0627\u0626\u064A \u064A\u0639\u062A\u0645\u062F \u0627\u0644\u062C\u0644\u0633\u0627\u062A \u0627\u0644\u0641\u0639\u0644\u064A\u0629 \u0644\u0627 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0639\u062F \u0627\u0644\u062A\u0642\u062F\u064A\u0631\u064A.",
    successRule: "\u064A\u0642\u0627\u0633 \u0627\u0644\u0627\u062A\u062C\u0627\u0647 \u0648\u0625\u063A\u0644\u0627\u0642 \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0641\u062A\u0631\u0629 \u062F\u0627\u062E\u0644 \u0627\u0644\u0646\u0637\u0627\u0642\u061B \u0644\u0645\u0633 \u0627\u0644\u0647\u062F\u0641 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0641\u062A\u0631\u0629 \u0644\u0627 \u064A\u064F\u0639\u062F \u0646\u062C\u0627\u062D\u064B\u0627 \u0639\u0646\u062F \u0646\u0647\u0627\u064A\u062A\u0647\u0627. \u062D\u062F \u0627\u0644\u062D\u064A\u0627\u062F \u0645\u062B\u0628\u062A \u0641\u064A \u0627\u0644\u062A\u0648\u0642\u0639 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u061B \u0627\u0644\u0633\u062C\u0644\u0627\u062A \u0627\u0644\u0633\u0627\u0628\u0642\u0629 \u062F\u0648\u0646 \u062D\u062F \u0635\u0631\u064A\u062D \u062A\u0633\u062A\u062E\u062F\u0645 \xB11%."
  };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/regime-engine.ts
var RegimeEngine = class {
  static detect(prices) {
    const missing = (reason) => ({ currentRegime: null, probabilities: null, structuralBreakDetected: false, volatilityRatio: null, regimeStabilityScore: null, available: false, calibrated: false, reason });
    if (prices.some((p) => !Number.isFinite(p) || p <= 0)) return missing("\u0623\u0633\u0639\u0627\u0631 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629\u061B \u0644\u0627 \u064A\u0635\u062F\u0631 \u062A\u0635\u0646\u064A\u0641.");
    if (prices.length < 25) return missing("\u064A\u0644\u0632\u0645 25 \u062C\u0644\u0633\u0629 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.");
    const returns = prices.slice(1).map((p, i) => Math.log(p) - Math.log(prices[i]));
    const vol5 = this.calcStdDev(returns.slice(-5));
    const vol20 = this.calcStdDev(returns.slice(-20));
    const ratio2 = vol20 > 1e-12 ? vol5 / vol20 : 1;
    const current = prices[prices.length - 1];
    const sma20 = prices.slice(-20).reduce((s, p) => s + p / 20, 0);
    const z = vol20 > 1e-12 ? (current - sma20) / (vol20 * current) : 0;
    const structuralBreak = vol20 > 1e-12 && (Math.abs(returns.at(-1)) > 2.8 * vol20 || ratio2 > 2.2);
    let bull = 0.2, meanReverting = 0.65, shock = 0.15;
    if (ratio2 > 1.6 || structuralBreak) {
      bull = 0.15;
      meanReverting = 0.15;
      shock = 0.7;
    } else if (z > 1.2 && ratio2 <= 1.2) {
      bull = 0.7;
      meanReverting = 0.2;
      shock = 0.1;
    } else if (z < -1.2 && ratio2 > 1.3) {
      bull = 0.1;
      meanReverting = 0.3;
      shock = 0.6;
    }
    return { available: true, calibrated: false, currentRegime: shock > 0.5 ? "VOLATILITY_SHOCK" : bull > 0.5 ? "BULL_TREND" : "MEAN_REVERTING", probabilities: { bull, meanReverting, shock }, structuralBreakDetected: structuralBreak, volatilityRatio: ratio2, regimeStabilityScore: Math.max(0, Math.min(100, Math.round((1 - (structuralBreak ? 0.6 : 0) - Math.abs(ratio2 - 1) * 0.3) * 100))), reason: "\u062A\u0635\u0646\u064A\u0641 \u0648\u0635\u0641\u064A \u0628\u0627\u0644\u0642\u0648\u0627\u0639\u062F\u061B \u0627\u0644\u0623\u0648\u0632\u0627\u0646 \u0644\u064A\u0633\u062A \u0627\u062D\u062A\u0645\u0627\u0644\u0627\u062A \u0645\u064F\u0639\u0627\u064A\u0631\u0629 \u0648\u0644\u0627 \u0625\u062B\u0628\u0627\u062A\u064B\u0627 \u0644\u0627\u0646\u062E\u0641\u0627\u0636 \u0627\u0644\u0645\u062E\u0627\u0637\u0631 \u0623\u0648 \u0644\u0627\u0646\u0643\u0633\u0627\u0631 \u0647\u064A\u0643\u0644\u064A." };
  }
  static calcStdDev(values) {
    if (values.length < 2) return 0;
    const mean2 = values.reduce((s, v) => s + v, 0) / values.length;
    return Math.sqrt(values.reduce((s, v) => s + (v - mean2) ** 2, 0) / (values.length - 1));
  }
};

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/forecast-conditions.ts
var validDate2 = (date2) => /^\d{4}-\d{2}-\d{2}$/.test(date2) && Number.isFinite(Date.parse(date2 + "T00:00:00Z")) && (/* @__PURE__ */ new Date(date2 + "T00:00:00Z")).toISOString().slice(0, 10) === date2;
var clamp = (n) => Math.max(-1, Math.min(1, n));
var validPublication = (date2) => validDate2(date2.slice(0, 10)) && /^\d{4}-\d{2}-\d{2}(?:T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2}))?$/.test(date2) && Number.isFinite(Date.parse(date2));
function forecastConditions(report, now = Date.now()) {
  const cutoff = Math.min(Date.parse(report.asOf + "T23:59:59.999Z"), now);
  const pricesValid = validDate2(report.asOf) && Number.isFinite(cutoff) && report.prices.every((p, i) => finite(p.close) && p.close > 0 && validDate2(p.date) && p.date <= report.asOf && Date.parse(p.date + "T00:00:00Z") <= cutoff && (!i || report.prices[i - 1].date < p.date));
  const closes = pricesValid ? report.prices.map((p) => p.close) : [];
  const regime = closes.length >= 60 ? RegimeEngine.detect(closes) : {
    ...RegimeEngine.detect([]),
    reason: "\u0644\u0645 \u062A\u062A\u0648\u0641\u0631 60 \u062C\u0644\u0633\u0629 \u0635\u0627\u0644\u062D\u0629 \u0644\u062A\u0637\u0628\u064A\u0642 \u0634\u0631\u0648\u0637 \u062D\u0627\u0644\u0629 \u0627\u0644\u0633\u0648\u0642."
  };
  const volumes = pricesValid ? report.prices.slice(-21).map((p) => p.volume) : [];
  const validVolumes = volumes.length === 21 && volumes.every((v) => finite(v) && v >= 0);
  const average2 = validVolumes ? volumes.slice(0, 20).reduce((s, v) => s + v / 20, 0) : 0;
  const volumeRatio = average2 > 0 ? volumes[20] / average2 : null;
  const relativeVolume = finite(volumeRatio) ? volumeRatio : null;
  const facts = resolveFinancialSources(report).facts.filter((f) => {
    if (!f.publishedAt || !validPublication(f.publishedAt) || !f.source.startsWith("https://")) return false;
    const published = Date.parse(f.publishedAt);
    return finite(published) && published >= Date.parse(f.date + "T00:00:00Z") && published <= cutoff;
  });
  const annual = facts.filter((f) => f.period === "annual" && f.currency === report.currency && ageDays(report.asOf, f.date) <= 550);
  const periodEnd = annual.filter((f) => ["operatingCashFlow", "freeCashFlow"].includes(f.key)).map((f) => f.date).sort().at(-1) ?? null;
  const get = (key) => annual.find((f) => f.key === key && f.date === periodEnd);
  const cfo = get("operatingCashFlow"), capex = get("capex"), direct = get("freeCashFlow");
  const computed = cfo && capex ? cfo.value - Math.abs(capex.value) : null;
  const conflict = finite(computed) && direct && Math.abs(computed - direct.value) > Math.max(1, Math.abs(computed) * 5e-3);
  const candidateFcf = conflict ? null : computed ?? direct?.value ?? null;
  const freeCashFlow = finite(candidateFcf) ? candidateFcf : null;
  const qualitySignal = freeCashFlow !== null && cfo && cfo.value > 0 ? clamp(freeCashFlow / cfo.value) : null;
  const shareFacts = facts.filter((f) => f.key === "shares" && f.period !== "trailing" && f.value > 0 && ageDays(report.asOf, f.date) <= 210).sort((a, b) => b.date.localeCompare(a.date));
  const shares = shareFacts[0];
  const splitAfterShares = shares && report.corporateActions?.some((c) => c.kind === "split" && c.date > shares.date && c.date <= report.asOf);
  const close = closes.at(-1);
  const rawCap = shares && !splitAfterShares && close ? shares.value * close : null;
  const marketCap = finite(rawCap) && rawCap > 0 ? rawCap : null;
  const rawYield = freeCashFlow !== null && marketCap !== null ? freeCashFlow / marketCap * 100 : null;
  const yieldPercent = finite(rawYield) ? rawYield : null;
  const used = freeCashFlow === null ? [] : computed !== null ? [cfo, capex] : [direct];
  if (yieldPercent !== null && shares) used.push(shares);
  const reason = conflict ? "\u0627\u0633\u062A\u064F\u0628\u0639\u062F \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062D\u0631: \u0627\u062E\u062A\u0644\u0627\u0641 \u0628\u064A\u0646 \u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0648\u0627\u0644\u0646\u0627\u062A\u062C \u0645\u0646 \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A \u0648\u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0644\u0646\u0641\u0633 \u0627\u0644\u0641\u062A\u0631\u0629." : freeCashFlow === null ? "\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062D\u0631 \u063A\u064A\u0631 \u0645\u062A\u062D\u0642\u0642\u061B \u064A\u0644\u0632\u0645 \u0645\u0628\u0644\u063A \u0645\u0628\u0627\u0634\u0631 \u0623\u0648 \u062A\u062F\u0641\u0642 \u062A\u0634\u063A\u064A\u0644\u064A \u0648\u0625\u0646\u0641\u0627\u0642 \u0631\u0623\u0633\u0645\u0627\u0644\u064A \u0644\u0646\u0641\u0633 \u0627\u0644\u0633\u0646\u0629 \u0648\u0627\u0644\u0639\u0645\u0644\u0629\u060C \u0628\u0645\u0635\u062F\u0631 \u0648\u062A\u0627\u0631\u064A\u062E \u0646\u0634\u0631 \u0645\u0639\u0631\u0648\u0641\u064A\u0646." : yieldPercent === null ? "\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062D\u0631 \u0645\u062A\u0627\u062D\u061B \u0639\u0627\u0626\u062F\u0647 \u063A\u064A\u0631 \u0645\u0642\u062F\u0651\u0631 \u0644\u063A\u064A\u0627\u0628 \u0639\u062F\u062F \u0623\u0633\u0647\u0645 \u062D\u062F\u064A\u062B \u0635\u0627\u0644\u062D \u0644\u0628\u0646\u0627\u0621 \u0642\u064A\u0645\u0629 \u0633\u0648\u0642\u064A\u0629 \u0645\u0648\u062B\u0642\u0629." : "\u0639\u0627\u0626\u062F \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062D\u0631 \u0646\u0633\u0628\u0629 \u0648\u0635\u0641\u064A\u0629 \u0645\u0646 \u0622\u062E\u0631 \u0633\u0646\u0629 \u0645\u0627\u0644\u064A\u0629\u061B \u0644\u064A\u0633 \u0639\u0627\u0626\u062F \u0627\u0644\u0633\u0647\u0645 \u0627\u0644\u0645\u062A\u0648\u0642\u0639 \u0623\u0648 \u062A\u0643\u0644\u0641\u0629 \u0631\u0623\u0633 \u0627\u0644\u0645\u0627\u0644.";
  const notes = [
    regime.available ? "\u062D\u0627\u0644\u0629 \u0627\u0644\u0633\u0648\u0642 \u0648\u0635\u0641\u064A\u0629\u061B \u0644\u064A\u0633\u062A \u0627\u062D\u062A\u0645\u0627\u0644\u064B\u0627 \u0645\u0639\u0627\u064A\u0631\u064B\u0627 \u0623\u0648 \u062F\u0644\u064A\u0644\u064B\u0627 \u0642\u0627\u0637\u0639\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0627\u0646\u0643\u0633\u0627\u0631 \u0627\u0644\u0647\u064A\u0643\u0644\u064A." : regime.reason,
    relativeVolume === null ? "\u0627\u0644\u062D\u062C\u0645 \u0627\u0644\u0646\u0633\u0628\u064A \u063A\u064A\u0631 \u0645\u062A\u062D\u0642\u0642\u061B \u064A\u0644\u0632\u0645 \u062D\u062C\u0645 \u0627\u0644\u062C\u0644\u0633\u0629 \u064820 \u062C\u0644\u0633\u0629 \u0633\u0627\u0628\u0642\u0629 \u0635\u0627\u0644\u062D\u0629." : `\u0627\u0644\u062D\u062C\u0645 \u0627\u0644\u0646\u0633\u0628\u064A ${relativeVolume.toFixed(2)}\xD7 \u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u0645\u062A\u0648\u0633\u0637 20 \u062C\u0644\u0633\u0629 \u0633\u0627\u0628\u0642\u0629.`,
    reason,
    "\u0644\u0627 \u062A\u064F\u0633\u062A\u0646\u062A\u062C \u0627\u062D\u062A\u0645\u0627\u0644\u0627\u062A \u0635\u0639\u0648\u062F \u0623\u0648 \u062F\u0631\u062C\u0629 \u062B\u0642\u0629 \u0631\u0642\u0645\u064A\u0629 \u0645\u0646 \u0646\u0633\u0628\u0629 \u0641\u0648\u0632 \u0623\u0648 Brier \u0627\u0641\u062A\u0631\u0627\u0636\u064A\u064A\u0646."
  ];
  return {
    version: "fcf-regime-volume-1",
    calibrated: false,
    pricesValid,
    regime,
    relativeVolume,
    cashFlow: {
      freeCashFlow,
      yieldPercent,
      marketCap,
      periodEnd,
      qualitySignal,
      sources: used.map((f) => ({ key: f.key, source: f.source, date: f.date, publishedAt: f.publishedAt })),
      reason
    },
    notes
  };
}
function horizonCondition(conditions, sessions) {
  const shock = conditions.regime.available && (conditions.regime.currentRegime === "VOLATILITY_SHOCK" || conditions.regime.structuralBreakDetected);
  return {
    abstain: shock && sessions <= 21,
    abstainReason: shock && sessions <= 21 ? "\u0627\u0645\u062A\u0646\u0627\u0639 \u0645\u0634\u0631\u0648\u0637: \u0631\u064F\u0635\u062F \u0646\u0645\u0637 \u0635\u062F\u0645\u0629 \u0641\u064A \u0627\u0644\u062A\u0630\u0628\u0630\u0628\u061B \u0644\u0627 \u064A\u0635\u062F\u0631 \u0646\u0637\u0627\u0642 \u0642\u0635\u064A\u0631 \u0627\u0644\u0645\u062F\u0649 \u062D\u062A\u0649 \u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u062D\u0627\u0644\u0629." : null,
    positiveTiltMultiplier: conditions.relativeVolume !== null && conditions.relativeVolume < 1.1 ? 0.6 : 1,
    shock
  };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/conformal-calibration.ts
var CONFORMAL_RANGE_CALIBRATION_ENABLED = false;
var finitePositive = (v) => typeof v === "number" && Number.isFinite(v) && v > 0;
function quantile(values, p) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const i = (sorted.length - 1) * p;
  const lo = Math.floor(i), hi = Math.ceil(i);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (i - lo);
}
function calibrateForecastRange(input) {
  const targetCoverage = input.targetCoverage ?? 0.9;
  const minimum = input.minCalibrationSamples ?? 60;
  const { prices, sessions, center, range } = input;
  if (!Number.isInteger(sessions) || sessions < 1 || !finitePositive(center) || !Array.isArray(range) || range.length !== 2 || !range.every(finitePositive) || range[0] > range[1] || !(targetCoverage > 0 && targetCoverage < 1)) {
    return { status: "invalid", range: null, sample: 0, targetCoverage, empiricalCoverage: null, quantileLogError: null, reason: "\u0645\u062F\u062E\u0644\u0627\u062A \u0645\u0639\u0627\u064A\u0631\u0629 \u0627\u0644\u0646\u0637\u0627\u0642 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629." };
  }
  const closes = prices.map((p) => p.close).filter(finitePositive);
  const returns = [];
  for (let i = sessions; i < closes.length; i++) {
    const value = Math.log(closes[i] / closes[i - sessions]);
    if (Number.isFinite(value)) returns.push(value);
  }
  if (returns.length < minimum) {
    return { status: "insufficient", range: [range[0], range[1]], sample: returns.length, targetCoverage, empiricalCoverage: null, quantileLogError: null, reason: `\u0639\u064A\u0646\u0629 \u0627\u0644\u0645\u0639\u0627\u064A\u0631\u0629 \u063A\u064A\u0631 \u0643\u0627\u0641\u064A\u0629 (${returns.length}/${minimum}).` };
  }
  const centerReturn = quantile(returns, 0.5);
  if (centerReturn === null) {
    return { status: "invalid", range: null, sample: returns.length, targetCoverage, empiricalCoverage: null, quantileLogError: null, reason: "\u062A\u0639\u0630\u0631 \u062D\u0633\u0627\u0628 \u0645\u0631\u0643\u0632 \u0639\u0648\u0627\u0626\u062F \u0627\u0644\u0645\u0639\u0627\u064A\u0631\u0629." };
  }
  const errors = returns.map((value) => Math.abs(value - centerReturn));
  const q = quantile(errors, targetCoverage);
  if (q === null || !Number.isFinite(q)) {
    return { status: "invalid", range: null, sample: returns.length, targetCoverage, empiricalCoverage: null, quantileLogError: null, reason: "\u062A\u0639\u0630\u0631 \u062D\u0633\u0627\u0628 \u0645\u0626\u064A\u0646 \u062E\u0637\u0623 \u0627\u0644\u0645\u0639\u0627\u064A\u0631\u0629." };
  }
  const empiricalCoverage = errors.filter((value) => value <= q).length / errors.length;
  const baseLow = Math.max(0, Math.log(center / range[0]));
  const baseHigh = Math.max(0, Math.log(range[1] / center));
  const low = center * Math.exp(-Math.max(baseLow, q));
  const high = center * Math.exp(Math.max(baseHigh, q));
  if (!finitePositive(low) || !finitePositive(high) || low > high) {
    return { status: "invalid", range: null, sample: returns.length, targetCoverage, empiricalCoverage, quantileLogError: q, reason: "\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u0645\u0639\u0627\u064A\u0631\u0629 \u062E\u0631\u062C\u062A \u0639\u0646 \u0646\u0637\u0627\u0642 \u0633\u0639\u0631\u064A \u0635\u0627\u0644\u062D." };
  }
  return {
    status: "calibrated",
    range: [Number(low.toFixed(2)), Number(high.toFixed(2))],
    sample: returns.length,
    targetCoverage,
    empiricalCoverage,
    quantileLogError: q,
    reason: "\u0646\u0637\u0627\u0642 \u062A\u062C\u0631\u064A\u0628\u064A \u0645\u0648\u0633\u0639 \u0645\u0646 \u062E\u0637\u0623 \u0639\u0648\u0627\u0626\u062F \u062A\u0627\u0631\u064A\u062E\u064A\u0629\u061B \u0644\u0627 \u064A\u0645\u062B\u0644 \u0627\u062D\u062A\u0645\u0627\u0644 \u062A\u062D\u0642\u0642 \u0645\u0633\u062A\u0642\u0628\u0644\u064A\u064B\u0627."
  };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/forecast-horizons.ts
var HORIZONS = [
  { name: "\u064A\u0648\u0645\u064A", sessions: 1 },
  { name: "\u0623\u0633\u0628\u0648\u0639", sessions: 5 },
  { name: "\u0634\u0647\u0631", sessions: 21 },
  { name: "3 \u0623\u0634\u0647\u0631", sessions: 63 },
  { name: "6 \u0623\u0634\u0647\u0631", sessions: 126 },
  { name: "\u0633\u0646\u0629", sessions: 252 }
];

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/research-model.ts
var MODEL_VERSION = "mizan-scenarios-7";
var clamp2 = (v) => Math.max(-1, Math.min(1, v));
var avg = (v) => {
  const x = v.filter(finite);
  return x.length ? x.reduce((s, n) => s + n, 0) / x.length : null;
};
var norm = (v, scale = 1) => finite(v) ? clamp2(v / scale) : null;
var RESEARCH_WEIGHTS = {
  short: { growth: 3, quality: 4, debt: 3, valuation: 3, trend: 20, momentum: 14, liquidity: 18, risk: 10, levels: 10, market: 5, sector: 4, events: 6 },
  medium: { growth: 15, quality: 15, debt: 10, valuation: 15, trend: 10, momentum: 7, liquidity: 8, risk: 7, levels: 4, market: 4, sector: 3, events: 2 },
  long: { growth: 20, quality: 22, debt: 15, valuation: 18, trend: 5, momentum: 2, liquidity: 4, risk: 5, levels: 1, market: 3, sector: 3, events: 2 }
};
function forecastWeights(sessions) {
  if (sessions === 1) return { growth: 0, quality: 1, debt: 0, valuation: 1, trend: 22, momentum: 20, liquidity: 24, risk: 10, levels: 8, market: 10, sector: 2, events: 2 };
  if (sessions <= 5) return RESEARCH_WEIGHTS.short;
  if (sessions <= 21) return { growth: 6, quality: 7, debt: 4, valuation: 9, trend: 16, momentum: 10, liquidity: 16, risk: 9, levels: 7, market: 5, sector: 4, events: 7 };
  if (sessions <= 63) return RESEARCH_WEIGHTS.medium;
  if (sessions <= 126) return Object.fromEntries(Object.keys(RESEARCH_WEIGHTS.medium).map((k) => [k, (RESEARCH_WEIGHTS.medium[k] + RESEARCH_WEIGHTS.long[k]) / 2]));
  return RESEARCH_WEIGHTS.long;
}
function researchFactors(report, now = Date.now()) {
  const a = automaticAnalysis(report);
  const conditioning = forecastConditions(report, now);
  report = { ...report, facts: resolveFinancialSources(report).facts };
  const t = a.tech, price = a.price, source = report.priceSource, financial = report.facts.find((f) => f.key === "revenue")?.source || source, date2 = t.last?.date || "";
  const factors = [];
  const add = (key, name, signal, detail, url = source, asOf = date2) => factors.push({ key, name, signal, detail, source: url, date: asOf });
  const annualFresh = !!a.annualDate && ageDays(report.asOf, a.annualDate) <= 550 && (!a.latestQuarterDate || ageDays(report.asOf, a.latestQuarterDate) <= 210);
  const fsignal = (v) => annualFresh && !a.specialized ? v : null;
  const incomeDates = report.facts.filter((f) => f.key === "netIncome" && f.period === "annual" && f.currency === a.currency).sort((x, y) => x.date.localeCompare(y.date));
  const lastIncome = incomeDates.at(-1), priorIncome = incomeDates.filter((f) => lastIncome && f.date < lastIncome.date).at(-1);
  const incomeGrowth = lastIncome && priorIncome && priorIncome.value > 0 && lastIncome.value > 0 ? (lastIncome.value / priorIncome.value - 1) * 100 : null;
  add("growth", "\u0627\u0644\u0646\u0645\u0648", fsignal(avg([norm(a.cagrRevenue, 25), norm(a.cagrCfo, 25), norm(incomeGrowth, 30)])), `\u0646\u0645\u0648 \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A ${fmt(a.cagrRevenue)}% \u0648\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A ${fmt(a.cagrCfo)}%\u061B \u0646\u0645\u0648 \u0627\u0644\u0631\u0628\u062D \u0627\u0644\u0633\u0646\u0648\u064A ${fmt(incomeGrowth)}%.`, financial, a.annualDate);
  const margins = a.history.map((h) => h.operatingMargin).filter(finite), stability = margins.length >= 3 ? norm(15 - (Math.max(...margins) - Math.min(...margins)), 15) : null;
  const fcf = conditioning.cashFlow, fcfSignal = fcf.periodEnd === a.annualDate ? fcf.qualitySignal : null;
  add("quality", "\u0627\u0644\u0631\u0628\u062D\u064A\u0629 \u0648\u062C\u0648\u062F\u0629 \u0627\u0644\u062A\u062F\u0641\u0642", fsignal(avg([norm(a.cashConversion === null ? null : a.cashConversion - 1), norm(a.operatingMargin, 25), stability, finite(a.annual.operatingCashFlow) ? a.annual.operatingCashFlow > 0 ? 1 : -1 : null, fcfSignal])), `CFO/\u0635\u0627\u0641\u064A \u0627\u0644\u0631\u0628\u062D ${fmt(a.cashConversion)}\u061B \u0627\u0644\u0647\u0627\u0645\u0634 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A ${fmt(a.operatingMargin)}%\u061B ${margins.length} \u0633\u0646\u0648\u0627\u062A \u0647\u0648\u0627\u0645\u0634. \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062D\u0631 ${fmt(fcf.freeCashFlow)} ${report.currency}\u061B \u0623\u062B\u0631\u0647 \u0636\u0645\u0646 \u0627\u0644\u062C\u0648\u062F\u0629 ${fcfSignal === null ? "\u063A\u064A\u0631 \u0645\u062A\u062D\u0642\u0642" : "\u0648\u0635\u0641\u064A \u0648\u0645\u062D\u062F\u0648\u062F \u0628\u0648\u0632\u0646 \u0627\u0644\u062C\u0648\u062F\u0629"}.`, financial, a.annualDate);
  add("debt", "\u0627\u0644\u0642\u062F\u0631\u0629 \u0639\u0644\u0649 \u062E\u062F\u0645\u0629 \u0627\u0644\u062F\u064A\u0646", fsignal(avg([norm(a.netDebtEbitda === null ? null : 3 - a.netDebtEbitda, 3), norm(a.interestCoverage === null ? null : a.interestCoverage - 3, 5)])), `\u0635\u0627\u0641\u064A \u0627\u0644\u062F\u064A\u0646/EBITDA ${fmt(a.netDebtEbitda)}\u061B \u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u062A\u0645\u0648\u064A\u0644 ${fmt(a.interestCoverage)}.`, financial, a.annualDate);
  add("valuation", "\u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0645\u0642\u0627\u0628\u0644 \u0627\u0644\u0646\u0638\u0631\u0627\u0621", fsignal(a.pe && a.peerPE && a.peerCount >= 2 ? clamp2((a.peerPE / a.pe - 1) / 0.5) : null), `P/E ${fmt(a.pe)} \u0645\u0642\u0627\u0628\u0644 ${fmt(a.peerPE)} \u0644\u0639\u064A\u0646\u0629 ${a.peerCount} \u0646\u0638\u0631\u0627\u0621\u061B \u0644\u0627 \u062A\u0645\u062B\u0644 \u0627\u0644\u0642\u0637\u0627\u0639 \u0643\u0644\u0647.`, financial, a.ttmDate);
  const s50 = t.sma50.at(-1), s200 = t.sma200.at(-1), rsi2 = t.rsi.at(-1), macd = t.macdHist.at(-1);
  add("trend", "\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0633\u0639\u0631", price && finite(s50) && finite(s200) ? avg([norm(price / s50 - 1, 0.15), norm(s50 / s200 - 1, 0.15)]) : null, `\u0627\u0644\u0633\u0639\u0631 ${fmt(price)}\u061B \u0645\u062A\u0648\u0633\u0637 50 ${fmt(s50)} \u0648\u0645\u062A\u0648\u0633\u0637 200 ${fmt(s200)}.`);
  add("momentum", "\u0627\u0644\u0632\u062E\u0645 \u0648\u0627\u0644\u062D\u062C\u0645 \u0627\u0644\u0646\u0633\u0628\u064A", avg([finite(rsi2) ? norm(rsi2 - 50, 30) : null, finite(macd) && price ? norm(macd / price, 0.01) : null]), `RSI ${fmt(rsi2)}\u061B MACD ${fmt(macd)}\u061B \u0627\u0644\u062D\u062C\u0645 \u0627\u0644\u0646\u0633\u0628\u064A ${fmt(t.relativeVolume)}\xD7.`);
  add("liquidity", "\u0627\u0644\u0633\u064A\u0648\u0644\u0629 \u0648\u0627\u0633\u062A\u0645\u0631\u0627\u0631\u064A\u0629 \u0627\u0644\u062A\u062F\u0627\u0648\u0644", finite(t.turnover) && t.turnover > 0 && t.zeroVolume !== null ? avg([clamp2((Math.log10(t.turnover) - 6) / 2), t.zeroVolume === 0 ? 0.5 : -1, finite(t.volumeRatio) ? norm(t.volumeRatio - 1) : null]) : null, `\u0645\u062A\u0648\u0633\u0637 \u0642\u064A\u0645\u0629 \u0627\u0644\u062A\u062F\u0627\u0648\u0644 \u0627\u0644\u062A\u0642\u0631\u064A\u0628\u064A ${fmt(t.turnover)} ${report.currency}\u061B \u0623\u064A\u0627\u0645 \u062F\u0648\u0646 \u062D\u062C\u0645 ${t.zeroVolume ?? "\u2014"}\u061B \u0627\u0644\u0641\u0627\u0631\u0642 \u0627\u0644\u0645\u0624\u0631\u062E \u063A\u064A\u0631 \u0645\u062A\u062D\u0642\u0642.`);
  add("risk", "\u0627\u0644\u062A\u0630\u0628\u0630\u0628 \u0648\u0627\u0644\u0647\u0628\u0648\u0637", avg([norm(t.atrPct === null ? null : 3 - t.atrPct, 3), norm(t.maxDD === null ? null : 25 - t.maxDD, 25)]), `ATR ${fmt(t.atrPct)}%\u061B \u0623\u0643\u0628\u0631 \u0647\u0628\u0648\u0637 \u0641\u064A \u0622\u062E\u0631 252 \u062C\u0644\u0633\u0629 ${fmt(t.maxDD)}%.`);
  add("levels", "\u0645\u0648\u0636\u0639 \u0627\u0644\u0633\u0639\u0631 \u0628\u064A\u0646 \u0627\u0644\u062F\u0639\u0645 \u0648\u0627\u0644\u0645\u0642\u0627\u0648\u0645\u0629", price && finite(t.support) && finite(t.resistance) ? clamp2(((t.resistance - price) / (price - t.support) - 2) / 3) : null, `\u062F\u0639\u0645 ${fmt(t.support)}\u061B \u0645\u0642\u0627\u0648\u0645\u0629 ${fmt(t.resistance)}\u061B \u0627\u0644\u0645\u0633\u062A\u0648\u064A\u0627\u062A \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0643\u0633\u0631 \u0648\u0644\u064A\u0633\u062A \u0623\u0648\u0627\u0645\u0631 \u062A\u0646\u0641\u064A\u0630.`);
  for (const key of ["market", "sector"]) {
    const b = report.context?.[key];
    const bt = b ? technical(b.prices) : null;
    const p = bt?.last?.close, b50 = bt?.sma50.at(-1), b200 = bt?.sma200.at(-1);
    const fresh = b && bt?.last && ageDays(report.asOf, bt.last.date) <= 3;
    add(key, key === "market" ? "\u062D\u0627\u0644\u0629 \u0627\u0644\u0633\u0648\u0642" : "\u062D\u0627\u0644\u0629 \u0627\u0644\u0642\u0637\u0627\u0639", fresh && p && finite(b50) && finite(b200) ? avg([norm(p / b50 - 1, 0.15), norm(b50 / b200 - 1, 0.15)]) : null, b ? `${b.name} (${b.symbol})\u061B \u0645\u0624\u0634\u0631 \u0645\u0631\u062C\u0639\u064A\u060C \u0648\u0644\u064A\u0633 \u0643\u0644 \u0627\u0644\u0623\u0648\u0631\u0627\u0642 \u0641\u064A \u0627\u0644\u0633\u0648\u0642.` : "\u0644\u0645 \u064A\u062A\u0648\u0641\u0631 \u0645\u0631\u062C\u0639 \u062D\u062F\u064A\u062B \u0645\u0637\u0627\u0628\u0642.", b?.source || source, bt?.last?.date || "");
  }
  const events = (report.official?.events || []).filter((x) => x.date >= report.asOf && ageDays(x.date, report.asOf) <= 14);
  add("events", "\u0627\u0644\u0625\u0641\u0635\u0627\u062D\u0627\u062A \u0648\u0627\u0644\u0623\u062D\u062F\u0627\u062B \u0627\u0644\u0642\u0631\u064A\u0628\u0629", events.length ? -1 : null, events.length ? events.map((x) => `${x.title} (${x.date})`).join("\u061B ") : `${report.news.length} \u0623\u062E\u0628\u0627\u0631/\u0625\u0641\u0635\u0627\u062D\u0627\u062A \u0645\u062A\u0627\u062D\u0629\u061B \u063A\u064A\u0627\u0628 \u062D\u062F\u062B \u0645\u0624\u0643\u062F \u0644\u0627 \u064A\u0639\u0646\u064A \u062E\u0644\u0648 \u0627\u0644\u062A\u0642\u0648\u064A\u0645. \u0644\u0627 \u0646\u062D\u0648\u0644 \u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0623\u062E\u0628\u0627\u0631 \u0625\u0644\u0649 \u0625\u0634\u0627\u0631\u0629 \u0625\u064A\u062C\u0627\u0628\u064A\u0629.`, report.official?.source || source, report.asOf);
  return { a, factors, incomeGrowth, conditioning };
}
function quantile2(values, p) {
  if (!values.length) return null;
  const v = [...values].sort((a, b) => a - b), i = (v.length - 1) * p, lo = Math.floor(i);
  return v[lo] + (v[Math.ceil(i)] - v[lo]) * (i - lo);
}
function deviation(values) {
  if (values.length < 2) return null;
  const mean2 = values.reduce((s, v) => s + v, 0) / values.length;
  return Math.sqrt(values.reduce((s, v) => s + (v - mean2) ** 2, 0) / (values.length - 1));
}
function dailyReturnRange(prices, sessions) {
  const daily = prices.slice(1).map((p, i) => Math.log(p.close / prices[i].close)).filter(Number.isFinite);
  if (daily.length < 12) return null;
  const median2 = quantile2(daily, 0.5), sigma = deviation(daily);
  if (median2 === null || sigma === null || sigma <= 0) return null;
  return { median: median2 * sessions, low: median2 * sessions - 1.28155 * sigma * Math.sqrt(sessions), high: median2 * sessions + 1.28155 * sigma * Math.sqrt(sessions), sample: daily.length, derived: true };
}
function forecastReadiness(report, now = Date.now()) {
  const last2 = report.prices.at(-1), priceOk = !!last2 && finite(last2.close) && last2.close > 0;
  const pricesOk = report.prices.filter((p) => finite(p.close) && p.close > 0).length >= 20;
  const stale = last2 ? ageDays(new Date(now).toISOString().slice(0, 10), last2.date) : Infinity;
  const priceCheck = report.checks.find((c) => c.name === "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u064A\u0648\u0645\u064A\u0629");
  const { a, factors } = researchFactors(report, now), coverage = factors.filter((f) => f.signal !== null).length;
  const financial = factors.filter((f) => ["growth", "quality", "debt", "valuation"].includes(f.key) && f.signal !== null).length;
  const financialFacts = new Set(resolveFinancialSources(report).facts.filter((f) => ["revenue", "netIncome", "operatingIncome", "operatingCashFlow", "freeCashFlow", "debt", "cash", "equity", "ebitda"].includes(f.key) && finite(f.value) && f.currency === report.currency).map((f) => f.key)).size;
  const warnings = [];
  if (priceCheck?.state !== "ok") warnings.push(pricesOk ? "\u0644\u0645 \u064A\u0643\u062A\u0645\u0644 \u062A\u062D\u0642\u0642 \u0627\u0644\u0645\u0635\u062F\u0631\u060C \u0644\u0643\u0646 \u062A\u0648\u062C\u062F \u0633\u0644\u0633\u0644\u0629 \u0633\u0639\u0631\u064A\u0629 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0642\u0631\u0627\u0621\u0629." : "\u0644\u0645 \u062A\u0635\u0644 \u0633\u0644\u0633\u0644\u0629 \u0633\u0639\u0631\u064A\u0629 \u0643\u0627\u0641\u064A\u0629\u061B \u0644\u0627 \u0646\u0639\u062A\u0628\u0631 \u063A\u064A\u0627\u0628 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0628\u064A\u0627\u0646\u0627\u062A \u0635\u0627\u0644\u062D\u0629.");
  if (stale > 3) warnings.push(`\u0622\u062E\u0631 \u062C\u0644\u0633\u0629 \u0633\u0639\u0631\u064A\u0629 \u0628\u062A\u0627\u0631\u064A\u062E ${last2?.date || "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D"}\u061B \u0642\u062F \u0644\u0627 \u062A\u0645\u062B\u0644 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0644\u062D\u0638\u064A.`);
  if (financialFacts < 2) warnings.push("\u062F\u0631\u062C\u0629 \u0627\u0644\u062B\u0642\u0629 \u0645\u0646\u062E\u0641\u0636\u0629 \u0628\u0633\u0628\u0628 \u0646\u0642\u0635 \u0628\u0639\u0636 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629.");
  if (a.sourceComparisons.some((item) => item.disagreed && item.resolved)) warnings.push("\u0627\u0639\u062A\u064F\u0645\u062F \u0627\u0644\u0645\u0635\u062F\u0631 \u0627\u0644\u0623\u0639\u0644\u0649 \u0623\u0648\u0644\u0648\u064A\u0629 \u0639\u0646\u062F \u0627\u062E\u062A\u0644\u0627\u0641 \u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0645\u062A\u0642\u0627\u0628\u0644\u0629\u061B \u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u0642\u064A\u0645 \u0627\u0644\u0623\u0635\u0644\u064A\u0629 \u0645\u062D\u0641\u0648\u0638\u0629 \u0641\u064A \u0627\u0644\u0645\u0635\u0627\u062F\u0631.");
  if (a.sourceComparisons.some((item) => item.excluded)) warnings.push("\u0627\u0633\u062A\u064F\u0628\u0639\u062F \u0627\u0644\u0639\u0627\u0645\u0644 \u0627\u0644\u0645\u062E\u062A\u0644\u0641 \u0639\u0644\u064A\u0647 \u0628\u064A\u0646 \u0645\u0635\u0627\u062F\u0631 \u0645\u062A\u0633\u0627\u0648\u064A\u0629\u061B \u062A\u0633\u062A\u0645\u0631 \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u0628\u0627\u0644\u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u0623\u062E\u0631\u0649 \u062F\u0648\u0646 \u0627\u062E\u062A\u064A\u0627\u0631 \u0631\u0642\u0645 \u0639\u0634\u0648\u0627\u0626\u064A.");
  if (!report.context?.market || !report.context?.sector) warnings.push("\u0645\u0631\u062C\u0639 \u0627\u0644\u0633\u0648\u0642 \u0623\u0648 \u0627\u0644\u0642\u0637\u0627\u0639 \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644\u061B \u064A\u064F\u062E\u0641\u0651\u0636 \u0648\u0632\u0646 \u0627\u0644\u0633\u064A\u0627\u0642 \u0627\u0644\u062E\u0627\u0631\u062C\u064A.");
  if (!report.news.some((n) => n.contentRead)) warnings.push("\u0627\u0644\u0623\u062E\u0628\u0627\u0631 \u0648\u0627\u0644\u0625\u0641\u0635\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u062D\u0629 \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644\u0629\u061B \u0644\u0627 \u064A\u0639\u0646\u064A \u0630\u0644\u0643 \u063A\u064A\u0627\u0628 \u0627\u0644\u0623\u062D\u062F\u0627\u062B.");
  if (report.mode === "historical") warnings.push("\u0647\u0630\u0627 \u062A\u0642\u062F\u064A\u0631 \u0639\u0644\u0649 \u0644\u0642\u0637\u0629 \u062A\u0627\u0631\u064A\u062E\u064A\u0629\u060C \u0648\u0644\u064A\u0633 \u062A\u0648\u0642\u0639\u064B\u0627 \u062D\u064A\u064B\u0627 \u0644\u0644\u0633\u0648\u0642 \u0627\u0644\u062D\u0627\u0644\u064A.");
  const unavailable = [];
  if (!priceOk || !pricesOk) unavailable.push("\u0644\u0627 \u062A\u0648\u062C\u062F \u0633\u0644\u0633\u0644\u0629 \u0633\u0639\u0631\u064A\u0629 \u0635\u0627\u0644\u062D\u0629 \u0644\u0627 \u062A\u0642\u0644 \u0639\u0646 20 \u062C\u0644\u0633\u0629.");
  if (stale > 21) unavailable.push("\u0622\u062E\u0631 \u0633\u0639\u0631 \u0642\u062F\u064A\u0645 \u062C\u062F\u064B\u0627 \u0644\u0625\u0635\u062F\u0627\u0631 \u062A\u0648\u0642\u0639 \u0645\u0641\u064A\u062F.");
  let quality = unavailable.length ? "\u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629" : stale <= 3 && report.prices.length >= 252 && financial >= 3 && financialFacts >= 3 && coverage >= 7 ? "\u0645\u0645\u062A\u0627\u0632\u0629" : stale <= 7 && report.prices.length >= 120 && financialFacts >= 2 && coverage >= 4 ? "\u062C\u064A\u062F\u0629" : report.prices.length >= 60 ? "\u0645\u062A\u0648\u0633\u0637\u0629" : "\u0636\u0639\u064A\u0641\u0629";
  if (quality === "\u0645\u0645\u062A\u0627\u0632\u0629" && (!report.context?.market || !report.context?.sector || !report.news.some((n) => n.contentRead))) quality = "\u062C\u064A\u062F\u0629";
  if (a.sourceComparisons.some((item) => item.conflict) && !unavailable.length) quality = "\u0645\u062A\u0648\u0633\u0637\u0629";
  if (report.facts.some((f) => f.source.startsWith("\u0645\u0644\u0641 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:")) && !unavailable.length) {
    quality = "\u0645\u062A\u0648\u0633\u0637\u0629";
    warnings.push("\u062A\u0648\u062C\u062F \u0628\u0646\u0648\u062F \u0645\u0646 \u0645\u0644\u0641 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0644\u0645 \u064A\u062A\u062D\u0642\u0642 \u0645\u0635\u062F\u0631\u0647\u0627 \u0645\u0633\u062A\u0642\u0644\u064B\u0627\u061B \u062E\u064F\u0641\u0636\u062A \u0627\u0644\u062B\u0642\u0629.");
  }
  const provisional = resolveFinancialSources(report).provisional;
  const limitedFeed = report.priceCoverage?.includes("IEX");
  if (limitedFeed) warnings.push("\u062A\u063A\u0637\u064A\u0629 IEX \u0645\u062D\u062F\u0648\u062F\u0629\u061B \u0644\u0627 \u064A\u0645\u062B\u0644 \u062D\u062C\u0645\u0647\u0627 \u062D\u062C\u0645 \u0627\u0644\u0633\u0648\u0642 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A \u0627\u0644\u0645\u062C\u0645\u0639\u060C \u0648\u0627\u0644\u062B\u0642\u0629 \u0645\u0646\u062E\u0641\u0636\u0629.");
  if (provisional) warnings.push("\u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0623\u0648\u0644\u064A: \u0628\u0639\u0636 \u0627\u0644\u0645\u0635\u0627\u062F\u0631 \u062B\u0627\u0646\u0648\u064A\u0629 \u0623\u0648 \u0644\u0627 \u062A\u062D\u0645\u0644 \u062A\u0627\u0631\u064A\u062E \u0646\u0634\u0631 \u0645\u0648\u062B\u0642\u064B\u0627\u061B \u062E\u064F\u0641\u0636\u062A \u0627\u0644\u062B\u0642\u0629 \u0648\u0644\u0645 \u062A\u062A\u0648\u0642\u0641 \u0627\u0644\u0642\u0631\u0627\u0621\u0629.");
  const confidence = provisional || limitedFeed ? "\u0645\u0646\u062E\u0641\u0636" : quality === "\u0645\u0645\u062A\u0627\u0632\u0629" ? "\u0645\u062A\u0648\u0633\u0637" : quality === "\u062C\u064A\u062F\u0629" ? "\u0645\u062A\u0648\u0633\u0637" : "\u0645\u0646\u062E\u0641\u0636";
  return { quality, confidence, warnings, unavailable, financial, financialFacts, coverage, stale, priceCount: report.prices.length };
}
function forecasts(report, quote = null, now = Date.now(), settings = DEFAULT_SETTINGS, horizons = HORIZONS) {
  const { a, factors, conditioning } = researchFactors(report, now), last2 = report.prices.at(-1);
  const quoteUsable = report.mode !== "historical" && quote && finite(quote.price) && quote.price > 0 && quote.symbol === report.company.symbol && quote.currency === report.currency && now - Date.parse(quote.quoteTime) >= 0 && now - Date.parse(quote.quoteTime) <= 15 * 6e4;
  const price = quoteUsable ? quote.price : last2?.close ?? null;
  const readiness = forecastReadiness(report, now);
  const missing = factors.filter((f) => f.signal === null).map((f) => `${f.name}: ${f.detail}`);
  const rows = horizons.map((h) => {
    const condition = horizonCondition(conditioning, h.sessions);
    const modelCondition = { ...condition, calibrated: false, regime: conditioning.regime.currentRegime, relativeVolume: conditioning.relativeVolume, cashFlow: conditioning.cashFlow, notes: conditioning.notes };
    const window = forecastWindow(report.company.symbol, h.sessions, report.asOf, now, report.mode === "historical");
    const weights = adjustedWeights(forecastWeights(h.sessions), settings);
    const available = factors.filter((f) => f.signal !== null), coverage = available.reduce((s, f) => s + weights[f.key], 0);
    const reasons = [...readiness.unavailable];
    if (!conditioning.pricesValid) reasons.push("\u0633\u0644\u0633\u0644\u0629 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062A\u062D\u0648\u064A \u0642\u064A\u0645\u0629 \u0623\u0648 \u062A\u0627\u0631\u064A\u062E\u064B\u0627 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u060C \u0623\u0648 \u062C\u0644\u0633\u0627\u062A \u0645\u0643\u0631\u0631\u0629/\u063A\u064A\u0631 \u0645\u0631\u062A\u0628\u0629/\u0628\u0639\u062F \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0642\u0637\u0639.");
    if (condition.abstainReason) reasons.push(condition.abstainReason);
    if (h.sessions === 1 && report.mode !== "historical" && readiness.stale > 4) reasons.push("\u0622\u062E\u0631 \u062C\u0644\u0633\u0629 \u0642\u062F\u064A\u0645\u0629 \u062C\u062F\u064B\u0627 \u0644\u062A\u0648\u0642\u0639 \u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629.");
    if (settings.periods[h.sessions]?.enabled === false) reasons.push("\u0623\u0648\u0642\u0641\u062A \u0647\u0630\u0647 \u0627\u0644\u0645\u062F\u0629 \u0645\u0646 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0625\u062F\u0627\u0631\u0629\u061B \u064A\u0645\u0643\u0646\u0643 \u0625\u0639\u0627\u062F\u0629 \u062A\u0634\u063A\u064A\u0644\u0647\u0627.");
    const returns = [];
    for (let i = h.sessions; i < report.prices.length; i++) returns.push(Math.log(report.prices[i].close / report.prices[i - h.sessions].close));
    const median2 = quantile2(returns, 0.5), q10 = quantile2(returns, 0.1), q90 = quantile2(returns, 0.9), fallback = dailyReturnRange(report.prices, h.sessions);
    const history = median2 !== null && q10 !== null && q90 !== null && q90 - q10 > 0 ? { median: median2, low: q10, high: q90, sample: returns.length, derived: false } : fallback;
    if (!price || history === null) reasons.push("\u0644\u0627 \u062A\u062A\u0648\u0641\u0631 \u0639\u064A\u0646\u0629 \u062A\u0630\u0628\u0630\u0628 \u0633\u0639\u0631\u064A\u0629 \u0635\u0627\u0644\u062D\u0629 \u0644\u0628\u0646\u0627\u0621 \u0646\u0637\u0627\u0642 \u0627\u0633\u062A\u0631\u0634\u0627\u062F\u064A.");
    const basis = available.sort((x, y) => Math.abs(y.signal) * weights[y.key] - Math.abs(x.signal) * weights[x.key]).slice(0, 6).map((f) => `${f.name}: ${f.detail}`);
    const contributions = factors.map((f) => ({ name: f.name, weight: weights[f.key], impact: f.signal === null ? null : Math.round(f.signal * weights[f.key] * 100) / 100 }));
    const invalidation = [...finite(a.tech.support) ? [`\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0633\u0639\u0631 \u062F\u0648\u0646 \u0627\u0644\u062F\u0639\u0645 ${fmt(a.tech.support)} \u064A\u0633\u062A\u062F\u0639\u064A \u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u0641\u0631\u0636\u064A\u0629 \u0627\u0644\u0641\u0646\u064A\u0629.`] : [], h.sessions === 1 ? "\u0627\u0646\u0639\u0643\u0627\u0633 \u0627\u0644\u0632\u062E\u0645 \u0623\u0648 \u0627\u0646\u0643\u0645\u0627\u0634 \u0627\u0644\u0633\u064A\u0648\u0644\u0629 \u0641\u064A \u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629 \u064A\u0628\u0637\u0644 \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0642\u0635\u064A\u0631\u0629." : "\u062A\u0631\u0627\u062C\u0639 \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A \u0623\u0648 \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A \u0641\u064A \u0646\u062A\u0627\u0626\u062C \u062C\u062F\u064A\u062F\u0629 \u064A\u0636\u0639\u0641 \u0641\u0631\u0636\u064A\u0629 \u0627\u0644\u0646\u0645\u0648.", "\u0625\u0639\u0644\u0627\u0646 \u062C\u0648\u0647\u0631\u064A \u0645\u062E\u0627\u0644\u0641 \u0644\u0644\u0641\u0631\u0636\u064A\u0627\u062A \u0623\u0648 \u062A\u063A\u064A\u0631 \u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0633\u0648\u0642 \u0648\u0627\u0644\u0642\u0637\u0627\u0639 \u064A\u0633\u062A\u062F\u0639\u064A \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u062D\u0644\u064A\u0644."];
    const risks = [...invalidation, ...a.weaknesses, ...missing, ...readiness.warnings, "\u062A\u063A\u064A\u0631 \u0627\u0644\u0646\u0638\u0627\u0645 \u0627\u0644\u0633\u0648\u0642\u064A \u0623\u0648 \u0627\u0644\u0623\u0631\u0628\u0627\u062D \u0648\u0627\u0644\u0633\u064A\u0648\u0644\u0629 \u0642\u062F \u064A\u062E\u0631\u062C \u0627\u0644\u0633\u0639\u0631 \u0639\u0646 \u0627\u0644\u0646\u0637\u0627\u0642.", "\u0627\u0644\u062A\u0648\u0632\u064A\u0639\u0627\u062A \u0627\u0644\u0646\u0642\u062F\u064A\u0629 \u0648\u062A\u0643\u0627\u0644\u064A\u0641 \u0627\u0644\u062A\u0646\u0641\u064A\u0630 \u063A\u064A\u0631 \u062F\u0627\u062E\u0644\u0629 \u0641\u064A \u0646\u0637\u0627\u0642 \u062D\u0631\u0643\u0629 \u0627\u0644\u0633\u0639\u0631."];
    if (reasons.length) return { modelCondition, window, riskLevel: a.riskLabel, contributions, period: h.name, sessions: h.sessions, available: false, direction: "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D", price, range: null, change: null, confidence: "\u0645\u0646\u062E\u0641\u0636", coverage, reasons, risks, invalidation, basis, sample: returns.length, independent: Math.max(0, Math.floor((report.prices.length - 1) / h.sessions)), dataQuality: readiness.quality };
    const bias = coverage ? available.reduce((s, f) => s + f.signal * weights[f.key], 0) / 100 : 0;
    const empiricalSigma = deviation(returns) ?? 0;
    const daily = report.prices.slice(1).map((p, i) => Math.log(p.close / report.prices[i].close));
    const recentSigma = deviation(daily.slice(-63)) ?? 0, longSigma = deviation(daily.slice(-252)) ?? recentSigma;
    const daySigma = h.sessions <= 21 ? recentSigma : (recentSigma + longSigma) / 2;
    const sigma = daySigma * Math.sqrt(h.sessions), expectedScale = Math.max(sigma, empiricalSigma);
    const rawCenter = Math.max(-expectedScale * 0.5, Math.min(expectedScale * 0.5, h.sessions === 1 ? bias * daySigma * 0.25 : bias * 0.15 * h.sessions / 252));
    const center = rawCenter > 0 ? rawCenter * condition.positiveTiltMultiplier : rawCenter;
    const widthLow = Math.max(history.median - history.low, 1.28155 * sigma), widthHigh = Math.max(history.high - history.median, 1.28155 * sigma);
    const penalty = 1 + Math.min(0.2, (100 - coverage) / 500) + (readiness.quality === "\u0636\u0639\u064A\u0641\u0629" ? 0.1 : 0);
    let low = price * Math.exp(center - widthLow * penalty), high = price * Math.exp(center + widthHigh * penalty);
    const predictedPrice = price * Math.exp(center), expectedChange = predictedPrice - price, expectedChangePct = 100 * expectedChange / price, neutralThresholdPct = h.sessions === 1 ? 0.1 : h.sessions <= 5 ? 0.25 : 0.5;
    const rangeCalibration = CONFORMAL_RANGE_CALIBRATION_ENABLED ? calibrateForecastRange({ prices: report.prices, sessions: h.sessions, center: predictedPrice, range: [low, high] }) : { status: "insufficient", range: [low, high], sample: 0, targetCoverage: 0.9, empiricalCoverage: null, quantileLogError: null, reason: "\u0645\u0639\u0627\u064A\u0631\u0629 Conformal \u0627\u0644\u062A\u062C\u0631\u064A\u0628\u064A\u0629 \u0645\u0639\u0637\u0644\u0629 \u062D\u062A\u0649 \u0645\u0631\u0627\u062C\u0639\u0629 \u062A\u063A\u0637\u064A\u062A\u0647\u0627 \u062E\u0627\u0631\u062C \u0627\u0644\u0639\u064A\u0646\u0629." };
    if (rangeCalibration.status === "calibrated" && rangeCalibration.range) {
      low = rangeCalibration.range[0];
      high = rangeCalibration.range[1];
    }
    const direction = directionOf(expectedChangePct, neutralThresholdPct);
    const independent = Math.max(0, Math.floor((report.prices.length - 1) / h.sessions));
    const confidence = condition.shock ? "\u0645\u0646\u062E\u0641\u0636" : h.sessions === 1 ? !quoteUsable || now - Date.parse(quote.quoteTime) > 6e4 || !report.context?.market ? "\u0645\u0646\u062E\u0641\u0636" : readiness.confidence : h.sessions >= 126 && readiness.financial < 3 ? "\u0645\u0646\u062E\u0641\u0636" : readiness.confidence;
    const longJump = daily.slice(-20).some((v) => Math.abs(v) > 0.25 && Math.abs(v) > Math.max(0.01, longSigma) * 6);
    const anomalous = !Number.isFinite(high) || !Number.isFinite(low) || low <= 0 || sigma <= 0 || Math.max(Math.abs(Math.log(high / price)), Math.abs(Math.log(low / price))) > settings.maxSigma * expectedScale || longJump;
    const confidenceBlocked = settings.minConfidence === "high" || settings.minConfidence === "medium" && confidence === "\u0645\u0646\u062E\u0641\u0636";
    if (anomalous || confidenceBlocked) return { modelCondition, window, riskLevel: a.riskLabel, contributions, period: h.name, sessions: h.sessions, available: false, direction: "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D", price, range: null, change: null, confidence, coverage, reasons: [anomalous ? "\u062F\u0631\u062C\u0629 \u0627\u0644\u062B\u0642\u0629 \u063A\u064A\u0631 \u0643\u0627\u0641\u064A\u0629 \u0644\u0625\u0635\u062F\u0627\u0631 \u0646\u0637\u0627\u0642 \u0633\u0639\u0631\u064A \u062F\u0642\u064A\u0642. \u0627\u0644\u0646\u0637\u0627\u0642 \u0623\u0648 \u062D\u0631\u0643\u0629 \u062D\u062F\u064A\u062B\u0629 \u062A\u062C\u0627\u0648\u0632\u062A \u0641\u062D\u0635 \u0627\u0644\u062A\u0630\u0628\u0630\u0628 \u0627\u0644\u062A\u0627\u0631\u064A\u062E\u064A\u061B \u064A\u0644\u0632\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0623\u062D\u062F\u0627\u062B \u0648\u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0631\u0623\u0633 \u0627\u0644\u0645\u0627\u0644." : "\u0627\u0644\u062B\u0642\u0629 \u0627\u0644\u0645\u062A\u0627\u062D\u0629 \u0623\u0642\u0644 \u0645\u0646 \u0627\u0644\u062D\u062F \u0627\u0644\u0630\u064A \u062D\u062F\u062F\u062A\u0647 \u0641\u064A \u0627\u0644\u0625\u062F\u0627\u0631\u0629."], risks, invalidation, basis, sample: history.sample, independent, dataQuality: readiness.quality, rangeCalibration };
    const logWidth = Math.log(high / low), q25 = low * Math.exp(logWidth * 0.25), q75 = low * Math.exp(logWidth * 0.75);
    return { modelCondition, predictedPrice, expectedChange, expectedChangePct, neutralThresholdPct, rangeMeaning: "end_close_estimate", evaluationPolicy: EVALUATION_POLICY, window, riskLevel: a.riskLabel, rangeCheck: { dailyVolatility: daySigma * 100, horizonVolatility: expectedScale * 100, maxSigma: settings.maxSigma, market: report.context?.market?.symbol || null, sector: report.context?.sector?.symbol || null }, contributions, scenarios: { negative: [low, q25], base: [q25, q75], positive: [q75, high] }, catalysts: [h.sessions === 1 ? "\u0627\u0633\u062A\u0645\u0631\u0627\u0631 \u0627\u0644\u0632\u062E\u0645 \u0648\u0627\u0644\u0633\u064A\u0648\u0644\u0629 \u0648\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0633\u0648\u0642 \u0641\u064A \u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629." : "\u0627\u0633\u062A\u0645\u0631\u0627\u0631 \u0627\u0644\u0646\u0645\u0648 \u0648\u0627\u0644\u062A\u062F\u0641\u0642 \u0648\u0627\u0644\u0647\u0648\u0627\u0645\u0634 \u0648\u0641\u0642 \u0627\u0644\u0641\u0631\u0636\u064A\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u0629.", "\u062A\u062D\u0642\u0642 \u0627\u062E\u062A\u0631\u0627\u0642 \u064A\u0624\u0643\u062F\u0647 \u0627\u0644\u062D\u062C\u0645\u060C \u0623\u0648 \u0625\u0639\u0644\u0627\u0646 \u062C\u0648\u0647\u0631\u064A \u062C\u062F\u064A\u062F \u0628\u0639\u062F \u0645\u0631\u0627\u062C\u0639\u062A\u0647."], period: h.name, sessions: h.sessions, available: true, direction, price, range: [low, high], change: [(low / price - 1) * 100, (high / price - 1) * 100], confidence, coverage, reasons: readiness.warnings, risks, invalidation, basis, sample: history.sample, independent: Math.max(0, Math.floor((report.prices.length - 1) / h.sessions)), dataQuality: readiness.quality, derivedRange: history.derived, rangeCalibration };
  });
  return { createdAt: new Date(now).toISOString(), version: forecastModelVersion(settings), settingsUsed: { weights: settings.weights, maxSigma: settings.maxSigma, minConfidence: settings.minConfidence, periods: settings.periods }, price, currency: report.currency, priceTime: quoteUsable ? quote.quoteTime : last2?.date || "", retrievedAt: report.retrievedAt, rows, factors, dataQuality: readiness.quality, dataWarnings: [...readiness.warnings, ...quoteUsable && now - Date.parse(quote.quoteTime) > 6e4 ? ["\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0645\u0631\u062C\u0639\u064A \u0645\u062A\u0623\u062E\u0631 \u062D\u062A\u0649 15 \u062F\u0642\u064A\u0642\u0629\u061B \u0644\u0627 \u064A\u0635\u0644\u062D \u0643\u0633\u0639\u0631 \u062A\u0646\u0641\u064A\u0630 \u0644\u062D\u0638\u064A."] : []], dailyScope: "\u0627\u0644\u064A\u0648\u0645\u064A: \u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629\u060C \u0648\u0644\u064A\u0633 \u062A\u0648\u0635\u064A\u0629 \u062A\u0646\u0641\u064A\u0630 \u062F\u0627\u062E\u0644 \u0627\u0644\u062F\u0642\u064A\u0642\u0629. \u0627\u0644\u0633\u0639\u0631 \u0642\u062F \u064A\u062A\u0623\u062E\u0631 \u062D\u062A\u0649 15 \u062F\u0642\u064A\u0642\u0629.", method: "\u0646\u0645\u0648\u0630\u062C \u0633\u064A\u0646\u0627\u0631\u064A\u0648 \u0645\u062A\u0639\u062F\u062F \u0627\u0644\u0639\u0648\u0627\u0645\u0644\u061B \u0627\u0644\u064A\u0648\u0645\u064A \u0644\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629 \u0628\u0645\u064A\u0644 \u0645\u062D\u062F\u0648\u062F \u0628\u0631\u0628\u0639 \u0627\u0644\u062A\u0630\u0628\u0630\u0628 \u0627\u0644\u064A\u0648\u0645\u064A \u0645\u0631\u062C\u062D\u064B\u0627 \u0628\u0627\u0644\u0641\u0646\u064A \u0648\u0627\u0644\u0633\u064A\u0648\u0644\u0629 \u0648\u0627\u0644\u0633\u0648\u0642\u060C \u0648\u0644\u0644\u0645\u062F\u062F \u0627\u0644\u0623\u0637\u0648\u0644 \u0645\u064A\u0644 \u0633\u0646\u0648\u064A \u0645\u062D\u062F\u0648\u062F \xB115% \u062A\u064F\u062D\u062F\u062F\u0647 \u0627\u0644\u0623\u0648\u0632\u0627\u0646 \u0627\u0644\u0645\u0639\u0644\u0646\u0629\u060C \u0648\u0627\u062A\u0633\u0627\u0639 \u0645\u0646 \u0627\u0644\u0645\u0626\u064A\u0646\u064A\u0646 10 \u064890 \u0644\u0639\u0648\u0627\u0626\u062F \u062A\u0627\u0631\u064A\u062E\u064A\u0629 \u0645\u0645\u0627\u062B\u0644\u0629 \u0644\u0644\u0623\u0641\u0642 \u0648\u0627\u0644\u062A\u0630\u0628\u0630\u0628 \u0627\u0644\u064A\u0648\u0645\u064A \u0627\u0644\u062D\u062F\u064A\u062B \u0645\u0636\u0631\u0648\u0628\u064B\u0627 \u0628\u062C\u0630\u0631 \u0639\u062F\u062F \u062C\u0644\u0633\u0627\u062A \u0627\u0644\u0645\u062F\u0629\u061B \u0623\u0636\u064A\u0641\u062A \u0637\u0628\u0642\u0629 \u0645\u0639\u0627\u064A\u0631\u0629 \u0646\u0637\u0627\u0642 Conformal \u062A\u062C\u0631\u064A\u0628\u064A\u0629 \u0644\u0643\u0646\u0647\u0627 \u0645\u0639\u0637\u0644\u0629 \u062D\u062A\u0649 \u062A\u062B\u0628\u062A \u062A\u063A\u0637\u064A\u062A\u0647\u0627 \u062E\u0627\u0631\u062C \u0627\u0644\u0639\u064A\u0646\u0629. \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0645\u0631\u0643\u0632\u064A \u0646\u0627\u062A\u062C \u0645\u064A\u0644 \u0627\u0644\u0646\u0645\u0648\u0630\u062C\u060C \u0648\u0644\u064A\u0633 \u0645\u0646\u062A\u0635\u0641 \u0627\u0644\u0646\u0637\u0627\u0642. \u0645\u0642\u0627\u0645 \u0645\u0633\u0627\u0647\u0645\u0627\u062A \u0627\u0644\u0623\u0648\u0632\u0627\u0646 100 \u062F\u0627\u0626\u0645\u064B\u0627\u061B \u0644\u0627 \u064A\u0639\u0627\u062F \u062A\u0648\u0632\u064A\u0639 \u0648\u0632\u0646 \u0627\u0644\u0639\u0627\u0645\u0644 \u0627\u0644\u0646\u0627\u0642\u0635. \u0627\u0644\u0645\u0626\u064A\u0646\u0627\u062A \u0648\u0635\u0641 \u0644\u0644\u0645\u0627\u0636\u064A \u0648\u0644\u064A\u0633\u062A \u0627\u062D\u062A\u0645\u0627\u0644 \u062A\u062D\u0642\u0642 \u0645\u0633\u062A\u0642\u0628\u0644\u064A. \u0639\u0646\u062F \u0646\u0642\u0635 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u064A\u0646\u062E\u0641\u0636 \u0645\u0633\u062A\u0648\u0649 \u0627\u0644\u062B\u0642\u0629 \u0648\u0644\u0627 \u064A\u062E\u062A\u0641\u064A \u0627\u0644\u062A\u0648\u0642\u0639 \u0645\u0627 \u062F\u0627\u0645\u062A \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0635\u0627\u0644\u062D\u0629. \u0644\u0627 \u062A\u062B\u0628\u062A \u062F\u0642\u0629 \u0627\u0644\u0646\u0645\u0648\u0630\u062C \u0628\u0627\u062E\u062A\u0628\u0627\u0631 \u0645\u0633\u062A\u0642\u0628\u0644\u064A\u061B \u0644\u0630\u0644\u0643 \u0644\u0627 \u062A\u0645\u0646\u062D \u062B\u0642\u0629 \u0645\u0631\u062A\u0641\u0639\u0629." };
}
function forecastModelVersion(settings) {
  const s = JSON.stringify([settings.weights, settings.maxSigma, settings.minConfidence, settings.periods]);
  let hash = 2166136261;
  for (let i = 0; i < s.length; i++) hash = Math.imul(hash ^ s.charCodeAt(i), 16777619);
  return MODEL_VERSION + "-" + (hash >>> 0).toString(16);
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/extended-analysis.ts
var divide2 = (x, y) => finite(x) && finite(y) && y > 0 ? x / y : null;
function extendedAnalysis(report) {
  const a = automaticAnalysis(report), date2 = a.annualDate;
  report = { ...report, facts: resolveFinancialSources(report).facts };
  const get = (key, d = date2) => {
    const f = latestFact(report.facts, key, "annual", d);
    return f?.currency === a.currency ? f.value : null;
  };
  const previous = [...new Set(report.facts.filter((f) => f.key === "revenue" && f.period === "annual" && f.date < date2).map((f) => f.date))].sort().at(-1) || "";
  const netDebt = finite(a.annual.debt) && finite(a.annual.cash) ? a.annual.debt - a.annual.cash : null, fcf = finite(a.annual.operatingCashFlow) && finite(a.annual.capex) ? a.annual.operatingCashFlow - Math.abs(a.annual.capex) : null;
  const tax = divide2(get("taxExpense"), get("pretaxIncome")), capital = finite(a.annual.equity) && finite(netDebt) ? a.annual.equity + netDebt : null, prevCapital = finite(get("equity", previous)) && finite(get("debt", previous)) && finite(get("cash", previous)) ? get("equity", previous) + get("debt", previous) - get("cash", previous) : null;
  const roic = tax !== null && tax >= 0 && tax <= 1 && capital !== null && prevCapital !== null && finite(a.annual.operatingIncome) ? divide2(a.annual.operatingIncome * (1 - tax), (capital + prevCapital) / 2) : null;
  const growth = (key) => {
    const now = get(key), prev2 = get(key, previous);
    return finite(now) && finite(prev2) && prev2 > 0 ? (now / prev2 - 1) * 100 : null;
  };
  const arGrowth = growth("receivables"), inventoryGrowth = growth("inventory"), revenueGrowth = growth("revenue"), netGrowth = growth("netIncome"), cfoGrowth = growth("operatingCashFlow");
  const normalized = get("normalizedIncome"), nonRecurring = finite(normalized) && finite(a.annual.netIncome) && a.annual.netIncome !== 0 ? Math.abs(a.annual.netIncome - normalized) / Math.abs(a.annual.netIncome) * 100 : null;
  const components = [{ name: "\u062A\u062D\u0648\u0644 \u0627\u0644\u0623\u0631\u0628\u0627\u062D \u0625\u0644\u0649 \u0646\u0642\u062F", value: a.cashConversion, healthy: finite(a.cashConversion) && a.cashConversion >= 1 }, { name: "\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062D\u0631", value: fcf, healthy: fcf !== null && fcf > 0 }, { name: "\u0646\u0645\u0648 \u0627\u0644\u0630\u0645\u0645 \u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u0627\u0644\u0625\u064A\u0631\u0627\u062F", value: arGrowth !== null && revenueGrowth !== null ? arGrowth - revenueGrowth : null, healthy: arGrowth !== null && revenueGrowth !== null && arGrowth <= revenueGrowth + 5 }, { name: "\u0646\u0645\u0648 \u0627\u0644\u0645\u062E\u0632\u0648\u0646 \u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u0627\u0644\u0625\u064A\u0631\u0627\u062F", value: inventoryGrowth !== null && revenueGrowth !== null ? inventoryGrowth - revenueGrowth : null, healthy: inventoryGrowth !== null && revenueGrowth !== null && inventoryGrowth <= revenueGrowth + 5 }, { name: "\u0627\u0633\u062A\u0645\u0631\u0627\u0631 \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A", value: cfoGrowth, healthy: cfoGrowth !== null && cfoGrowth >= 0 }, { name: "\u0627\u062E\u062A\u0644\u0627\u0641 \u0627\u0644\u0631\u0628\u062D \u0627\u0644\u0645\u0639\u0644\u0646 \u0639\u0646 \u0627\u0644\u0645\u0637\u0628\u0639", value: nonRecurring, healthy: nonRecurring !== null && nonRecurring < 10 }];
  const known = components.filter((c) => c.value !== null), qualityScore = known.length ? known.filter((c) => c.healthy).length / known.length * 100 : null;
  const earningsQuality = known.length < 4 ? "\u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644\u0629" : qualityScore >= 90 ? "\u0645\u0645\u062A\u0627\u0632\u0629" : qualityScore >= 75 ? "\u062C\u064A\u062F\u0629" : qualityScore >= 55 ? "\u0645\u0642\u0628\u0648\u0644\u0629" : qualityScore >= 30 ? "\u0636\u0639\u064A\u0641\u0629" : "\u0645\u0642\u0644\u0642\u0629";
  const anomalies = [];
  if (finite(netGrowth) && netGrowth > 0 && (!finite(cfoGrowth) || cfoGrowth < 0)) anomalies.push("\u0627\u0644\u0623\u0631\u0628\u0627\u062D \u062A\u0646\u0645\u0648 \u0644\u0643\u0646 \u0646\u0645\u0648 \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A \u0633\u0627\u0644\u0628 \u0623\u0648 \u063A\u064A\u0631 \u0645\u062A\u062D\u0642\u0642.");
  const prevMargin = divide2(get("operatingIncome", previous), get("revenue", previous));
  if (revenueGrowth !== null && revenueGrowth > 0 && prevMargin !== null && a.operatingMargin !== null && a.operatingMargin < prevMargin * 100) anomalies.push("\u0646\u0645\u0648 \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A \u064A\u062A\u0631\u0627\u0641\u0642 \u0645\u0639 \u062A\u0631\u0627\u062C\u0639 \u0627\u0644\u0647\u0627\u0645\u0634 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A.");
  if (nonRecurring !== null && nonRecurring > 15) anomalies.push("\u0641\u0631\u0642 \u0645\u0624\u062B\u0631 \u0628\u064A\u0646 \u0635\u0627\u0641\u064A \u0627\u0644\u0631\u0628\u062D \u0648\u0627\u0644\u0631\u0628\u062D \u0627\u0644\u0645\u0637\u0628\u0639\u061B \u064A\u0644\u0632\u0645 \u0627\u0644\u0631\u062C\u0648\u0639 \u0625\u0644\u0649 \u0627\u0644\u0625\u064A\u0636\u0627\u062D\u0627\u062A \u0644\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0628\u0646\u0648\u062F \u0627\u0644\u0627\u0633\u062A\u062B\u0646\u0627\u0626\u064A\u0629.");
  if (a.dupont.leverage !== null && a.dupont.leverage > 3) anomalies.push("\u0645\u0636\u0627\u0639\u0641 \u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0644\u0643\u064A\u0629 \u0645\u0631\u062A\u0641\u0639\u061B \u0642\u062F \u064A\u0643\u0648\u0646 ROE \u0645\u062F\u0641\u0648\u0639\u064B\u0627 \u0628\u0627\u0644\u0631\u0627\u0641\u0639\u0629 \u0627\u0644\u0645\u0627\u0644\u064A\u0629.");
  if (a.priceChange !== null && a.priceChange > 2 && finite(a.tech.relativeVolume) && a.tech.relativeVolume < 1) anomalies.push("\u0635\u0639\u0648\u062F \u0627\u0644\u0633\u0639\u0631 \u0644\u0645 \u064A\u0635\u0627\u062D\u0628\u0647 \u062D\u062C\u0645 \u0623\u0639\u0644\u0649 \u0645\u0646 \u0645\u062A\u0648\u0633\u0637 \u0627\u0644\u062A\u062F\u0627\u0648\u0644.");
  if (finite(a.tech.relativeVolume) && a.tech.relativeVolume >= 3) anomalies.push("\u062D\u062C\u0645 \u062A\u062F\u0627\u0648\u0644 \u0627\u0633\u062A\u062B\u0646\u0627\u0626\u064A \u064A\u062A\u062C\u0627\u0648\u0632 3 \u0623\u0645\u062B\u0627\u0644 \u0627\u0644\u0645\u062A\u0648\u0633\u0637.");
  const last2 = report.prices.at(-1), prev = report.prices.at(-2);
  if (last2 && prev && Math.abs(last2.open / prev.close - 1) > 0.05) anomalies.push("\u0641\u062C\u0648\u0629 \u0627\u0641\u062A\u062A\u0627\u062D \u062A\u062A\u062C\u0627\u0648\u0632 5%\u061B \u0627\u0641\u062D\u0635 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0648\u062A\u063A\u064A\u064A\u0631\u0627\u062A \u0631\u0623\u0633 \u0627\u0644\u0645\u0627\u0644 \u0642\u0628\u0644 \u062A\u0641\u0633\u064A\u0631\u0647\u0627.");
  if (a.fair && a.price && a.price > a.fair[1]) anomalies.push("\u0627\u0644\u0633\u0639\u0631 \u0623\u0639\u0644\u0649 \u0646\u0637\u0627\u0642 \u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0646\u0633\u0628\u064A \u0627\u0644\u0645\u062A\u0627\u062D\u061B \u0639\u064A\u0646\u0629 \u0627\u0644\u0646\u0638\u0631\u0627\u0621 \u0645\u062D\u062F\u0648\u062F\u0629.");
  const availableChecks = [report.prices.length >= 252, !!last2 && ageDays(report.asOf, last2.date) <= 3, !!date2 && ageDays(report.asOf, date2) <= 550, !!a.latestQuarterDate && ageDays(report.asOf, a.latestQuarterDate) <= 210, finite(a.annual.revenue), finite(a.annual.netIncome), finite(a.annual.operatingCashFlow), finite(netDebt), a.peerCount >= 2, report.news.length > 0, !!report.context?.market, !!report.context?.sector, report.checks.some((x) => x.name === "\u0625\u0641\u0635\u0627\u062D\u0627\u062A SEC" && x.state === "ok") || !!report.official?.facts.length, report.facts.every((f) => !!f.publishedAt) && report.facts.length > 0];
  const coverage = availableChecks.filter(Boolean).length / availableChecks.length * 100, conflict = a.sourceComparisons.some((x) => x.conflict), fresh = !!last2 && ageDays(report.asOf, last2.date) <= 3;
  const dataQuality = !fresh || conflict || coverage < 45 ? "\u0636\u0639\u064A\u0641\u0629" : coverage < 70 ? "\u0645\u062A\u0648\u0633\u0637\u0629" : coverage < 95 ? "\u062C\u064A\u062F\u0629" : "\u0645\u0645\u062A\u0627\u0632\u0629";
  const metrics = [["\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u0646\u0642\u062F\u064A \u0627\u0644\u062D\u0631", fcf], ["\u0635\u0627\u0641\u064A \u0627\u0644\u062F\u064A\u0646", netDebt], ["\u0631\u0623\u0633 \u0627\u0644\u0645\u0627\u0644 \u0627\u0644\u0639\u0627\u0645\u0644", finite(a.annual.currentAssets) && finite(a.annual.currentLiabilities) ? a.annual.currentAssets - a.annual.currentLiabilities : null], ["EPS \u2014 \u0622\u062E\u0631 12 \u0634\u0647\u0631\u064B\u0627", divide2(a.ttmIncome, a.shares)], ["ROIC %", roic === null ? null : roic * 100], ["P/S", a.currency === report.currency ? divide2(a.cap, a.annual.revenue) : null], ["Forward P/E", null], ["PEG", netGrowth && netGrowth > 0 ? divide2(a.pe, netGrowth) : null], ["\u0627\u0644\u0639\u0627\u0626\u062F \u0627\u0644\u0646\u0642\u062F\u064A %", a.currency === report.currency ? (divide2(a.annual.dividends, a.cap) ?? NaN) * 100 : null], ["\u0627\u0644\u0630\u0645\u0645 \u0627\u0644\u0645\u062F\u064A\u0646\u0629", get("receivables")], ["\u0627\u0644\u0645\u062E\u0632\u0648\u0646", get("inventory")], ["\u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0627\u0644\u0631\u0623\u0633\u0645\u0627\u0644\u064A", a.annual.capex]];
  const qdate = a.latestQuarterDate;
  const comparisonDate = qdate ? String(Number(qdate.slice(0, 4)) - 1) + qdate.slice(4) : "";
  const quarter = ["revenue", "netIncome", "operatingCashFlow"].map((key) => {
    const current = latestFact(report.facts, key, "quarterly", qdate), previous2 = latestFact(report.facts, key, "quarterly", comparisonDate);
    const comparable = current && previous2 && current.currency === previous2.currency;
    return { key, current: current?.value ?? null, previous: comparable ? previous2.value : null, growth: comparable && previous2.value > 0 ? (current.value / previous2.value - 1) * 100 : null, date: qdate, previousDate: comparisonDate, source: current?.source || report.priceSource };
  });
  const gaps = ["\u0622\u062C\u0627\u0644 \u0627\u0644\u062F\u064A\u0646 \u0648\u062A\u0643\u0644\u0641\u062A\u0647 \u0627\u0644\u062A\u0641\u0635\u064A\u0644\u064A\u0629", "\u0631\u0623\u064A \u0627\u0644\u0645\u0631\u0627\u062C\u0639 \u0648\u0645\u062E\u0627\u0637\u0631 \u0627\u0644\u0627\u0633\u062A\u0645\u0631\u0627\u0631\u064A\u0629", "\u0627\u0644\u062D\u0648\u0643\u0645\u0629 \u0648\u0627\u0644\u0646\u0638\u0627\u0645 \u0627\u0644\u0623\u0633\u0627\u0633\u064A \u0648\u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646", "\u0627\u0644\u0642\u0636\u0627\u064A\u0627 \u0648\u0627\u0644\u0645\u062E\u0627\u0637\u0631 \u0627\u0644\u062A\u0646\u0638\u064A\u0645\u064A\u0629", "\u0643\u0628\u0627\u0631 \u0627\u0644\u0645\u0644\u0627\u0643 \u0648\u062A\u0639\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u0645\u0637\u0644\u0639\u064A\u0646 \u0648\u0627\u0644\u0645\u0644\u0643\u064A\u0629 \u0627\u0644\u0645\u0624\u0633\u0633\u064A\u0629", "\u0645\u0639\u0644\u0645\u0627\u062A DCF \u0648\u0645\u0639\u062F\u0644 \u0627\u0644\u062E\u0635\u0645 \u0648\u0627\u0644\u0646\u0645\u0648 \u0627\u0644\u0646\u0647\u0627\u0626\u064A \u0627\u0644\u0645\u0648\u062B\u0642\u0629", "\u062A\u0642\u0648\u064A\u0645 \u062C\u0648\u0647\u0631\u064A \u0643\u0627\u0645\u0644 \u0648\u062A\u0642\u062F\u064A\u0631 \u0627\u0633\u062A\u064A\u0639\u0627\u0628 \u0627\u0644\u0623\u062E\u0628\u0627\u0631 \u0641\u064A \u0627\u0644\u0633\u0639\u0631", "\u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0634\u0631\u0639\u064A \u0648\u0627\u0644\u062A\u0637\u0647\u064A\u0631 \u0648\u0641\u0642 \u0645\u0631\u062C\u0639 \u062D\u062F\u064A\u062B \u0645\u0639\u062A\u0645\u062F"];
  const methods = [];
  const addMethod = (name, values, basePerShare) => {
    if (values.length < 2 || !basePerShare || basePerShare <= 0) return;
    const v = values.sort((x, y) => x - y);
    methods.push({ name, low: v[0] * basePerShare, base: v.reduce((s, n) => s + n, 0) / v.length * basePerShare, high: v.at(-1) * basePerShare });
  };
  if (a.currency === report.currency) {
    addMethod("P/E", report.peers.map((p) => p.pe).filter(finite).filter((v) => v > 0), divide2(a.ttmIncome, a.shares));
    addMethod("P/B", report.peers.map((p) => p.pb).filter(finite).filter((v) => v > 0), divide2(a.annual.equity, a.shares));
    if (!a.specialized) addMethod("P/S", report.peers.map((p) => p.ps).filter(finite).filter((v) => v > 0), divide2(a.annual.revenue, a.shares));
  }
  const fair = !a.blockers.length && !conflict && fresh && methods.length >= 2 ? { low: methods.reduce((s, m) => s + m.low, 0) / methods.length, base: methods.reduce((s, m) => s + m.base, 0) / methods.length, high: methods.reduce((s, m) => s + m.high, 0) / methods.length } : null;
  const metricKeys = { "\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u0646\u0642\u062F\u064A \u0627\u0644\u062D\u0631": ["operatingCashFlow", "capex"], "\u0635\u0627\u0641\u064A \u0627\u0644\u062F\u064A\u0646": ["debt", "cash"], "\u0631\u0623\u0633 \u0627\u0644\u0645\u0627\u0644 \u0627\u0644\u0639\u0627\u0645\u0644": ["currentAssets", "currentLiabilities"], "EPS \u2014 \u0622\u062E\u0631 12 \u0634\u0647\u0631\u064B\u0627": ["netIncome", "shares"], "ROIC %": ["operatingIncome", "taxExpense", "pretaxIncome", "equity", "debt", "cash"], "P/S": ["revenue", "shares"], "Forward P/E": [], "PEG": ["netIncome", "shares"], "\u0627\u0644\u0639\u0627\u0626\u062F \u0627\u0644\u0646\u0642\u062F\u064A %": ["dividends", "shares"], "\u0627\u0644\u0630\u0645\u0645 \u0627\u0644\u0645\u062F\u064A\u0646\u0629": ["receivables"], "\u0627\u0644\u0645\u062E\u0632\u0648\u0646": ["inventory"], "\u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0627\u0644\u0631\u0623\u0633\u0645\u0627\u0644\u064A": ["capex"] };
  const metricRows = metrics.map(([name, value]) => {
    const keys = metricKeys[name] || [], usesPrice = ["P/S", "PEG", "\u0627\u0644\u0639\u0627\u0626\u062F \u0627\u0644\u0646\u0642\u062F\u064A %"].includes(name);
    const inputs = report.facts.filter((f) => keys.includes(f.key) && f.currency === a.currency && (f.date === date2 || f.date === previous || f.date === a.ttmDate));
    const sources = [...new Set(inputs.map((f) => f.source).concat(usesPrice ? [report.priceSource] : []))].filter(Boolean);
    return { name, value: finite(value) ? value : null, date: name === "EPS \u2014 \u0622\u062E\u0631 12 \u0634\u0647\u0631\u064B\u0627" ? a.ttmDate : date2, source: sources[0] || "", sources, inputs: inputs.map((f) => ({ key: f.key, period: f.period, date: f.date, publishedAt: f.publishedAt || null, source: f.source })), retrievedAt: report.retrievedAt };
  });
  const keyInsights = [], riskWarnings = [...anomalies];
  const strongCash = finite(a.annual.netIncome) && a.annual.netIncome > 0 && finite(a.annual.operatingCashFlow) && a.annual.operatingCashFlow > 0 && finite(a.cashConversion) && a.cashConversion >= 0.8;
  if (strongCash) keyInsights.push(`\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A \u064A\u063A\u0637\u064A ${fmt(a.cashConversion * 100)}% \u0645\u0646 \u0635\u0627\u0641\u064A \u0627\u0644\u0631\u0628\u062D \u0627\u0644\u0645\u0648\u062C\u0628 \u0644\u0641\u062A\u0631\u0629 ${date2}.`);
  else if (finite(a.annual.operatingCashFlow) && a.annual.operatingCashFlow <= 0) riskWarnings.push("\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A \u063A\u064A\u0631 \u0645\u0648\u062C\u0628\u061B \u0644\u0627 \u064A\u064F\u0639\u062F \u062A\u062D\u0648\u064A\u0644\u064B\u0627 \u0646\u0642\u062F\u064A\u064B\u0627 \u0642\u0648\u064A\u064B\u0627 \u062D\u062A\u0649 \u0625\u0646 \u0643\u0627\u0646 \u0635\u0627\u0641\u064A \u0627\u0644\u0631\u0628\u062D \u0633\u0627\u0644\u0628\u064B\u0627 \u0623\u064A\u0636\u064B\u0627.");
  else if (finite(a.cashConversion) && a.cashConversion < 0.5) riskWarnings.push("\u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u0631\u0628\u062D \u0627\u0644\u0645\u0648\u062C\u0628 \u0625\u0644\u0649 \u062A\u062F\u0641\u0642 \u062A\u0634\u063A\u064A\u0644\u064A \u0623\u0642\u0644 \u0645\u0646 50%.");
  if (netDebt === null) riskWarnings.push("\u0627\u0644\u062F\u064A\u0646 \u0623\u0648 \u0627\u0644\u0646\u0642\u062F \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u061B \u0635\u0627\u0641\u064A \u0627\u0644\u062F\u064A\u0646 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0628 \u0648\u0644\u0627 \u064A\u064F\u0641\u062A\u0631\u0636 \u0635\u0641\u0631\u064B\u0627.");
  else if (netDebt <= 0) keyInsights.push("\u0627\u0644\u0646\u0642\u062F \u064A\u063A\u0637\u064A \u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u062F\u064A\u0646 \u0627\u0644\u0645\u062A\u0627\u062D \u0644\u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629\u061B \u0644\u0627 \u064A\u062B\u0628\u062A \u0630\u0644\u0643 \u0648\u062D\u062F\u0647 \u0627\u0644\u0623\u0645\u0627\u0646 \u0627\u0644\u0645\u0627\u0644\u064A \u0623\u0648 \u0627\u0644\u0633\u064A\u0648\u0644\u0629 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A\u0629.");
  if (finite(a.annual.equity) && a.annual.equity <= 0) riskWarnings.push("\u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646 \u063A\u064A\u0631 \u0645\u0648\u062C\u0628\u0629.");
  else if (netDebt !== null && finite(a.annual.equity) && a.annual.equity > 0 && netDebt / a.annual.equity > 1.5) riskWarnings.push(`\u0635\u0627\u0641\u064A \u0627\u0644\u062F\u064A\u0646 \u064A\u0645\u062B\u0644 ${fmt(netDebt / a.annual.equity * 100)}% \u0645\u0646 \u062D\u0642\u0648\u0642 \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u064A\u0646.`);
  const month = report.forecast?.rows.find((r) => r.sessions === 21);
  if (month?.available) keyInsights.push(`\u0627\u0644\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0634\u0647\u0631\u064A \u0641\u064A \u0627\u0644\u062A\u0648\u0642\u0639 \u0627\u0644\u0645\u0631\u0641\u0642: ${month.direction}\u061B ${month.confidence}. \u0644\u064A\u0633 \u0627\u062D\u062A\u0645\u0627\u0644 \u0646\u062C\u0627\u062D \u0645\u0639\u0627\u064A\u0631\u064B\u0627.`);
  const growthScore = finite(a.cagrRevenue) ? Math.max(0, Math.min(100, 50 + 3 * a.cagrRevenue)) : null;
  const liquidityScore = a.axes.find((v) => v.name === "\u0627\u0644\u0633\u064A\u0648\u0644\u0629")?.value ?? null;
  const valuationVerdict = fair ? "\u0646\u0637\u0627\u0642 \u0646\u0633\u0628\u064A \u0645\u062A\u0627\u062D \u0645\u0646 \u0639\u062F\u0629 \u0645\u0636\u0627\u0639\u0641\u0627\u062A\u061B \u064A\u062D\u062A\u0627\u062C \u062A\u062D\u0642\u0642\u064B\u0627 \u0645\u0646 \u0645\u0644\u0627\u0621\u0645\u0629 \u0627\u0644\u0646\u0638\u0631\u0627\u0621." : "\u0644\u0627 \u062A\u062A\u0648\u0641\u0631 \u0623\u062F\u0644\u0629 \u0643\u0627\u0641\u064A\u0629 \u0644\u062A\u0642\u064A\u064A\u0645 \u0645\u062A\u0639\u062F\u062F \u0627\u0644\u0637\u0631\u0642.";
  return { growthScore, qualityScore, liquidityScore, valuationVerdict, keyInsights, riskWarnings, methods, fair, a, dataQuality, coverage, earningsQuality, components, metrics: metricRows, quarter, anomalies, gaps, nonRecurring, summary: conflict ? "\u064A\u0648\u062C\u062F \u062A\u0639\u0627\u0631\u0636 \u0628\u064A\u0646 \u0627\u0644\u0645\u0635\u0627\u062F\u0631\u061B \u0644\u0627 \u064A\u064F\u0639\u062A\u0645\u062F \u062D\u0643\u0645 \u0646\u0647\u0627\u0626\u064A \u0642\u0628\u0644 \u062D\u0633\u0645\u0647." : dataQuality === "\u0636\u0639\u064A\u0641\u0629" ? "\u0642\u0631\u0627\u0621\u0629 \u0623\u0648\u0644\u064A\u0629 \u0628\u062B\u0642\u0629 \u0645\u0646\u062E\u0641\u0636\u0629 \u0648\u0641\u0642 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u062D\u0629\u061B \u0631\u0627\u062C\u0639 \u0623\u0633\u0628\u0627\u0628 \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631 \u0648\u062D\u062F\u0648\u062F \u0627\u0644\u0645\u0635\u0627\u062F\u0631 \u0641\u064A \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644." : `${a.opinion}. \u062C\u0648\u062F\u0629 \u0627\u0644\u0623\u0631\u0628\u0627\u062D ${earningsQuality}\u061B \u0627\u0644\u062E\u0637\u0631 ${a.riskLabel}. \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A ${Math.round(coverage)}% \u0636\u0645\u0646 \u0627\u0644\u0641\u062D\u0648\u0635 \u0627\u0644\u0645\u062A\u0627\u062D\u0629.`, invalidation: ["\u0646\u0645\u0648 \u0627\u0644\u0631\u0628\u062D \u062F\u0648\u0646 \u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u0646\u0642\u062F\u064A \u0623\u0648 \u062A\u0631\u0627\u062C\u0639 \u0627\u0644\u0647\u0648\u0627\u0645\u0634 \u0641\u064A \u0646\u062A\u0627\u0626\u062C \u062C\u062F\u064A\u062F\u0629.", "\u0627\u0631\u062A\u0641\u0627\u0639 \u0635\u0627\u0641\u064A \u0627\u0644\u062F\u064A\u0646 \u0623\u0648 \u062A\u0631\u0627\u062C\u0639 \u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u062A\u0645\u0648\u064A\u0644 \u0625\u0644\u0649 \u0623\u0642\u0644 \u0645\u0646 3 \u0645\u0631\u0627\u062A.", "\u0625\u0641\u0635\u0627\u062D \u062C\u0648\u0647\u0631\u064A \u0623\u0648 \u0625\u0639\u0627\u062F\u0629 \u0639\u0631\u0636 \u0627\u0644\u0642\u0648\u0627\u0626\u0645 \u064A\u063A\u064A\u0651\u0631 \u0627\u0644\u0641\u0631\u0636\u064A\u0627\u062A.", "\u0643\u0633\u0631 \u0627\u0644\u062F\u0639\u0645 \u0628\u0625\u063A\u0644\u0627\u0642 \u0623\u0648 \u0641\u0634\u0644 \u0627\u0644\u0627\u062E\u062A\u0631\u0627\u0642 \u0645\u0639 \u0636\u0639\u0641 \u0627\u0644\u062D\u062C\u0645 \u0644\u0644\u0645\u0636\u0627\u0631\u0628\u0629.", "\u062A\u063A\u064A\u0631 \u0645\u0639\u0627\u064A\u064A\u0631 \u0627\u0644\u062A\u0648\u0627\u0641\u0642 \u0627\u0644\u0634\u0631\u0639\u064A \u0623\u0648 \u0638\u0647\u0648\u0631 \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u062D\u0648\u0643\u0645\u0629 \u062C\u0648\u0647\u0631\u064A\u0629."] };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/decision-room.ts
var DECISION_VERSION = "decision-evidence-1";
var valid = (v) => typeof v === "number" && Number.isFinite(v);
var clamp3 = (v) => Math.max(0, Math.min(100, v));
function decisionRoom(report) {
  const a = automaticAnalysis(report), x = extendedAnalysis(report);
  const financial = a.axes.find((v) => v.name === "\u0627\u0644\u0642\u0648\u0629 \u0627\u0644\u0645\u0627\u0644\u064A\u0629")?.value ?? null;
  const known = x.components.filter((v) => valid(v.value));
  const earnings = known.length >= 4 ? known.filter((v) => v.healthy).length / known.length * 100 : null;
  const factors = [
    { name: "\u0627\u0644\u0642\u0648\u0629 \u0627\u0644\u0645\u0627\u0644\u064A\u0629", value: financial, weight: 40, reason: "\u0627\u0644\u0645\u062D\u0648\u0631 \u0627\u0644\u0645\u0627\u0644\u064A \u0627\u0644\u0645\u0648\u062C\u0648\u062F: 100 \u0646\u0627\u0642\u0635 \u0645\u062A\u0648\u0633\u0637 \u0645\u062E\u0627\u0637\u0631 \u0639\u0648\u0627\u0645\u0644\u0647. \u0644\u0627 \u0646\u0637\u0628\u0651\u0642 \u0627\u0644\u0646\u0645\u0648\u0630\u062C \u0627\u0644\u0639\u0627\u0645 \u0639\u0644\u0649 \u0627\u0644\u0628\u0646\u0648\u0643 \u0648\u0627\u0644\u0635\u0646\u0627\u062F\u064A\u0642." },
    { name: "\u062C\u0648\u062F\u0629 \u0627\u0644\u0623\u0631\u0628\u0627\u062D", value: earnings, weight: 35, reason: `\u0646\u0633\u0628\u0629 \u0627\u0644\u0641\u062D\u0648\u0635 \u0627\u0644\u0633\u0644\u064A\u0645\u0629 \u0645\u0646 ${known.length} \u0641\u062D\u0648\u0635 \u0645\u062A\u0627\u062D\u0629\u061B \u064A\u0644\u0632\u0645 4 \u0645\u0646 6 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644. \u0644\u064A\u0633\u062A \u0627\u062D\u062A\u0645\u0627\u0644 \u0646\u062C\u0627\u062D \u0627\u0644\u0627\u0633\u062A\u062B\u0645\u0627\u0631.` },
    { name: "\u0646\u0645\u0648 \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A", value: valid(a.cagrRevenue) ? clamp3(50 + 3 * a.cagrRevenue) : null, weight: 25, reason: "50 + \u062B\u0644\u0627\u062B\u0629 \u0623\u0645\u062B\u0627\u0644 \u0646\u0633\u0628\u0629 \u0627\u0644\u0646\u0645\u0648 \u0627\u0644\u0633\u0646\u0648\u064A \u0627\u0644\u0645\u0631\u0643\u0628\u060C \u0645\u062D\u0635\u0648\u0631\u0629 \u0628\u064A\u0646 0 \u0648100. \u0642\u0627\u0639\u062F\u0629 \u0648\u0635\u0641\u064A\u0629 \u0645\u0639\u0644\u0646\u0629 \u0648\u0644\u064A\u0633\u062A \u0646\u0645\u0648\u0630\u062C \u0639\u0627\u0626\u062F \u0645\u064F\u0639\u0627\u064A\u0631." }
  ];
  const companyQuality = factors.every((v) => valid(v.value)) && !a.specialized && !!a.annualDate && ageDays(report.asOf, a.annualDate) <= 550 && !a.sourceComparisons.some((v) => v.conflict) ? Math.round(factors.reduce((s, v) => s + v.value * v.weight / 100, 0)) : null;
  const priceSuitability = x.fair && valid(a.price) && a.price > 0 ? Math.round(clamp3(50 + 100 * (x.fair.base - a.price) / x.fair.base)) : null;
  const s50 = a.tech.sma50.at(-1), s200 = a.tech.sma200.at(-1);
  const trend = valid(a.price) && valid(s50) && valid(s200) ? a.price > s50 && s50 > s200 ? "\u0635\u0627\u0639\u062F" : a.price < s50 && s50 < s200 ? "\u0647\u0627\u0628\u0637" : "\u0645\u062E\u062A\u0644\u0637 / \u0645\u062D\u0627\u064A\u062F" : "\u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644";
  const marketRegime = RegimeEngine.detect(report.prices.map((p) => p.close));
  return { a, x, factors, companyQuality, priceSuitability, trend, marketRegime, version: DECISION_VERSION };
}
function publicBaselineEligible(report) {
  return report.mode === "current" && !report.checks.some((v) => v.name.startsWith("\u0645\u0644\u0641 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645")) && !report.facts.some((v) => !/^https?:\/\//.test(v.source));
}
function decisionBaseline(report, createdAt) {
  const { a, x, companyQuality, priceSuitability } = decisionRoom(report);
  const selectedFacts = resolveFinancialSources(report).facts;
  const source = (key) => selectedFacts.find((v) => v.key === key && v.date === a.annualDate && v.period === "annual")?.source || "";
  const metric = (key, name, value, unit, period, src) => ({ key, name, value: valid(value) ? value : null, unit, period, source: src });
  return { version: DECISION_VERSION, symbol: report.company.symbol, currency: report.currency, createdAt, quoteTime: report.quoteTime, priceDate: report.prices.at(-1)?.date || "", model: report.forecast?.version || "", conclusion: a.opinion, confidence: (report.forecast?.rows || []).map((v) => ({ period: v.period, confidence: v.confidence })), metrics: [
    metric("price", "\u0633\u0639\u0631 \u0627\u0644\u062A\u062D\u0644\u064A\u0644", a.price, report.currency, report.quoteTime || report.asOf, report.priceSource),
    metric("quality", "\u062C\u0648\u062F\u0629 \u0627\u0644\u0634\u0631\u0643\u0629", companyQuality, "/100", a.annualDate, ""),
    metric("suitability", "\u0645\u0644\u0627\u0621\u0645\u0629 \u0627\u0644\u0633\u0639\u0631", priceSuitability, "/100", report.asOf, ""),
    metric("revenueGrowth", "\u0646\u0645\u0648 \u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u0631\u0643\u0628", a.cagrRevenue, "%", a.annualDate, source("revenue")),
    metric("operatingMargin", "\u0627\u0644\u0647\u0627\u0645\u0634 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A", a.operatingMargin, "%", a.annualDate, source("operatingIncome")),
    metric("cashConversion", "\u0627\u0644\u062A\u062F\u0641\u0642 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u064A / \u0627\u0644\u0631\u0628\u062D", a.cashConversion, "\xD7", a.annualDate, source("operatingCashFlow")),
    metric("debt", "\u0635\u0627\u0641\u064A \u0627\u0644\u062F\u064A\u0646 / EBITDA", a.netDebtEbitda, "\xD7", a.annualDate, source("debt")),
    metric("pe", "\u0645\u0643\u0631\u0631 \u0627\u0644\u0631\u0628\u062D\u064A\u0629", a.pe, "\xD7", a.ttmDate, report.priceSource),
    metric("volume", "\u0627\u0644\u062D\u062C\u0645 \u0627\u0644\u0646\u0633\u0628\u064A", a.tech.relativeVolume, "\xD7", report.asOf, report.priceSource),
    metric("support", "\u0627\u0644\u062F\u0639\u0645", a.tech.support, report.currency, report.asOf, report.priceSource),
    metric("dataCoverage", "\u062A\u063A\u0637\u064A\u0629 \u0641\u062D\u0648\u0635 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A", x.coverage, "%", report.asOf, "")
  ] };
}
function compareDecisionBaselines(before, after, actions = []) {
  if (before.version !== after.version || before.symbol !== after.symbol || before.currency !== after.currency || before.createdAt > after.createdAt) return { state: "incomparable", reason: "\u0627\u062E\u062A\u0644\u0641\u062A \u0627\u0644\u0647\u0648\u064A\u0629 \u0623\u0648 \u0627\u0644\u0639\u0645\u0644\u0629 \u0623\u0648 \u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u062D\u0633\u0627\u0628 \u0623\u0648 \u062A\u0631\u062A\u064A\u0628 \u0627\u0644\u0648\u0642\u062A\u061B \u0644\u0645 \u0646\u062D\u0633\u0628 \u0641\u0631\u0648\u0642\u064B\u0627 \u0645\u0636\u0644\u0644\u0629." };
  const split = actions.some((v) => v.kind === "split" && v.date > before.priceDate && v.date <= after.priceDate);
  const rows = after.metrics.flatMap((v) => {
    const old = before.metrics.find((p) => p.key === v.key);
    if (!old || old.unit !== v.unit) return [];
    const comparable = valid(old.value) && valid(v.value) && !(split && ["price", "support"].includes(v.key));
    if (old.value === v.value && old.period === v.period) return [];
    return [{ key: v.key, name: v.name, before: old.value, after: v.value, difference: comparable ? v.value - old.value : null, unit: v.unit, beforePeriod: old.period, afterPeriod: v.period, beforeSource: old.source, afterSource: v.source, note: split && ["price", "support"].includes(v.key) ? "\u062D\u062F\u062B \u062A\u063A\u064A\u064A\u0631 \u0641\u064A \u0639\u062F\u062F \u0627\u0644\u0623\u0633\u0647\u0645\u061B \u064A\u0644\u0632\u0645 \u062A\u0648\u062D\u064A\u062F \u0648\u062D\u062F\u0627\u062A \u0627\u0644\u0633\u0639\u0631 \u0642\u0628\u0644 \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629." : !comparable ? "\u0623\u062D\u062F \u0627\u0644\u0631\u0642\u0645\u064A\u0646 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u061B \u0644\u0627 \u064A\u064F\u0639\u0627\u0645\u0644 \u0643\u0635\u0641\u0631." : old.period !== v.period ? "\u0627\u062E\u062A\u0644\u0641\u062A \u0641\u062A\u0631\u0629 \u0623\u0648 \u0644\u062D\u0638\u0629 \u0627\u0644\u0642\u064A\u0627\u0633\u061B \u0631\u0627\u062C\u0639 \u0627\u0644\u062A\u0627\u0631\u064A\u062E\u064A\u0646." : void 0 }];
  });
  return { state: "available", previousAt: before.createdAt, currentAt: after.createdAt, previousConclusion: before.conclusion, currentConclusion: after.conclusion, confidenceBefore: before.confidence, confidenceAfter: after.confidence, rows };
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/evidence-ledger.ts
async function fingerprint(value) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))), (b) => b.toString(16).padStart(2, "0")).join("");
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/forecast-conformal.ts
var CONFORMAL_POLICY = "mizan-conformal-end-price-v1";
var CONFORMAL_TARGET = 0.9;
var CONFORMAL_MIN_SAMPLE = 30;
var MAX_SAMPLE = 250;
var QUERY_PER_HORIZON = 500;
var positive = (v) => typeof v === "number" && Number.isFinite(v) && v > 0;
var object = (v) => {
  try {
    const x = typeof v === "string" ? JSON.parse(v) : v;
    return x && typeof x === "object" && !Array.isArray(x) ? x : null;
  } catch {
    return null;
  }
};
var date = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v) && Number.isFinite(Date.parse(v + "T00:00:00Z")) && (/* @__PURE__ */ new Date(v + "T00:00:00Z")).toISOString().slice(0, 10) === v;
var instant = (v) => typeof v === "string" && date(v.slice(0, 10)) && /^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?Z$/.test(v) && Number.isFinite(Date.parse(v));
var interval = (v) => Array.isArray(v) && v.length === 2 && positive(v[0]) && positive(v[1]) && v[0] <= v[1];
function conformalQuantile(scores, target = CONFORMAL_TARGET) {
  if (!Number.isFinite(target) || target <= 0 || target >= 1 || scores.some((s) => !Number.isFinite(s) || s < 0)) return null;
  const rank = Math.ceil((scores.length + 1) * target);
  if (!scores.length || rank > scores.length) return null;
  return { rank, value: [...scores].sort((a, b) => a - b)[rank - 1] };
}
function savedPriceScale(forecast) {
  const sigma = forecast?.rangeCheck?.horizonVolatility;
  if (!positive(forecast?.price) || !positive(sigma)) return null;
  const scale = forecast.price * sigma / 100;
  return positive(scale) ? scale : null;
}
function scoreInterval(bounds, actual, reference, target) {
  const [lo, hi] = bounds;
  return 100 * (hi - lo + 2 / (1 - target) * (Math.max(0, lo - actual) + Math.max(0, actual - hi))) / reference;
}
function evaluateConformalRange(forecast, actual) {
  const c = forecast?.rangeCalibration;
  if (c?.policy !== CONFORMAL_POLICY || c.mode !== "shadow" || c.status !== "shadow" || c.targetCoverage !== CONFORMAL_TARGET || c.sample < CONFORMAL_MIN_SAMPLE || !instant(c.calibratedAt) || c.calibratedAt !== forecast.createdAt || !instant(c.calibrationThrough) || Date.parse(c.calibrationThrough) >= Date.parse(c.calibratedAt) || !interval(c.range) || !interval(forecast.range) || !positive(actual) || !positive(forecast.price)) return null;
  const result = {
    policy: CONFORMAL_POLICY,
    targetCoverage: CONFORMAL_TARGET,
    candidateHit: actual >= c.range[0] && actual <= c.range[1],
    baselineHit: actual >= forecast.range[0] && actual <= forecast.range[1],
    candidateWidthPct: 100 * (c.range[1] - c.range[0]) / forecast.price,
    baselineWidthPct: 100 * (forecast.range[1] - forecast.range[0]) / forecast.price,
    candidateIntervalScorePct: scoreInterval(c.range, actual, forecast.price, CONFORMAL_TARGET),
    baselineIntervalScorePct: scoreInterval(forecast.range, actual, forecast.price, CONFORMAL_TARGET)
  };
  return Object.values(result).some((v) => typeof v === "number" && !Number.isFinite(v)) ? null : result;
}
function observed(rows) {
  const pairs = rows.map((r) => evaluateConformalRange(r.forecast, r.outcome.actualPrice)).filter((r) => r !== null);
  const mean2 = (key) => pairs.length ? pairs.reduce((s, p) => s + p[key], 0) / pairs.length : null;
  return {
    sample: pairs.length,
    candidateCoveragePct: pairs.length ? 100 * pairs.filter((p) => p.candidateHit).length / pairs.length : null,
    baselineCoveragePct: pairs.length ? 100 * pairs.filter((p) => p.baselineHit).length / pairs.length : null,
    candidateMeanWidthPct: mean2("candidateWidthPct"),
    baselineMeanWidthPct: mean2("baselineWidthPct"),
    candidateMeanIntervalScorePct: mean2("candidateIntervalScorePct"),
    baselineMeanIntervalScorePct: mean2("baselineIntervalScorePct")
  };
}
function eligibleHistory(records, ctx) {
  if (!instant(ctx.asOf)) return [];
  const cutoff = Date.parse(ctx.asOf), cutoffDate = ctx.asOf.slice(0, 10), candidates = [];
  for (const r of records) {
    const f = object(r.forecast ?? r.forecast_data), o = object(r.outcome ?? r.outcome_data);
    if (!f || !o || typeof r.id !== "string" || !r.id || r.symbol !== ctx.symbol || r.market !== ctx.market || r.model !== ctx.model || r.horizon !== ctx.horizon || ![true, 1].includes(r.available) || f.recordClass !== "prospective-public" || f.currency !== ctx.currency || f.model !== ctx.model || f.sessions !== ctx.horizon || f.evaluationPolicy !== EVALUATION_POLICY || o.evaluationPolicy !== EVALUATION_POLICY || f.rangeMeaning !== "end_close_estimate" || !instant(r.created_at) || !instant(r.evaluated_at) || !date(f.anchorDate) || !date(o.actualDate) || Date.parse(r.created_at) >= cutoff || Date.parse(r.evaluated_at) >= cutoff || Date.parse(r.evaluated_at) < Date.parse(r.created_at) || o.state !== "complete" || o.actualDate <= f.anchorDate || o.actualDate >= cutoffDate || r.created_at.slice(0, 10) > o.actualDate || r.created_at.slice(0, 10) < f.anchorDate || r.evaluated_at.slice(0, 10) <= o.actualDate || f.seriesBasis?.adjustment !== ctx.adjustment || !positive(f.predictedPrice) || !positive(o.actualPrice) || !interval(f.range)) continue;
    const scale = savedPriceScale(f);
    if (scale === null) continue;
    const score = Math.abs(o.actualPrice - f.predictedPrice) / scale;
    if (!Number.isFinite(score)) continue;
    candidates.push({ ...r, forecast: f, outcome: o, score });
  }
  candidates.sort((a, b) => a.created_at.localeCompare(b.created_at) || a.id.localeCompare(b.id));
  const seen = /* @__PURE__ */ new Set(), sample = [];
  let end = "";
  for (const r of candidates) {
    if (seen.has(r.id)) continue;
    seen.add(r.id);
    if (r.forecast.anchorDate <= end) continue;
    sample.push(r);
    end = r.outcome.actualDate;
  }
  return sample.slice(-MAX_SAMPLE);
}
function calibrateForecastRange2(forecast, records, ctx, options = {}) {
  const sample = eligibleHistory(records, ctx), scale = savedPriceScale(forecast);
  const result = {
    policy: CONFORMAL_POLICY,
    mode: "shadow",
    status: "collecting",
    reason: "\u062A\u062C\u0645\u064A\u0639 \u0646\u062A\u0627\u0626\u062C \u0645\u0643\u062A\u0645\u0644\u0629 \u0644\u0645\u0639\u0627\u064A\u0631\u0629 \u0646\u0637\u0627\u0642 \u0645\u0633\u062A\u0642\u0644 \u0644\u0647\u0630\u0647 \u0627\u0644\u0645\u062F\u0629\u061B \u0644\u0627 \u0646\u0633\u0628\u0629 \u062A\u062D\u0642\u0642 \u0645\u0641\u062A\u0631\u0636\u0629.",
    targetCoverage: CONFORMAL_TARGET,
    guaranteedCoverage: false,
    sample: sample.length,
    minimumSample: CONFORMAL_MIN_SAMPLE,
    scope: "same-symbol-market-currency-model-horizon",
    scaleDefinition: "reference-price-times-saved-log-volatility",
    scale,
    quantile: null,
    rank: null,
    range: null,
    baselineRange: interval(forecast?.range) ? [forecast.range[0], forecast.range[1]] : null,
    widthPct: null,
    calibratedAt: ctx.asOf,
    calibrationIds: sample.map((r) => r.id),
    calibrationThrough: sample.length ? sample.reduce((a, r) => a > r.evaluated_at ? a : r.evaluated_at, "") : null,
    historyTruncated: !!options.historyTruncated,
    observed: observed(sample)
  };
  const unavailable = (reason) => ({ ...result, status: "unavailable", reason });
  if (options.readError) return unavailable("\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u0633\u062C\u0644 \u0627\u0644\u0645\u0639\u0627\u064A\u0631\u0629\u061B \u0623\u0639\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0639\u0646\u062F \u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u062A\u0627\u0644\u064A.");
  if (!instant(ctx.asOf) || !ctx.symbol || !ctx.currency || !["sa", "us"].includes(ctx.market) || ![1, 5, 21, 63, 126, 252].includes(ctx.horizon) || ctx.recordClass !== "prospective-public" || !ctx.model.startsWith("mizan-scenarios-7-")) return unavailable("\u0647\u0630\u0647 \u0627\u0644\u0644\u0642\u0637\u0629 \u0623\u0648 \u0646\u0633\u062E\u0629 \u0627\u0644\u0646\u0645\u0648\u0630\u062C \u063A\u064A\u0631 \u0645\u0624\u0647\u0644\u0629 \u0644\u0645\u0639\u0627\u064A\u0631\u0629 \u0627\u0644\u0633\u062C\u0644 \u0627\u0644\u062D\u064A.");
  if (!forecast?.available || !positive(forecast.predictedPrice) || !interval(forecast.range) || scale === null || forecast.sessions !== ctx.horizon || forecast.evaluationPolicy !== EVALUATION_POLICY || forecast.rangeMeaning !== "end_close_estimate")
    return unavailable("\u0644\u0627 \u064A\u062A\u0648\u0641\u0631 \u062A\u0648\u0642\u0639 \u0645\u0631\u0643\u0632\u064A \u0623\u0648 \u0645\u0642\u064A\u0627\u0633 \u062A\u0630\u0628\u0630\u0628 \u0635\u0627\u0644\u062D \u0644\u0647\u0630\u0647 \u0627\u0644\u0645\u062F\u0629.");
  if (sample.length < CONFORMAL_MIN_SAMPLE) return result;
  const q = conformalQuantile(sample.map((r) => r.score));
  if (!q) return unavailable("\u0627\u0644\u0639\u064A\u0646\u0629 \u0644\u0627 \u062A\u0633\u0645\u062D \u0628\u0645\u0626\u064A\u0646 \u0645\u0637\u0627\u0628\u0642 \u0645\u062D\u062F\u0648\u062F\u061B \u0644\u0645 \u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0645\u0639\u0627\u0645\u0644 \u0628\u062F\u064A\u0644.");
  const halfWidth = q.value * scale, range = [forecast.predictedPrice - halfWidth, forecast.predictedPrice + halfWidth];
  if (!interval(range) || !Number.isFinite(halfWidth) || halfWidth <= 0) return unavailable("\u0627\u0644\u0646\u0637\u0627\u0642 \u0627\u0644\u0645\u0639\u0627\u064A\u0631 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D \u0644\u0644\u0623\u0633\u0639\u0627\u0631\u061B \u064A\u0644\u0632\u0645 \u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u0623\u062E\u0637\u0627\u0621 \u0648\u0627\u0644\u062A\u0630\u0628\u0630\u0628 \u062F\u0648\u0646 \u0642\u0635 \u0627\u0644\u062D\u062F\u0648\u062F.");
  const widthPct = 100 * (range[1] - range[0]) / forecast.price;
  if (!Number.isFinite(widthPct)) return unavailable("\u062A\u0639\u0630\u0631 \u062D\u0633\u0627\u0628 \u0639\u0631\u0636 \u0646\u0637\u0627\u0642 \u0645\u062D\u062F\u0648\u062F.");
  return {
    ...result,
    status: "shadow",
    reason: "\u0646\u0637\u0627\u0642 \u062A\u062C\u0631\u064A\u0628\u064A \u0645\u062D\u0641\u0648\u0638 \u0644\u0644\u0645\u0642\u0627\u0631\u0646\u0629\u061B \u0627\u0644\u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u0645\u0633\u062A\u0647\u062F\u0641\u0629 \u0644\u0627 \u062A\u0636\u0645\u0646 \u0643\u0644 \u062A\u0648\u0642\u0639 \u0623\u0648 \u062D\u0627\u0644\u0629 \u0633\u0648\u0642.",
    quantile: q.value,
    rank: q.rank,
    range,
    widthPct
  };
}
async function loadConformalHistory(db, symbol, market, model, asOf) {
  try {
    const result = await db.prepare(`WITH ranked AS (
      SELECT f.*,o.evaluated_at,o.data AS outcome_data,
        ROW_NUMBER() OVER (PARTITION BY f.horizon ORDER BY f.created_at DESC,f.id) AS rn
      FROM forecast_records f JOIN forecast_outcomes o ON o.id=f.id
      WHERE f.symbol=? AND f.market=? AND f.model=? AND f.available=1
        AND f.created_at<? AND o.evaluated_at<? AND json_valid(f.data) AND json_valid(o.data)
    ) SELECT id,symbol,horizon,market,model,available,created_at,evaluated_at,outcome_data,
      json_object('recordClass',json_extract(data,'$.recordClass'),'currency',json_extract(data,'$.currency'),
        'model',json_extract(data,'$.model'),'sessions',json_extract(data,'$.sessions'),
        'price',json_extract(data,'$.price'),'predictedPrice',json_extract(data,'$.predictedPrice'),
        'anchorDate',json_extract(data,'$.anchorDate'),'createdAt',json_extract(data,'$.createdAt'),'range',json_extract(data,'$.range'),
        'rangeCheck',json_extract(data,'$.rangeCheck'),'rangeMeaning',json_extract(data,'$.rangeMeaning'),
        'evaluationPolicy',json_extract(data,'$.evaluationPolicy'),'seriesBasis',json_extract(data,'$.seriesBasis'),
        'rangeCalibration',json_extract(data,'$.rangeCalibration')) AS forecast_data,
      rn FROM ranked WHERE rn<=? ORDER BY created_at,id`).bind(symbol, market, model, asOf, asOf, QUERY_PER_HORIZON + 1).all();
    const rows = result.results || [];
    return { records: rows.filter((r) => r.rn <= QUERY_PER_HORIZON), truncatedHorizons: new Set(rows.filter((r) => r.rn > QUERY_PER_HORIZON).map((r) => r.horizon)), readError: false };
  } catch {
    return { records: [], truncatedHorizons: /* @__PURE__ */ new Set(), readError: true };
  }
}

// ../../../tmp/mizan-v45-canonical-18ba8f39-20261003T223500Z/mizan-v45/lib/forecast-journal.ts
var MATURITY_PREDICATE = "julianday(?) - julianday(f.created_at) >= f.horizon * 7.0/5";
function researchMarket(report) {
  return report.company.symbol.endsWith(".SR") ? "sa" : /nasdaq|nyse|amex|arca|bats|^NMS$|^NGM$|^NCM$|^NYQ$|^PCX$|^ASE$|^BTS$/i.test(report.company.exchange) ? "us" : "other";
}
function evaluateForecast(record, report) {
  if (!record.available) return null;
  let data;
  try {
    data = typeof record.data === "string" ? JSON.parse(record.data) : record.data;
  } catch {
    return null;
  }
  if (!data || typeof data !== "object") return null;
  if (!Number.isInteger(record.horizon) || record.horizon < 1 || typeof data.anchorDate !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(data.anchorDate) || !Number.isFinite(Date.parse(data.anchorDate + "T00:00:00Z")) || (/* @__PURE__ */ new Date(data.anchorDate + "T00:00:00Z")).toISOString().slice(0, 10) !== data.anchorDate || !report.prices.length || report.prices[0].date > data.anchorDate) return null;
  if (record.symbol && record.symbol !== report.company.symbol) return { state: "excluded", source: report.priceSource, reason: "\u0647\u0648\u064A\u0629 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u062A\u062E\u062A\u0644\u0641 \u0639\u0646 \u0627\u0644\u0623\u0635\u0644 \u0627\u0644\u0645\u062D\u0641\u0648\u0638." };
  if (data.currency && data.currency !== report.currency) return { state: "excluded", source: report.priceSource, reason: "\u0639\u0645\u0644\u0629 \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u062A\u062E\u062A\u0644\u0641 \u0639\u0646 \u0639\u0645\u0644\u0629 \u0627\u0644\u062A\u0648\u0642\u0639." };
  const basis = data.seriesBasis;
  if (basis?.anchorClose) {
    const anchor = report.prices.find((p) => p.date === basis.anchorDate);
    if (!anchor) return null;
    if (basis.adjustment && basis.adjustment !== report.priceAdjustment || Math.abs(anchor.close - basis.anchorClose) > Math.max(1e-6, Math.abs(basis.anchorClose) * 1e-4)) return { state: "excluded", source: report.priceSource, reason: "\u062A\u063A\u064A\u0631 \u0623\u0633\u0627\u0633 \u0627\u0644\u0633\u0644\u0633\u0644\u0629 \u0623\u0648 \u0633\u0639\u0631\u0647\u0627 \u0627\u0644\u062A\u0627\u0631\u064A\u062E\u064A \u0627\u0644\u0645\u0631\u062C\u0639\u064A\u061B \u064A\u0644\u0632\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0627\u0644\u0645\u0632\u0648\u062F \u0642\u0628\u0644 \u0627\u0644\u0642\u064A\u0627\u0633." };
  }
  const future = report.prices.filter((p) => p.date > data.anchorDate);
  const marketDates = report.context?.market?.prices.filter((p) => p.date > data.anchorDate).map((p) => p.date);
  if (data.evaluationPolicy === EVALUATION_POLICY && (!marketDates || marketDates.length < record.horizon)) return null;
  if (marketDates && marketDates.length < record.horizon || !marketDates && future.length < record.horizon) return null;
  const actual = marketDates ? report.prices.find((p) => p.date === marketDates[record.horizon - 1]) : future[record.horizon - 1];
  if (!actual || actual.date >= report.asOf) return null;
  const actions = report.corporateActions || [];
  if (actions.some((a) => a.kind === "split" && a.date > data.anchorDate && a.date <= actual.date)) return { state: "excluded", source: report.priceSource, reason: "\u062D\u062F\u062B\u062A \u062A\u062C\u0632\u0626\u0629/\u062A\u062C\u0645\u064A\u0639 \u0623\u0633\u0647\u0645 \u062E\u0644\u0627\u0644 \u0627\u0644\u0641\u062A\u0631\u0629\u061B \u062A\u064F\u0633\u062A\u0628\u0639\u062F \u0645\u0646 \u0627\u0644\u0646\u0633\u0628\u0629 \u062D\u062A\u0649 \u062A\u064F\u0631\u0627\u062C\u0639 \u0648\u062D\u062F\u0627\u062A \u0627\u0644\u0633\u0639\u0631\u060C \u0645\u0639 \u0625\u0628\u0642\u0627\u0621 \u0627\u0644\u0633\u062C\u0644." };
  if (!data.price || !Array.isArray(data.range) || !data.range.every(Number.isFinite)) return null;
  const metrics = forecastMetrics({ reference: data.price, predicted: data.predictedPrice, actual: actual.close, range: data.range, direction: data.direction, neutralThresholdPct: data.neutralThresholdPct ?? 1 });
  const rangeComparison = evaluateConformalRange(data, actual.close);
  return { state: "complete", actualDate: actual.date, actualPrice: actual.close, actualDirection: metrics.actualDirection, directionCorrect: metrics.directionCorrect, priceErrorPct: metrics.relativeErrorPct, rangeHit: metrics.endRangeHit, source: report.priceSource, metrics, evaluationPolicy: EVALUATION_POLICY, ...rangeComparison ? { rangeComparison } : {} };
}
async function recordAnalysis(db, report, settings = DEFAULT_SETTINGS, accountKey = null) {
  const projection = forecasts(report, report.liveQuote || null, Date.now(), settings), createdAt = (/* @__PURE__ */ new Date()).toISOString(), id = crypto.randomUUID();
  const market = researchMarket(report);
  const priorResult = await db.prepare("SELECT f.symbol,f.horizon,f.market,f.model,f.created_at,json_extract(f.data,'$.direction') AS forecast_direction,o.data FROM forecast_records f JOIN forecast_outcomes o ON o.id=f.id WHERE f.model=? AND f.market=? AND json_extract(f.data,'$.recordClass')='prospective-public' ORDER BY f.created_at DESC LIMIT 10000").bind(projection.version, market).all();
  const prior = (priorResult.results || []).map((r) => ({ ...r, outcome: JSON.parse(r.data), forecastDirection: r.forecast_direction }));
  const rangeHistory = publicBaselineEligible(report) ? await loadConformalHistory(db, report.company.symbol, market, projection.version, createdAt) : { records: [], truncatedHorizons: /* @__PURE__ */ new Set(), readError: false };
  const baseline = publicBaselineEligible(report) ? decisionBaseline({ ...report, forecast: projection }, createdAt) : null;
  if (baseline) {
    try {
      const last2 = await db.prepare("SELECT data FROM analysis_snapshots WHERE symbol=? AND json_extract(data,'$.decisionBaseline.version')=? ORDER BY created_at DESC,rowid DESC LIMIT 1").bind(report.company.symbol, DECISION_VERSION).first();
      report.changes = last2 ? compareDecisionBaselines(JSON.parse(last2.data).decisionBaseline, baseline, report.corporateActions) : { state: "first", reason: "\u0647\u0630\u0627 \u0623\u0648\u0644 \u062A\u062D\u0644\u064A\u0644 \u0645\u062D\u0641\u0648\u0638 \u064A\u062F\u0639\u0645 \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629. \u0633\u062A\u0638\u0647\u0631 \u0627\u0644\u0641\u0631\u0648\u0642 \u0639\u0646\u062F \u0625\u0639\u0627\u062F\u0629 \u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u0633\u0647\u0645." };
    } catch {
      report.changes = { state: "unavailable", reason: "\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u0633\u0627\u0628\u0642\u061B \u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u062D\u0627\u0644\u064A \u0645\u0633\u062A\u0645\u0631 \u062F\u0648\u0646 \u0645\u0642\u0627\u0631\u0646\u0629." };
    }
  } else report.changes = { state: "private", reason: "\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u064A\u062A\u0636\u0645\u0646 \u0645\u0644\u0641\u064B\u0627 \u062E\u0627\u0635\u064B\u0627 \u0623\u0648 \u0628\u064A\u0627\u0646\u0627\u062A \u062A\u0627\u0631\u064A\u062E\u064A\u0629\u061B \u0644\u0627 \u064A\u062F\u062E\u0644 \u0641\u064A \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629 \u0627\u0644\u0639\u0627\u0645\u0629 \u0644\u0644\u062A\u062D\u0627\u0644\u064A\u0644 \u0627\u0644\u062D\u0627\u0644\u064A\u0629." };
  const snapshot = { ...report, accountKey: publicBaselineEligible(report) ? null : accountKey, recordClass: publicBaselineEligible(report) ? "prospective-public" : report.mode === "historical" ? "historical" : "private-input", decisionBaseline: baseline };
  delete snapshot.forecast;
  delete snapshot.changes;
  const previous = await db.prepare("SELECT id FROM analysis_snapshots WHERE symbol=? AND (json_extract(data,'$.recordClass')='prospective-public' OR json_extract(data,'$.accountKey')=?) ORDER BY created_at DESC,rowid DESC LIMIT 1").bind(report.company.symbol, accountKey).first();
  const rows = projection.rows.map((row) => {
    const completedAnchor = report.prices.filter((p) => p.date < row.window.anchorDate).at(-1);
    const calibrated = calibration(prior, row.sessions, market, projection.version, createdAt, row.direction);
    return { id: crypto.randomUUID(), ...row, anchorDate: row.window.anchorDate, createdAt, model: projection.version, currency: report.currency, unit: "share", assetType: report.company.instrument || "EQUITY", priceTime: projection.priceTime, source: report.priceSource, seriesBasis: { adjustment: report.priceAdjustment || null, anchorDate: completedAnchor?.date ?? null, anchorClose: completedAnchor?.close ?? null, definition: "\u0622\u062E\u0631 \u0634\u0645\u0639\u0629 \u0645\u0643\u062A\u0645\u0644\u0629 \u0642\u0628\u0644 \u064A\u0648\u0645 \u0627\u0644\u0625\u0635\u062F\u0627\u0631\u061B \u0634\u0645\u0639\u0629 \u0627\u0644\u0625\u0635\u062F\u0627\u0631 \u0644\u0627 \u062A\u0633\u062A\u062E\u062F\u0645 \u0644\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0625\u0639\u0627\u062F\u0629 \u0636\u0628\u0637 \u0627\u0644\u0633\u0644\u0633\u0644\u0629" }, settingsUsed: projection.settingsUsed, evidenceId: report.research?.recorded ? report.research.id : null, accountKey: publicBaselineEligible(report) ? null : accountKey, previousSnapshotId: previous?.id || null, recordClass: publicBaselineEligible(report) ? "prospective-public" : report.mode === "historical" ? "historical" : "private-input", probability: calibrated.probabilities, historicalAccuracy: calibrated.accuracy, calibration: calibrated, confidence: row.confidence, evidenceQuality: row.confidence, calibrationStatus: calibrated.confidence };
  });
  const calibratedRows = rows.map((row) => ({ ...row, rangeCalibration: calibrateForecastRange2(row, rangeHistory.records, {
    symbol: report.company.symbol,
    market,
    currency: report.currency,
    model: projection.version,
    horizon: row.sessions,
    asOf: createdAt,
    recordClass: row.recordClass,
    adjustment: report.priceAdjustment || null
  }, { historyTruncated: rangeHistory.truncatedHorizons.has(row.sessions), readError: rangeHistory.readError }) }));
  await db.batch([db.prepare("INSERT INTO analysis_snapshots (id,symbol,created_at,data) VALUES (?,?,?,?)").bind(id, report.company.symbol, createdAt, JSON.stringify(snapshot)), ...calibratedRows.map((row) => db.prepare("INSERT INTO forecast_records (id,snapshot_id,symbol,created_at,horizon,model,market,sector,confidence,available,data) VALUES (?,?,?,?,?,?,?,?,?,?,?)").bind(row.id, id, report.company.symbol, createdAt, row.sessions, projection.version, market, report.company.sector || "\u063A\u064A\u0631 \u0645\u062A\u062D\u0642\u0642", row.confidence, row.available ? 1 : 0, JSON.stringify(row)))]);
  try {
    await resolveForecasts(db, report);
  } catch {
    report.warnings.push("\u062D\u064F\u0641\u0638 \u0627\u0644\u062A\u0648\u0642\u0639\u060C \u0644\u0643\u0646 \u062A\u0639\u0630\u0631\u062A \u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u0639\u0636 \u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0627\u0644\u0645\u0633\u062A\u062D\u0642\u0629\u061B \u0633\u062A\u064F\u0639\u0627\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0639\u0646\u062F \u0627\u0644\u062A\u062D\u062F\u064A\u062B.");
  }
  return { ...projection, createdAt, rows: calibratedRows, snapshotId: id, recorded: true };
}
function calibration(records, horizon, market, model, now, direction) {
  const candidates = records.filter((r) => r.horizon === horizon && r.market === market && r.model === model && r.created_at < now && r.outcome?.state === "complete" && r.outcome.actualDate < now.slice(0, 10));
  const bySymbol = /* @__PURE__ */ new Map();
  for (const r of candidates) bySymbol.set(r.symbol, [...bySymbol.get(r.symbol) || [], r]);
  const sample = [];
  for (const group of bySymbol.values()) {
    let end = "";
    for (const r of group.sort((a, b) => a.created_at.localeCompare(b.created_at))) {
      if (r.created_at.slice(0, 10) > end) {
        sample.push(r);
        end = r.outcome.actualDate;
      }
    }
  }
  const n = sample.length;
  if (n < 30) return { confidence: "\u063A\u064A\u0631 \u0645\u0639\u0627\u064A\u0631\u0629", probabilities: null, accuracy: n ? sample.filter((r) => r.outcome.directionCorrect).length / n * 100 : null, sample: n, advantage: false, trainedThrough: now };
  const p = sample.filter((r) => r.outcome.directionCorrect).length / n, z = 1.96, lower = (p + z * z / (2 * n) - z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / (1 + z * z / n);
  const matched = sample.filter((r) => r.forecastDirection === direction);
  const probabilities = matched.length >= 30 ? Object.fromEntries(["\u0635\u0627\u0639\u062F", "\u0645\u062D\u0627\u064A\u062F", "\u0647\u0627\u0628\u0637"].map((d) => [d, (matched.filter((r) => r.outcome.actualDirection === d).length + 1) / (matched.length + 3) * 100])) : null;
  const proportions = Object.fromEntries(["\u0635\u0627\u0639\u062F", "\u0645\u062D\u0627\u064A\u062F", "\u0647\u0627\u0628\u0637"].map((d) => [d, sample.filter((r) => r.outcome.actualDirection === d).length / n]));
  const baseline = Math.max(...Object.values(proportions));
  const advantage = lower > baseline;
  return { confidence: advantage && n >= 100 ? "\u0645\u062A\u0648\u0633\u0637" : "\u0645\u0646\u062E\u0641\u0636", probabilities, accuracy: p * 100, sample: n, advantage, lower95: lower * 100, majorityBaseline: baseline * 100, trainedThrough: now };
}
async function saveEvaluationRevision(db, forecastId, outcome, reason = "\u062A\u0642\u064A\u064A\u0645 \u0628\u064A\u0627\u0646\u0627\u062A \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0645\u062F\u0629") {
  const lease = crypto.randomUUID(), lock = "evaluation:" + forecastId;
  const claimed = await db.prepare("INSERT INTO research_locks(id,token,until_ms) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET token=excluded.token,until_ms=excluded.until_ms WHERE until_ms<? RETURNING token").bind(lock, lease, Date.now() + 3e4, Date.now()).first();
  if (!claimed) return false;
  try {
    const hash = await fingerprint(JSON.stringify(outcome)), latest = await db.prepare("SELECT data,fingerprint FROM evaluation_revisions WHERE forecast_id=? ORDER BY revision DESC LIMIT 1").bind(forecastId).first();
    if (latest?.fingerprint === hash) return false;
    const old = await db.prepare("SELECT * FROM forecast_outcomes WHERE id=?").bind(forecastId).first(), at = (/* @__PURE__ */ new Date()).toISOString(), statements = [];
    if (old && !latest) statements.push(db.prepare("INSERT INTO evaluation_revisions(id,forecast_id,revision,created_at,fingerprint,data) SELECT ?,?,0,?,?,? WHERE NOT EXISTS(SELECT 1 FROM evaluation_revisions WHERE forecast_id=?)").bind(crypto.randomUUID(), forecastId, old.evaluated_at, "legacy", JSON.stringify({ outcome: JSON.parse(old.data), reason: "\u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629 \u0642\u0628\u0644 \u062A\u062D\u062F\u064A\u062B \u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0642\u064A\u0627\u0633\u061B \u0645\u062D\u0641\u0648\u0638\u0629 \u0643\u0645\u0627 \u0643\u0627\u0646\u062A." }), forecastId));
    const revisionId = crypto.randomUUID();
    statements.push(db.prepare("INSERT INTO evaluation_revisions(id,forecast_id,revision,created_at,fingerprint,data) SELECT ?,?,COALESCE(MAX(revision),0)+1,?,?,? FROM evaluation_revisions WHERE forecast_id=? HAVING (SELECT fingerprint FROM evaluation_revisions WHERE forecast_id=? ORDER BY revision DESC LIMIT 1) IS NOT ?").bind(revisionId, forecastId, at, hash, JSON.stringify({ outcome, reason }), forecastId, forecastId, hash));
    statements.push(db.prepare("INSERT INTO forecast_outcomes(id,evaluated_at,data) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM evaluation_revisions WHERE id=?) ON CONFLICT(id) DO UPDATE SET evaluated_at=excluded.evaluated_at,data=excluded.data").bind(forecastId, at, JSON.stringify(outcome), revisionId));
    const result = await db.batch(statements), write = result.at(-1);
    return Number(write?.meta?.changes ?? write?.changes ?? 0) > 0;
  } finally {
    try {
      await db.prepare("DELETE FROM research_locks WHERE id=? AND token=?").bind(lock, lease).run();
    } catch {
    }
  }
}
var ForecastResolutionError = class extends Error {
  constructor(evaluationsSaved) {
    super("forecast-resolution-failed");
    this.evaluationsSaved = evaluationsSaved;
  }
};
async function resolveForecasts(db, report) {
  const pending = await db.prepare(`SELECT f.* FROM forecast_records f LEFT JOIN forecast_outcomes o ON o.id=f.id WHERE f.symbol=? AND f.available=1 AND o.id IS NULL AND ${MATURITY_PREDICATE} ORDER BY f.created_at LIMIT 15`).bind(report.company.symbol, report.asOf).all();
  let count = 0;
  try {
    for (const record of pending.results || []) {
      const outcome = evaluateForecast(record, report);
      if (outcome && await saveEvaluationRevision(db, record.id, outcome)) count++;
    }
  } catch {
    throw new ForecastResolutionError(count);
  }
  return count;
}
export {
  DEFAULT_SETTINGS,
  automaticAnalysis,
  forecastModelVersion,
  forecasts,
  recordAnalysis
};
